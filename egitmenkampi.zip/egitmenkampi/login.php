

          <?php require_once 'header.php'; ?>





       <head><title>Üye Girişi - Eğitmenkampı</title>


<style type="text/css">
  
  @media only screen and (min-width: 992px){

    .giris_form {


margin-left:80px;
margin-top:70px;

    }

.loginkisim {

height: 524px;

}

.giris_banner {

background-image: url(loginfoto.jpeg);
background-size: cover;
height: 524px;

}

  }




</style>

       </head>

        <?php if (isset($_SESSION['kullanicioturum'])) {

          Header("Location:index");
        }; ?>


        <!-- Inner Page Banner Area End Here -->          
        <!-- Product Upload Page Start Here -->

        <div class="row">

          <div class="giris_banner col-md-6">





          </div>




          <div  class="product-upload-page-area bg-secondary section-space-bottom loginkisim col-md-6">
            <br>
            <div class="giris_form container">
              <div class="col-md-5 animated bounceInUp">
                <h3 style="color:#43DE09;" class="title-section">Üye Girişi</h3>
                <form action="nedmin/production/netting/musteriislem.php" method="POST" id="personal-info-form">


                  <div class="product-upload-wrapper inner-page-padding">


                    <?php   if (@$_GET['session']=="no") { ?>


                      <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Öncelikle giriş yapmalısınız.Hesabınız yoksa <a href="uyekayit.php">Hızlıca Üye Ol!</a></div>


                    <?php } ?>


                    <?php   if (@$_GET['login']=="fail") { ?>


                      <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Giriş İşlemi Başarısız Oldu.</div>

                    <?php } ?>


                    <?php   if (@$_GET['sifreyenileme']=="ok") { ?>


                      <div class="alert alert-success"><i class="fas fa-tick"></i> Yeni Şifreniz E-Posta Adresinize Yollandı.</div>

                    <?php } ?>





                    <div class="form-group">

                      <input name="kullanici_mail" required="" placeholder="E-Posta Adresiniz"    maxlength="100" type="email" id="first-name" class="form-control">
                    </div>




                    <div class="form-group">

                      <input name="kullanici_password" required="" placeholder="Şifreniz"    maxlength="20" type="password" id="first-name" class="form-control">
                    </div>

                    <button name="login" id="loginbuton" class="update-btn btn-block btn-pill"   type="submit">Giriş Yap</button>

                    <br><br>


                    <div class="row">

                      <div class="col-md-6"><a  href='sifremiunuttum' style="color:black;">Şifremi Unuttum</a></div>



                      <div class="col-md-6">Üye Değil Misin? <a href="uyekayit.php">Üye Ol !</a></div>
                    </div>







                  </div>

                </form>



              </div> 
            </div>
          </div>

        </div>




        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">

         $(document).ready(function() {
          $('#personal-info-form').submit(function() {

            $('#loginbuton').html("Giriş Yapılıyor <img style='height:22px;width:22px;' src='rolling.gif'>");

            if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
              jQuery.data(this, "disabledOnSubmit", { submited: true });
              $('input[type=submit], input[type=button]', this).each(function() {
                $(this).attr("disabled", "disabled");
              });
              return true;
            }
            else
            {
              return false;
            };






          });


        });

      </script>
