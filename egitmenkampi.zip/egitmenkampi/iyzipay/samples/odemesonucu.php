<?php

require_once('config.php');
include '../../nedmin/production/netting/baglann.php';
session_start();
ob_start();

$kullanicioturumsec=$db->prepare("SELECT * from kullanici where kullanici_durum=:durum and kullanici_mail=:mail");
$kullanicioturumsec->execute(array(
  "durum" => 1,
  "mail" => $_SESSION['kullanicioturum']
));
$kullanicioturumcek=$kullanicioturumsec->fetch(PDO::FETCH_ASSOC);

$token=$_POST['token'];
 $premium_turu=$_GET['preType'];



# create request class
$request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
$request->setLocale(\Iyzipay\Model\Locale::TR);
//$request->setConversationId($_SESSION['kullanici_id']);
$request->setToken($token);



# make request
$checkoutForm = \Iyzipay\Model\CheckoutForm::retrieve($request, Config::options());
$odeme_durum=$checkoutForm->getPaymentStatus();

if($odeme_durum=='FAILURE'){
    
    header("Location:https://www.egitmenkampi.com/odeme-planlari?payStatus=failure");
    
} else if($odeme_durum=='SUCCESS'){
    
    $kullanici_id=$_SESSION['kullanici_id'];
    
    $hazirla=$db->prepare("UPDATE kullanici set 

premium_baslangic=:premium_baslangic,
premium_bitis=:premium_bitis,
kullanici_onecikan=:kullanici_onecikan,
premium_turu=:premium_turu

where kullanici_id='$kullanici_id'
		");


switch ($premium_turu) {
	case '1':
		$derle=$hazirla->execute(array(
"premium_baslangic" => date('d.m.Y H:i:s'),
"premium_bitis" => date('d.m.Y H:i:s',strtotime('+2592000 seconds')),
"kullanici_onecikan" => 1,
"premium_turu" => $premium_turu
	));


		$hazirla2=$db->prepare("INSERT into premiumsatislari set

egitmen_id=:egitmen_id,
premium_turu=:premium_turu

			");

		$derle2=$hazirla2->execute(array(

			"egitmen_id" => $kullanici_id,
			"premium_turu" => 1

		));

		break;
	
	case '2':

	$derle=$hazirla->execute(array(
"premium_baslangic" => date('d.m.Y H:i:s'),
"premium_bitis" => date('d.m.Y H:i:s',strtotime('+15811200 seconds')),
"kullanici_onecikan" => 1,
"premium_turu" => $premium_turu
	));

	$hazirla2=$db->prepare("INSERT into premiumsatislari set

egitmen_id=:egitmen_id,
premium_turu=:premium_turu

			");

		$derle2=$hazirla2->execute(array(

			"egitmen_id" => $kullanici_id,
			"premium_turu" => 2

		));


	break;

	case '3':

	$derle=$hazirla->execute(array(
"premium_baslangic" => date('d.m.Y H:i:s'),
"premium_bitis" => date('d.m.Y H:i:s',strtotime('+31536000 seconds')),
"kullanici_onecikan" => 1,
"premium_turu" => $premium_turu
	));

	$hazirla2=$db->prepare("INSERT into premiumsatislari set

egitmen_id=:egitmen_id,
premium_turu=:premium_turu

			");

		$derle2=$hazirla2->execute(array(

			"egitmen_id" => $kullanici_id,
			"premium_turu" => 3

		));


	break;
};
	
$hazirla2=$db->prepare("UPDATE egitmenkategori set 

kullanici_onecikan=:kullanici_onecikan

where egitmen_id='$kullanici_id'
		");


	$derle2=$hazirla2->execute(array(
"kullanici_onecikan" => 1
	));

	$hazirla3=$db->prepare("UPDATE kategoriilce set 

kullanici_onecikan=:kullanici_onecikan

where egitmen_id='$kullanici_id'
		");


	$derle3=$hazirla3->execute(array(
"kullanici_onecikan" => 1
	));


	





    
     header("Location:https://www.egitmenkampi.com/ayricalikli-uyeligim?payStatus=success");
    
};

# print result
//print_r($checkoutForm);