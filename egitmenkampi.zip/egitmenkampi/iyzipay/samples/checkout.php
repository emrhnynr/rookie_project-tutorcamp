<?php

require_once('config.php');
include '../../nedmin/production/netting/baglann.php';
$ayricalikturu=$_GET['preType'];
session_start();
ob_start();

$kullanicioturumsec=$db->prepare("SELECT * from kullanici where kullanici_durum=:durum and kullanici_mail=:mail");
$kullanicioturumsec->execute(array(
  "durum" => 1,
  "mail" => $_SESSION['kullanicioturum']
));
$kullanicioturumcek=$kullanicioturumsec->fetch(PDO::FETCH_ASSOC);

$sehirsec=$db->prepare("SELECT * from sehirler where sehir_id=:id");
$sehirsec->execute(array(
    "id" => $kullanicioturumcek['kullanici_il']
    ));
    
    $sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC);
    
     $ipAdres=$_SERVER['REMOTE_ADDR'];
    
    

if ($kullanicioturumcek['kullanici_yetki']!=1 or $kullanicioturumcek['kullanici_onecikan']==1 or ($ayricalikturu!=1 and $ayricalikturu!=2 and $ayricalikturu!=3)) {
    
    header("Location:../../");
};



# create request class
$request = new \Iyzipay\Request\CreateCheckoutFormInitializeRequest();
$request->setLocale(\Iyzipay\Model\Locale::TR);
//$request->setConversationId("123456789");



switch ($ayricalikturu) {
                                    case '1':
 
 $request->setPrice('99');                                  
$request->setPaidPrice("99");
                                        break;

                                         case '2':
                                     
                             $request->setPrice('449');
                                $request->setPaidPrice("449");
                                        break;

                                         case '3':
                                  $request->setPrice('699');
                               $request->setPaidPrice("699");
                                        break;
                                    
                                  
                                        
                                    
                                };

$request->setCurrency(\Iyzipay\Model\Currency::TL);
//$request->setBasketId("B67832");
$request->setPaymentGroup(\Iyzipay\Model\PaymentGroup::SUBSCRIPTION);


switch ($ayricalikturu) {
    
                                    case '1':
 
                                    
        $request->setCallbackUrl("https://www.egitmenkampi.com/iyzipay/samples/odemesonucu?preType=1");
$request->setEnabledInstallments(array(1));
                                        break;

                                         case '2':
                                     
                            
                               $request->setCallbackUrl("https://www.egitmenkampi.com/iyzipay/samples/odemesonucu?preType=2");
                               $request->setEnabledInstallments(array(2, 3, 6));
                                        break;

                                         case '3':
                                 
                               $request->setCallbackUrl("https://www.egitmenkampi.com/iyzipay/samples/odemesonucu?preType=3");
                               $request->setEnabledInstallments(array(2, 3, 6, 9,12));
                                        break;
                                    
                                  
                                        
                                    
                                };


$buyer = new \Iyzipay\Model\Buyer();
$buyer->setId($_SESSION['kullanici_id']);
$buyer->setName($kullanicioturumcek['kullanici_ad']);
$buyer->setSurname($kullanicioturumcek['kullanici_soyad']);
//$buyer->setGsmNumber("+905350000000");
$buyer->setEmail($kullanicioturumcek['kullanici_mail']);
$buyer->setIdentityNumber("12345678900");
//$buyer->setLastLoginDate("2015-10-05 12:43:35");
//$buyer->setRegistrationDate("2013-04-21 15:12:09");
$buyer->setRegistrationAddress("Atatürk mah. 431.sok. gökmen2 apt. daire 14.");
$buyer->setIp($ipAdres);
$buyer->setCity($sehircek['sehir_ad']);
$buyer->setCountry("Turkey");
//$buyer->setZipCode("34732");
$request->setBuyer($buyer);

$shippingAddress = new \Iyzipay\Model\Address();
$shippingAddress->setContactName("Jane Doe");
$shippingAddress->setCity("Istanbul");
$shippingAddress->setCountry("Turkey");
$shippingAddress->setAddress("Nidakule Göztepe, Merdivenköy Mah. Bora Sok. No:1");
$shippingAddress->setZipCode("34742");
$request->setShippingAddress($shippingAddress);

$billingAddress = new \Iyzipay\Model\Address();
$billingAddress->setContactName($kullanicioturumcek['kullanici_ad']." ".$kullanicioturumcek['kullanici_soyad']);
$billingAddress->setCity($sehircek['sehir_ad']);
$billingAddress->setCountry("Turkey");
$billingAddress->setAddress("atatürk mah. 431.sok gökmen2 apt. daire 14");
$billingAddress->setZipCode("34742");
$request->setBillingAddress($billingAddress);

$basketItems = array();
$firstBasketItem = new \Iyzipay\Model\BasketItem();
$firstBasketItem->setId("BI101");
$firstBasketItem->setName("Binocular");
$firstBasketItem->setCategory1("Collectibles");
$firstBasketItem->setCategory2("Accessories");
$firstBasketItem->setItemType(\Iyzipay\Model\BasketItemType::VIRTUAL);
switch ($ayricalikturu) {
                                    case '1':
 $firstBasketItem->setPrice("97");

                                        break;

                                         case '2':
                                             
                                             $firstBasketItem->setPrice("447");
                                     
                             
                                        break;

                                         case '3':
                                             $firstBasketItem->setPrice("697");
                                 
                                        break;
                                    
                                  
                                        
                                    
                                };

$basketItems[0] = $firstBasketItem;

$secondBasketItem = new \Iyzipay\Model\BasketItem();
$secondBasketItem->setId("BI102");
$secondBasketItem->setName("Game code");
$secondBasketItem->setCategory1("Game");
$secondBasketItem->setCategory2("Online Game Items");
$secondBasketItem->setItemType(\Iyzipay\Model\BasketItemType::VIRTUAL);
$secondBasketItem->setPrice("1");
$basketItems[1] = $secondBasketItem;

$thirdBasketItem = new \Iyzipay\Model\BasketItem();
$thirdBasketItem->setId("BI103");
$thirdBasketItem->setName("Usb");
$thirdBasketItem->setCategory1("Electronics");
$thirdBasketItem->setCategory2("Usb / Cable");
$thirdBasketItem->setItemType(\Iyzipay\Model\BasketItemType::VIRTUAL);
$thirdBasketItem->setPrice("1");
$basketItems[2] = $thirdBasketItem;
$request->setBasketItems($basketItems);

# make request
$checkoutFormInitialize = \Iyzipay\Model\CheckoutFormInitialize::create($request, Config::options());

# print result
print_r($checkoutFormInitialize->getCheckoutFormContent());
?>

<html>
    
    <body>
        
        <div id="iyzipay-checkout-form" class="popup"></div>
    </body>
    
</html>