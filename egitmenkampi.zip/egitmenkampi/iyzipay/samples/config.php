<?php

require_once(dirname(__DIR__).'/IyzipayBootstrap.php');

IyzipayBootstrap::init();

class Config
{
    public static function options()
    {
        $options = new \Iyzipay\Options();
        $options->setApiKey('ntHz13SnmgULjax0dlB968vZVCBPbYTJ');
        $options->setSecretKey('a9F2UOchxK6u1Iv43HoD6SVygBmvC0kn');
        $options->setBaseUrl('https://api.iyzipay.com');

        return $options;
    }
}