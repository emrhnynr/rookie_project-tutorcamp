
                                            
            <?php require_once 'header.php'; 

            if ($kullanicioturumcek['kullanici_onecikan']!=1) {
                 header("Location:index");
                 
             } ?>

             <head>

            <title>Ayrıcalıklı Üyeliğim</title>

             <style type="text/css">
                
                @media only screen and (max-width: 991px){

  .tablepc {


    display: none;
  }
}

@media only screen and (min-width: 992px){

  .tablemobil {


    display: none;
  }
}
            </style> 

            </head>

            <div class="pagination-area bg-secondary">
                <div class="container">
                    <div class="pagination-wrapper">
                        <ul>
                            <li><a href="index">Anasayfa</a><span> -</span></li>
                            <li>Ayrıcalıklı Üyeliğim</li>
                        </ul>
                    </div>
                </div>  
            </div> 
            <!-- Inner Page Banner Area End Here -->          
            <!-- Sales Statement Page Start Here -->
            <div class="sales-statement-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <h2 class="title-section">Ayrıcalıklı Üyelik Detayları</h2>
                    <div class="sales-statement-wrapper inner-page-padding">

                      <?php if ($_GET['payStatus']=="success") { ?>
                          <div class="alert alert-success"><i class="fas fa-check"></i> <b>Ayrıcalıklı üyeliğiniz aktif edildi!</b> <a href="oneriler">Öneriler</a> kısmından profilinizi mükemmel hale getirecek önerilere göz atabilirsiniz. Ayrıca aşağıdaki numaradan bizimle iletişime geçebilirsiniz.</div>
                  <?php    } ?>  

                  <h4 align="center"><a href="tel:05551636605"><i style="color: green;" class="fas fa-phone"></i> 0 (555) 163 66 05</a></h4>
                        
                        <div class="table-responsive">
                            <table class="table table-striped tablepc">
                                <thead>
                                    <tr>
                                 
                                     <th style="border-right: 1px solid #ffffff; text-align: center;">Ayrıcalık Türü</th>
                                    <th  style="border-right: 1px solid #ffffff; text-align: center;">Üyelik Başlangıç Tarihi</th>
                                    <th style="border-right: 1px solid #ffffff; text-align: center;">Üyelik Bitiş Tarihi</th>
                                    <th style="border-right: 1px solid #ffffff; text-align: center;">Kalan Gün Sayısı</th>
                                   
                                
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                        <?php $premium_baslangic=$kullanicioturumcek['premium_baslangic'];
                                        $premium_bitis=$kullanicioturumcek['premium_bitis'];
                                        $premium_turu=$kullanicioturumcek['premium_turu'];
                                      $premium_baslangicay= substr($premium_baslangic,3,2);
                                       $premium_bitisay= substr($premium_bitis,3,2);

                                       

                                         ?>

                                         <td style="text-align: center;"><?php switch ($premium_turu) {
                                             case '1':
                                                 echo "1 Aylık";
                                                 break;

                                                 case '2':
                                                 echo "6 Aylık";
                                                 break;

                                                 case '3':
                                                 echo "12 Aylık";
                                                 break;

                                                 case '4':
                                                 echo "7 Günlük Ücretsiz";
                                             
                                             
                                         } ?></td>
                                        
                                        
                                        <td style="text-align: center;"><?php switch ($premium_baslangicay) {
                                            case '01':
                                                echo substr($premium_baslangic,0,2)." Ocak ".substr($premium_baslangic, 6,4);
                                                break;
                                            
                                             case '02':
                                                echo substr($premium_baslangic,0,2)." Şubat ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '03':
                                                echo substr($premium_baslangic,0,2)." Mart ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '04':
                                                echo substr($premium_baslangic,0,2)." Nisan ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '05':
                                                echo substr($premium_baslangic,0,2)." Mayıs ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '06':
                                                echo substr($premium_baslangic,0,2)." Haziran ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '07':
                                                echo substr($premium_baslangic,0,2)." Temmuz ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '08':
                                                echo substr($premium_baslangic,0,2)." Ağustos ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '09':
                                                echo substr($premium_baslangic,0,2)." Eylül ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '10':
                                                echo substr($premium_baslangic,0,2)." Ekim ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '11':
                                                echo substr($premium_baslangic,0,2)." Kasım ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '12':
                                                echo substr($premium_baslangic,0,2)." Aralık ".substr($premium_baslangic, 6,4);
                                                break;
                                        } ?>, <?php echo substr($premium_baslangic, 10,6) ?></td>
                                           <td style="text-align: center;"><?php switch ($premium_bitisay) {
                                            case '01':
                                                echo substr($premium_bitis,0,2)." Ocak ".substr($premium_bitis, 6,4);
                                                break;
                                            
                                             case '02':
                                                echo substr($premium_bitis,0,2)." Şubat ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '03':
                                                echo substr($premium_bitis,0,2)." Mart ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '04':
                                                echo substr($premium_bitis,0,2)." Nisan ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '05':
                                                echo substr($premium_bitis,0,2)." Mayıs ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '06':
                                                echo substr($premium_bitis,0,2)." Haziran ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '07':
                                                echo substr($premium_bitis,0,2)." Temmuz ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '08':
                                                echo substr($premium_bitis,0,2)." Ağustos ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '09':
                                                echo substr($premium_bitis,0,2)." Eylül ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '10':
                                                echo substr($premium_bitis,0,2)." Ekim ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '11':
                                                echo substr($premium_bitis,0,2)." Kasım ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '12':
                                                echo substr($premium_bitis,0,2)." Aralık ".substr($premium_bitis, 6,4);
                                                break;
                                        } ?>, <?php echo substr($premium_bitis, 10,6) ?></td>
                                        <td style="text-align: center;"><?php  echo ceil((strtotime($premium_bitis)-time())/86400); ?></td>
            
                                   
                                    </tr>
                                    
                                </tbody>
                            </table>



                                          <table class="table table-striped tablemobil">
                                <thead>
                                    <tr>
                                 
                                
                                    <th  style=" text-align: center;">Ayrıcalık Türü</th>

                                    
                                    
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                        
                                        
                                        <td style="text-align: center;"><?php switch ($premium_turu) {
                                             case '1':
                                                 echo "1 Aylık";
                                                 break;

                                                 case '2':
                                                 echo "6 Aylık";
                                                 break;

                                                 case '3':
                                                 echo "12 Aylık";
                                                 break;

                                                 case '4':
                                                 echo "7 Günlük Ücretsiz";
                                             
                                             
                                         } ?></td>
                                          
                                        
                                   
                                    </tr>
                                    
                                </tbody>
                            </table>
                            

                             <table class="table table-striped tablemobil">
                                <thead>
                                    <tr>
                                 
                                
                                    <th  style=" text-align: center;">Üyelik Başlangıç Tarihi</th>
                                    
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                        
                                        
                                        <td style="text-align: center;"><?php switch ($premium_baslangicay) {
                                            case '01':
                                                echo substr($premium_baslangic,0,2)." Ocak ".substr($premium_baslangic, 6,4);
                                                break;
                                            
                                             case '02':
                                                echo substr($premium_baslangic,0,2)." Şubat ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '03':
                                                echo substr($premium_baslangic,0,2)." Mart ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '04':
                                                echo substr($premium_baslangic,0,2)." Nisan ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '05':
                                                echo substr($premium_baslangic,0,2)." Mayıs ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '06':
                                                echo substr($premium_baslangic,0,2)." Haziran ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '07':
                                                echo substr($premium_baslangic,0,2)." Temmuz ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '08':
                                                echo substr($premium_baslangic,0,2)." Ağustos ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '09':
                                                echo substr($premium_baslangic,0,2)." Eylül ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '10':
                                                echo substr($premium_baslangic,0,2)." Ekim ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '11':
                                                echo substr($premium_baslangic,0,2)." Kasım ".substr($premium_baslangic, 6,4);
                                                break;

                                                 case '12':
                                                echo substr($premium_baslangic,0,2)." Aralık ".substr($premium_baslangic, 6,4);
                                                break;
                                        } ?>, <?php echo substr($premium_baslangic, 10,6) ?></td>
                                          
                                        
                                   
                                    </tr>
                                    
                                </tbody>
                            </table>
                             <table class="table table-striped tablemobil">
                                <thead>
                                    <tr>
                                 
                                
                                 
                                    <th style="border-right: 1px solid #ffffff; text-align: center;">Üyelik Bitiş Tarihi</th>
                                    
                                    
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                    
                                        
                                       
                                           <td style="text-align: center;"><?php switch ($premium_bitisay) {
                                            case '01':
                                                echo substr($premium_bitis,0,2)." Ocak ".substr($premium_bitis, 6,4);
                                                break;
                                            
                                             case '02':
                                                echo substr($premium_bitis,0,2)." Şubat ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '03':
                                                echo substr($premium_bitis,0,2)." Mart ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '04':
                                                echo substr($premium_bitis,0,2)." Nisan ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '05':
                                                echo substr($premium_bitis,0,2)." Mayıs ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '06':
                                                echo substr($premium_bitis,0,2)." Haziran ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '07':
                                                echo substr($premium_bitis,0,2)." Temmuz ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '08':
                                                echo substr($premium_bitis,0,2)." Ağustos ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '09':
                                                echo substr($premium_bitis,0,2)." Eylül ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '10':
                                                echo substr($premium_bitis,0,2)." Ekim ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '11':
                                                echo substr($premium_bitis,0,2)." Kasım ".substr($premium_bitis, 6,4);
                                                break;

                                                 case '12':
                                                echo substr($premium_bitis,0,2)." Aralık ".substr($premium_bitis, 6,4);
                                                break;
                                        } ?>, <?php echo substr($premium_bitis, 10,6) ?></td>
                                        
                                   
                                    </tr>
                                    
                                </tbody>
                            </table>

                             <table class="table table-striped tablemobil">
                                <thead>
                                    <tr>
                                 
                                
                                    
                                    <th style="border-right: 1px solid #ffffff; text-align: center;">Kalan Gün Sayısı</th>
                                   
                                   
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                      
                                        
                                       
                                        <td style="text-align: center;"><?php  echo ceil((strtotime($premium_bitis)-time())/86400); ?></td>
                                        
                                   
                                    </tr>
                                    
                                </tbody>
                            </table>

                        



                        </div>

                    
                     
                       
                    </div> 
                </div> 
            </div> 
            
            <?php require_once 'footer.php'; ?>