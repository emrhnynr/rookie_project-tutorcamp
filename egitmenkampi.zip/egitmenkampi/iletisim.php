
            <?php   require_once 'header.php'; ?>   


            <head>
  
<title>İletişim | EğitmenKampı</title>

</head>














          
            <div class="contact-us-info-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="contact-us-left">
                                <h2>İletişim Bilgileri</h2>      
                                <ul>
                                    <li>
                                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                                        <h3 class="title-bar-medium-left">Ofis</h3>
                                        <p><?php echo $anaayarcek['ayar_adres']; ?></p> 
                                    </li>
                                   
                                    <li>
                                        <i class="fas fa-envelope"></i>
                                        <h3 class="title-bar-medium-left">E-mail</h3>
                                        <p><?php echo $anaayarcek['ayar_mail']; ?></p>   
                                    </li>      
                                </ul>
                            </div>  
                        </div>  
                        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                            <div class="contact-us-right"> 
                                <h3 class="title-bar-medium-left">Soru ve Görüşler</h3>
                                <br>    
                                <div class="contact-form"> 


                                    <?php if (@$_GET['mesajgonder']=="ok") { ?>

                                        <div class="alert alert-success"><i class="fas fa-check"></i> <b>İşlem Başarılı!</b> Mesajınız Tarafımıza Başarıyla İletilmiştir,Teşekkür Ederiz!</div>


                                        
                                 <?php   } else if(@$_GET['mesajgonder']=="hata") { ?>

                                    <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Mesajınız İletilemedi.</div>


                              <?php  } else if(@$_GET['mesajgonder']=="hatalikod"){ ?>

                                <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen Güvenlik Kodunu Doğru Giriniz.</div>


                            <?php  } ?>

                              


                                    <form action="phpmailer/iletisimgonder.php" method="POST" id="contact-form">
                                        <fieldset>
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <input type="text" placeholder="Ad ve Soyad*" class="form-control" maxlength="51" name="kullanici_adsoyad" id="form-name" data-error="Bu alanı doldurmanız zorunludur." required="">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>

                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <input type="email" placeholder="E-Mail*" class="form-control" name="kullanici_mail" id="form-mail" data-error="Bu alanı doldurmanız zorunludur." maxlength="100" required="">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                
                                                 <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <input type="text" placeholder="Konu*" class="form-control" name="kullanici_konu" id="form-subject" data-error="Bu alanı doldurmanız zorunludur." maxlength="100" required="">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <textarea placeholder="Mesajınız*" maxlength="5000" class="textarea form-control" name="kullanici_metin" id="form-message" rows="7" cols="20" data-error="Bu alanı doldurmanız zorunludur." required=""></textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>


                                                 <div   class="col-sm-4">
                                                    <div class="form-group">
                                                        
                                                        <img id="captcha" src="securimage/securimage_show.php">
                                                    </div>
                                                </div>

                                                 <div align="left" style="height: 110px;"  class="col-sm-8">
                                                    <div class="form-group">
                                                        <input type="text" placeholder="Güvenlik Kodunu Giriniz*" class="form-control" name="captcha_code" id="form-mail" data-error="Bu alanı doldurmanız zorunludur." maxlength="10" required="">
                                                        <div class="help-block with-errors"></div>
                                                    </div>

                                                </div>
                                                <div class="col-lg-4 col-md-4 col-sm-6 col-sm-12">
                                                    <div class="form-group margin-bottom-none">
                                                        <button type="submit" name="mailgonder" class="update-btn">Gönder</button>
                                                    </div>
                                                </div>
                                                <div class="col-lg-8 col-md-8 col-sm-6 col-sm-12">
                                                    <div class='form-response'></div>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          <?php     require_once 'footer.php'; ?>
           <script type="text/javascript">
             
             $(document).ready(function() {
  $('#contact-form').submit(function() {



    if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };






  });


});

           </script>