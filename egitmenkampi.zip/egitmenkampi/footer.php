<!-- Footer Area Start Here -->
<footer>
    <div class="footer-area-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-box">
                        <h3 class="title-bar-left title-bar-footer">Bize Ulaşın </h3>
                        <ul class="corporate-address">
                            <li><i class="fa fa-map-marker" aria-hidden="true"></i><?php echo @$anaayarcek['ayar_adres']; ?></li>
                            <li><i class="fas fa-envelope"></i><?php echo @$anaayarcek['ayar_mail'] ?></li>
                          
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-box">
                        <h3 class="title-bar-left title-bar-footer">Topluluğumuza Katılın </h3>
                        <ul class="featured-links">
                            <li>
                                <ul>
                                    <li><a href="index.php">Anasayfa</a></li>
                                    <li><a href="egitmenkayit.php">Eğitmen Ol</a></li>
                                    <li><a href="blog.php">Blog</a></li>
                                </ul>
                            </li>
                        </ul> 
                    </div>
                </div>
                <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12">
                    <div class="footer-box">
                        <h3 class="title-bar-left title-bar-footer">Yardımcı olalım</h3>
                        <ul class="featured-links">
                            <li>
                                <ul>
                                    <li><a href="iletisim.php">İletişime Geç</a></li>
                                    <li><a href="topluluk-kurallari.php">Topluluk Kuralları</a></li>
                                    <li><a href="gizlilik.php">Gizlilik</a></li>
               

                                      <?php if ($kullanicioturumcek['kullanici_yetki']==1) { ?>

                                          <li><a href="mesafeli-satis-sozlesmesi">Mesafeli Satış Sözleşmesi</a></li>
                                          


                                 <?php     } ?>
                                        
                       
                                </ul>
                            </li>
                        </ul> 
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <div class="footer-area-bottom">
        <div class="container">
            <p>Telif Hakları © 2019 - 2020 Tüm Hakları Saklıdır.</p>
            <img style="height: 30px;width: 80px;"  src="dimg/visamastercard.png">
        </div>
    </div>
</footer>
<!-- Footer Area End Here -->
</div>
<!-- Main Body Area End Here -->
<script type="text/javascript">
    $('#carpi').click(function(){
        $('#ustbilgikutu').slideUp(400);
    })
   
    $(document).ready(function() {
        $("body").tooltip({ selector: '[data-toggle=tooltip]' });
    });
    $(document).ready(function () {
        $("a#cikisyap").one("click", function() {
            $(this).click(function () { return false; });
        });
    });
</script>
</body>
</html>
<!-- Plugins js -->
<script src="js\plugins.js" type="text/javascript"></script>
<!-- Bootstrap js -->
<script src="js\bootstrap.min.js" type="text/javascript"></script>
<!-- WOW JS -->     
<script src="js\wow.min.js"></script>
<!-- Owl Cauosel JS -->
<script src="vendor\OwlCarousel\owl.carousel.min.js" type="text/javascript"></script>
<!-- Meanmenu Js -->
<script src="js\jquery.meanmenu.min.js" type="text/javascript"></script>
<!-- Srollup js -->
<script src="js\jquery.scrollUp.min.js" type="text/javascript"></script>
<!-- Select2 Js -->
<script src="js\select2.min.js" type="text/javascript"></script>
<!-- jquery.counterup js -->
<script src="js\jquery.counterup.min.js"></script>
<script src="js\waypoints.min.js"></script>
<!-- Isotope js -->
<script src="js\isotope.pkgd.min.js" type="text/javascript"></script>
<!-- Gridrotator js -->
<script src="js\jquery.gridrotator.js" type="text/javascript"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!-- Custom Js -->
<script src="js\main.js" type="text/javascript"></script>
<!-- Nouislider Js -->
<script src="vendor\noUiSlider\nouislider.min.js" type="text/javascript"></script>
