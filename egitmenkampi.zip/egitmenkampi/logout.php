
<?php 

session_start();

if (empty($_SESSION['kullanicioturum'])) {
	
	Header("Location:index");
};


$kullanici_id=$_GET['kullanici_id'];



	
	unset($_SESSION['kullanicioturum']);
unset($_SESSION['kullanici_id']);

Header("Location:index");






 ?>