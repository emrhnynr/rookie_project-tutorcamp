﻿

<?php require_once 'header.php'; ?>


<head>
    <title>Hata - 404</title>

</head>
  
            <div class="page-error-area bg-secondary section-space-bottom">
                <div class="container">
                    
                    <div class="page-error-top">
                        <img src="img\404.png" alt="404" class="img-responsive">
                        <p>Üzgünüz,Aradığınız Sayfayı Bulamadık</p>
                        <div class="page-error-bottom">
                            <p>Aradığınız sayfa kaldırılmış veya yanlış girilmiş olabilir.</p>
                            <p>Anasayfaya dönüp istediğiniz gibi sayfamızda dolaşmaya devam edebilirsiniz.</p>
                            <a href="index.php" class="default-btn">Anasayfaya Dön</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php require_once 'footer.php'; ?>