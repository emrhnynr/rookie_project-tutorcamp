<?php require_once 'header.php'; ?>

<head>
	
	<title>Profil Fotoğrafı - Eğitmenkampı</title>


</head>

<?php if ($kullanicioturumcek['kullanici_yetki']==2) {
	
header("Location:404");

}; ?>

 <div class="help-page-area bg-secondary section-space-bottom">
                <div class="container">
                    
                    <div class="inner-page-details inner-page-padding"> 
                        




                                    
                                        <?php if (@$_GET['fotoupdatedurum']=="buyukdosya") { ?>
                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Dosyanızın boyutu 3 MB'ı geçemez.</div>
                                      <?php  } else if(@$_GET['fotoupdatedurum']=="izinsizuzanti"){ ?>


                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Yalnızca .jpg ve .png uzantılı dosyalarınızı kaydedebilirsiniz. (Resim isminde . varsa kaydolmaz,kontrol ediniz.)</div>



                                   <?php   } else if(@$_GET['fotoupdatedurum']=="no"){ ?>

                                     <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Dosya yüklenirken bir hata oluştu.</div>



                                  <?php } else if(@$_GET['fotoupdatedurum']=="ok"){ ?>


                                    <div class="alert alert-success"><i class="fas fa-check"></i> <b>İşlem Başarılı</b>, Profil Fotoğrafınız Editör Onayından Hızlıca Geçtikten Sonra Yayınlanacaktır.</div>



                                  <?php } else if(@$_GET['deletep']=="ok"){ ?>

                                    <div class="alert alert-success"><i class="fas fa-check"></i> Fotoğrafınız Kaldırıldı!</div>


                                 <?php } else if(@$_GET['deletep']=="no"){ ?>


                                    <div class="alert alert-danger"><i class="fas fa-check"></i> Fotoğrafınız Kaldırılamadı.</div>



                               <?php  } ?>
                                        <h3 class="title-section">Profil Fotoğrafım</h3>
                                        <div class="public-profile inner-page-padding"> 

                                            <form action="nedmin/production/netting/musteriislem.php" style="margin-top:60px;"  method="POST" enctype="multipart/form-data"  data-parsley-validate class="form-horizontal form-label-left formaise">
                                           
                                            <div  class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Yüklü Fotoğraf</label>
                  <div  class="col-md-6 col-sm-6 col-xs-12">



                  <?php if (!empty($kullanicioturumcek['kullanici_resim'])) { ?>


                                                             <img style="width: 100px;height:100px;" class="img-responsive img-circle" src="<?php echo $kullanicioturumcek['kullanici_resim']; ?>">
                                                            

                                                      <?php  } else {


                                                        if ($kullanicioturumcek['kullanici_yetki']=="0") {


                                                            if (empty($kullanicioturumcek['kullanici_cinsiyet'])) { ?>


                                                                <img style="width: 100px;height:100px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">


                                                                

                                                          <?php  } else if ($kullanicioturumcek['kullanici_cinsiyet']=="1") { ?>

                                                             <img style="width: 100px;height: 100px;" class="img-responsive img-circle" src="dimg/3.jpg">
                                                                

                                                           <?php } else if($kullanicioturumcek['kullanici_cinsiyet']=="2"){ ?>


                                                             <img style="width: 100px;height: 100px;" class="img-responsive img-circle" src="dimg/5.jpg">


                                                           <?php }

                                                            

                                                        } else if($kullanicioturumcek['kullanici_yetki']=="1" or $kullanicioturumcek['kullanici_yetki']==3){


                                                            if ($kullanicioturumcek['kullanici_cinsiyet']=="1") { ?>


                                                                 <img style="width: 100px;height: 100px;" class="img-responsive img-circle" src="dimg/9.jpg">
                                                              

                                                          <?php  } else { ?>


                                                            <img style="width: 100px;height: 100px;" class="img-responsive img-circle" src="dimg/11.jpg">



                                                        <?php  }





                                                        }




                                                      } ?>

                                                      <?php     if (!empty($kullanicioturumcek['kullanici_resim'])) { ?>


                                                         <a style="color:red;" data-toggle='modal' href="#fotokaldir"><i style="color:red;" class="fas fa-trash"></i> Fotoğrafı Kaldır</a>
                                                         
                                                     <?php } ?>


                                                    

                                                     

                    
                  </div>



                </div>

                 <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Fotoğraf Seç
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="file" id="first-name" required=""  name="kullanici_resim"  class="form-control col-md-7 col-xs-12">
                  </div>
                </div>

                




                <input type="hidden" name="eski_yol" value="<?php echo $kullanicioturumcek['kullanici_resim']; ?>">

               

                <div  align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                   
                  <button  type="submit" name="profilfotoguncelle" class="update-btn">Güncelle</button>
                </div>

                <br><br><br><br>

            </form>
                                            
                                            
                                            
                                        </div> 

                                        <div class="modal fade" id="fotokaldir"> 

  <div   class="modal-dialog modal-lg">
    <div  class="col-md-3 modal-content">
        <a class="close" data-dismiss="modal" href=""><span>&times;</span></a>
      





    <h4>Profil Fotoğrafınızı kaldırmak istediğinize emin misiniz?</h4>
  







<div class="modal-footer">
  
  <a id="profilfotosil2" href="nedmin/production/netting/musteriislem.php?profilfotosil=ok"><button class="btn btn-success btn-xs">Evet</button></a>
    <button class="btn btn-danger btn-xs" data-dismiss="modal">İptal</button>
</div>
    </div>

  </div>



</div>
                                    


                    </div>  
                </div>  
            </div> 






<?php require_once 'footer.php'; ?>
<script type="text/javascript">
  $(document).ready(function() {
  $('.formaise').submit(function() {



    if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };






  });


});

</script>