<?php require_once 'header.php'; ?>



<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!-- Header Area Start Here -->

<head>
  <title>Özel Ders - Eğitmeninizi Bulun, Seviye Atlayın ! - Eğitmen Kampı</title>
</head>
<style type="text/css">

.product-details-tab-area .product-details-title {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-flex;
    display: -ms-flex;
    display: -o-flex;
    display: flex;
    text-align: center;
    border: 1px solid #dfdfdf;
  }
  @media only screen and (max-width: 500px) {
    .product-details-tab-area .product-details-title {
      display: inherit;
    }
  }
  .product-details-tab-area .product-details-title li {
    -webkit-box-flex: 1;
    -moz-flex: 1;
    -webkit-flex: 1;
    flex: 1;
    position: relative;
    border-right: 1px solid #dfdfdf;
    -webkit-transition: all 0.5s ease-out;
    -moz-transition: all 0.5s ease-out;
    -ms-transition: all 0.5s ease-out;
    -o-transition: all 0.5s ease-out;
    transition: all 0.5s ease-out;
    background-color: white;
  }

   .product-details-tab-area .product-details-title .active {
    background-color: #8bc34a;
  }
  @media only screen and (max-width: 500px) {
    .product-details-tab-area .product-details-title li {
      border-right: none;
      border-bottom: 1px solid #dfdfdf;
    }
  }
  .product-details-tab-area .product-details-title li:last-child {
    border-right: none;
    border-bottom: none;
  }
  .product-details-tab-area .product-details-title li:before {
    content: "";
    height: 3px;
    width: 100%;
    background: #8bc34a;
    position: absolute;
    z-index: 1;
    bottom: 0;
    left: 0;
    right: 0;
    margin: 0 auto;
    opacity: 0;
    visibility: hidden;
  }
  .product-details-tab-area .product-details-title li a {
    font-size: 16px;
    display: block;
    width: 100%;
    color: #70838d;
    padding: 17px 0;
    text-transform: capitalize;
    -webkit-transition: all 0.5s ease-out;
    -moz-transition: all 0.5s ease-out;
    -ms-transition: all 0.5s ease-out;
    -o-transition: all 0.5s ease-out;
    transition: all 0.5s ease-out;
  }
  @media only screen and (max-width: 479px) {
    .product-details-tab-area .product-details-title li a {
      display: block!important;
    }
  }
 
  .product-details-tab-area .product-details-title .active a {
    color: white;
    text-decoration: none;
  }
  .product-details-tab-area .product-details-title .active:before {
    opacity: 1;
    visibility: visible;
  }
  
  
  }



.update-btn2 {
    height: 35px;
    text-align: center;
    color: #ffffff;
    padding-left:6px;
    padding-right:6px;
    background: #e74c3c;
    text-transform: capitalize;
    font-size: 15px;
    font-weight: 500;
    display: inline-block;
    border: 2px solid #e74c3c;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
  }

@media screen and (min-width: 992px){

.item-content {

  height: 260px;
}



}





  .filtrele {
    padding: 10px;
    width: 90%;
    margin: 0 auto 40px;
  }
  .update-btnn {
    height: 35px;
    text-align: center;
    color: #8bc34a;
    padding-left:6px;
    padding-right:6px;
    background: #ffffff;
    text-transform: capitalize;
    font-size: 15px;
    font-weight: 500;
    display: inline-block;
    border: 2px solid #8bc34a;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
  }


  .update-btnn:hover {

text-decoration: underline;

  }
</style>


<div id="kategori"> 
<!-- <head>
<style type="text/css">
.kategorikutu {
-webkit-transition: all 0.2s ease-out;
-moz-transition: all 0.2s ease-out;
-ms-transition: all 0.2s ease-out;
-o-transition: all 0.2s ease-out;
transition: all 0.2s ease-out;
}
.kategorikutu:hover{
border:2.5px solid white;
}
</style>
</head> -->
<div class="container">
  <?php if ($kullanicioturumcek['kullanici_yetki']==2) { ?>
    
     <?php if ($egitmenkategoritestsay==0) {
      
      header("Location:kayittamamla");
    } else {

      header("Location:kayittamamla2");
    } ?>
    
      <?php } else if($kullanicioturumcek['kullanici_yetki']==3){ ?>
        <div align="center" class="col-md-12" style="margin-top:15px;padding-top:15px;background-color:#8AE5F9;border-left:4px solid #0615FD;">
        <p><b><i class="fas fa-info-circle"></i> </b>Girdiğiniz bilgiler uygun görüldüğü takdirde hesabınız hızlıca onaylanıp mail adresinize bilgi mesajı yollanacaktır.<b>Teşekkür ederiz !</b><br><a style="font-size:17px;" href="fotografim">• Profil Fotoğrafı Yükle</a><br>
          <a style="font-size:17px;" href="sertifikalarim">• Sertifika Yükle</a></p>
      </div>
    <?php } else if($kullanicioturumcek['kullanici_yetki']==1 and $kullanicioturumcek['kullanici_onecikan']!=1 and ($kullanicioturumcek['kullanici_il']==35 or $kullanicioturumcek['kullanici_il']==36)){ ?>


<div class="alert alert-warning">
  <h4 style="font-size: 17.5px;" align="center"><i class="fas fa-info-circle"></i> Aşağıdaki bilgileriniz yayınlanmıyor</h4>
  <ul>
    <li style="text-align: center;">● Sertifika Sahibi Olduğunuz</li>
    <li style="text-align: center;">● Telefon Numaranız</li>
   <li style="text-align: center;">● Size Yapılan Yorumlar</li>
   <hr>
    <li style="text-align: center;">Bu bilgilerin yayınlanması için <a href="odeme-planlari">tıklayın</a></li>
  </ul>
</div>

  <?php  } ?>
    <br>
    <h3 id="baslik" class="title-default" align="center">Alanını Seç, Hızlıca Özel Ders Eğitmenini Bul !</h3>
   <!-- <a href="online-ders-verenler" class="onlinebuton" href="online-ders-verenler"><i class="fas fa-globe-europe"></i> Online Ders Verenler</a> -->




   
<!--

Filtreleme seçenekleri buraya gelecek.

 -->

  <div class="product-details-tab-area">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12 col-sm-12">
                                            <ul class="product-details-title">
                                                <li  class="active"><a href="#ilkokultakviye" data-toggle="tab" aria-expanded="false"><i class="fas fa-child"></i> İlkokul Takviye</a></li>
                                                <li ><a href="#ortaokultakviye" data-toggle="tab" aria-expanded="false"><i class="fas fa-school"></i> Ortaokul Takviye</a></li>
                                                <li ><a href="#lisetakviye" data-toggle="tab" aria-expanded="false"><i class="fas fa-graduation-cap"></i> Lise Takviye</a></li>

                                              
                                            </ul>
                                        </div>
                                        <div style="margin-top:20px;" class="col-lg-12 col-md-12 col-sm-12">
                                            <div class="tab-content">
                                                 <div class="row  tab-pane animated flipInX active in" id="ilkokultakviye">




        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-matematik-ilkokul-162"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(43, 59, 253,0.9);" class="kategorikutu kategorisira1">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-divide"></i><br> <span>Matematik</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-turkce-ilkokul-183"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(251, 30, 8,0.9);" class="kategorikutu kategorisira2">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-book"></i><br> <span>Türkçe</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-hayat-bilgisi-184"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(132, 109, 25 ,0.9);" class="kategorikutu kategorisira3">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chalkboard-teacher"></i><br> <span>Hayat Bilgisi</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-okuma-yazma-185"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(227, 18, 132,0.9);" class="kategorikutu kategorisira4">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-book-reader"></i><br> <span>Okuma Yazma</span> </i> 
            </div>

          </div></a>
        </div>

          <div id="kutucuuk" class="col-md-2"> 
          <a href="c-ingilizce-ilkokul-168"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(158, 65, 116,0.9);" class="kategorikutu kategorisira5">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chalkboard-teacher"></i><br> <span>İngilizce</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-fen-bilgisi-ilkokul-154"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(250, 156, 11,0.9);" class="kategorikutu kategorisira6">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-atom"></i><br> <span>Fen Bilgisi</span> </i> 
            </div>

          </div></a>
        </div>

       

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-din-kulturu-ve-ahlak-bilgisi-148"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(116, 227, 18,0.9);" class="kategorikutu kategorisira7">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-mosque"></i><br> <span>Din Kültürü</span> </i> 
            </div>

          </div></a>
        </div>

           <div id="kutucuuk" class="col-md-2"> 
          <a href="c-resim-78"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(146, 17, 191 ,0.9);" class="kategorikutu kategorisira8">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-paint-brush"></i><br> <span>Resim</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-muzik-85"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(191, 17, 41 ,0.9);" class="kategorikutu kategorisira9">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-guitar"></i><br> <span>Müzik</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-yuzme-44"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(18, 192, 2270.9);" class="kategorikutu kategorisira10">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-swimmer"></i><br> <span>Yüzme</span> </i> 
            </div>

          </div></a>
        </div>


          <div id="kutucuuk" class="col-md-2"> 
          <a href="c-satranc-170"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(191, 38, 17 ,0.9);" class="kategorikutu kategorisira11">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chess-queen"></i><br> <span>Satranç</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-yazilim-99"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(53, 52, 45,0.9);" class="kategorikutu kategorisira12">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-laptop-code"></i><br> <span>Yazılım</span> </i> 
            </div>

          </div></a>
        </div>

        


         

    
    </div>      

    
<h3 align="center">Faktoriyel Oluşturma<hr></h3>






     <div class="row animated bounceIn tab-pane" id="ortaokultakviye">




        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-matematik-ortaokul-181"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(43, 59, 253,0.9);" class="kategorikutu kategorisira1">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-square-root-alt"></i><br> <span>Matematik</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-turkce-ortaokul-182"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(251, 30, 8,0.9);" class="kategorikutu kategorisira2">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-book"></i><br> <span>Türkçe</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-ingilizce-ortaokul-186"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(158, 65, 116,0.9);" class="kategorikutu kategorisira3">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chalkboard-teacher"></i><br> <span>İngilizce</span> </i> 
            </div>

          </div></a>
        </div>

         

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-fen-bilgisi-ortaokul-187"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(250, 156, 11,0.9);" class="kategorikutu kategorisira4">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-atom"></i><br> <span>Fen Bilgisi</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-sosyal-bilgiler-156"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(132, 109, 25,0.9);" class="kategorikutu kategorisira5">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chalkboard-teacher"></i><br> <span>Sosyal Bilgiler</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-din-kulturu-ve-ahlak-bilgisi-148"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(116, 227, 18,0.9);" class="kategorikutu kategorisira6">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-mosque"></i><br> <span>Din Kültürü</span> </i> 
            </div>

          </div></a>
        </div>

       

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-resim-78"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(146, 17, 191,0.9);" class="kategorikutu kategorisira7">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-paint-brush"></i><br> <span>Resim</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-muzik-85"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(191, 17, 41 ,0.9);" class="kategorikutu kategorisira8">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-guitar"></i><br> <span>Müzik</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-yuzme-44"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(18, 192, 2270.9);" class="kategorikutu kategorisira9">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-swimmer"></i><br> <span>Yüzme</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-satranc-170"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(227, 18, 132,0.9);" class="kategorikutu kategorisira10">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chess-queen"></i><br> <span>Satranç</span> </i> 
            </div>

          </div></a>
        </div>


          <div id="kutucuuk" class="col-md-2"> 
          <a href="c-dovus-sanatlari-23"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(191, 38, 17,0.9);" class="kategorikutu kategorisira11">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-brain"></i><br> <span>Dövüş Sanatları</span> </i> 
            </div>

          </div></a>
        </div>


<div id="kutucuuk" class="col-md-2"> 
          <a href="c-yazilim-99"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(53, 52, 45,0.9);" class="kategorikutu kategorisira12">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-laptop-code"></i><br> <span>Yazılım</span> </i> 
            </div>

          </div></a>
        </div>
        

        

    
    </div>           

     <div class="row animated  slideInUp tab-pane" id="lisetakviye">




        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-matematik-lise-163"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(43, 59, 253,0.9);" class="kategorikutu kategorisira1">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-square-root-alt"></i><br> <span>Matematik</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-turkce-lise-145"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(251, 30, 8,0.9);" class="kategorikutu kategorisira2">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-book"></i><br> <span>Türkçe</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-ingilizce-lise-166"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(158, 65, 116,0.9);" class="kategorikutu kategorisira3">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chalkboard-teacher"></i><br> <span>İngilizce</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-ingilizce-yds-hazirlik-167"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(158, 65, 116,0.9);" class="kategorikutu kategorisira4">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-chalkboard-teacher"></i><br> <span>YDS Hazırlık</span> </i> 
            </div>

          </div></a>
        </div>

        

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-geometri-155"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(132, 109, 25,0.9);" class="kategorikutu kategorisira5">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-pencil-ruler"></i><br> <span>Geometri</span> </i> 
            </div>

          </div></a>
        </div>

        

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-fizik-151"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(227, 18, 132,0.9);" class="kategorikutu kategorisira6">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-magnet"></i><br> <span>Fizik</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-kimya-152"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(250, 156, 11,0.9);" class="kategorikutu kategorisira7">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-flask"></i><br> <span>Kimya</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-biyoloji-153"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(24, 202, 78,0.9);" class="kategorikutu kategorisira8">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-heart"></i><br> <span>Biyoloji</span> </i> 
            </div>

          </div></a>
        </div>

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-tarih-146"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(18, 192, 2270.9);" class="kategorikutu kategorisira9">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-landmark"></i><br> <span>Tarih</span> </i> 
            </div>

          </div></a>
        </div>

      


       

         <div id="kutucuuk" class="col-md-2"> 
          <a href="c-edebiyat-144"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white;background-color: rgba(167, 175, 131,0.9);" class="kategorikutu kategorisira10">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-pen-fancy"></i><br> <span>Edebiyat</span> </i> 
            </div>

          </div></a>
        </div>

        <div id="kutucuuk" class="col-md-2"> 
          <a href="c-cografya-143"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(53, 52, 45 ,0.9);" class="kategorikutu kategorisira11">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-globe-europe"></i><br> <span>Coğrafya</span> </i> 
            </div>

          </div></a>
        </div>

          <div id="kutucuuk" class="col-md-2"> 
          <a href="c-din-kulturu-ve-ahlak-bilgisi-148"><div align="center" style="color:white; margin-bottom:10px;border-radius: 5px; border: 2px solid white; background-color: rgba(116, 227, 18 ,0.9);" class="kategorikutu kategorisira12">
            <div class="col-md-12 kategori_ust_bosluk"><i style="font-size: 23px;" class="fas fa-mosque"></i><br> <span>Din Kültürü</span> </i> 
            </div>

          </div></a>
        </div>

          

    
    </div>                        
                                            </div>
                                        </div>
                                    </div>
                                </div> 


  
    
   
  </div>
</div>

<div class="newest-products-area section-space-default">
            <div class="container">
                <h2 align="center" class="title-default">İstanbul'da Öne Çıkan Eğitmenler</h2> </div>
            <div class="container" id="isotope-container">
                <div class="row featuredContainer">

                    <?php $egitmensec=$db->prepare("SELECT * from kullanici where kullanici_il=:il and kullanici_durum=:durum and kullanici_yetki=:yetki and kullanici_onecikan=:onecikan order by premium_baslangic ASC limit 24");
            $egitmensec->execute(array(
              "durum" => 1,
              "yetki" => 1,
              "onecikan" => 1,
              "il" => 35

            ));
            while ($egitmencek=$egitmensec->fetch(PDO::FETCH_ASSOC)) { 
              $egitmenkategorisecxx=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:id and kategori_enalt=:enalt");
              $egitmenkategorisecxx->execute(array(
                "id" => $egitmencek['kullanici_id'],
                "enalt" => 1
              ));
              $egitmenkategorisay=$egitmenkategorisecxx->rowCount();






              ?>
              
             
                <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 istanbul">

                  <a href="profil-<?php echo $egitmencek['kullanici_id']; ?>">
                  <div class="single-item-grid">
                    <div align='center' class="item-img">
                      <img style="width: 180px;height: 180px; border:1px solid #8bc34a;" class="img-responsive img-circle" src="<?php echo $egitmencek['kullanici_resim']; ?>">
                    </div>
                    <div  class="item-content">
                      <div style="border-bottom:0px" class="item-info">
                        <h3><?php echo $egitmencek['kullanici_ad']." ".mb_substr($egitmencek['kullanici_soyad'],0,1)."."; ?>
                          </span><br><span style="color:#707070; font-size:13px;"><?php echo date("Y")-$egitmencek['kullanici_dogum']." Yaşında"; ?> / <?php if ($egitmencek['kullanici_cinsiyet']==1) {
                            echo "Kadın";
                          } else if($egitmencek['kullanici_cinsiyet']==2) {
                            echo "Erkek";
                          } ?></span></h3>
                          <?php
                          $sayim=0;
                          echo '<span style="color:green;"><i class="fas fa-user-tie"></i>';while ($egitmenkategoricekxx=$egitmenkategorisecxx->fetch(PDO::FETCH_ASSOC)) { 
                            $sayim++;
                            $kategorisecxx=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_id=:id");
                            $kategorisecxx->execute(array(
                              "durum" => 1,
                              "id" => $egitmenkategoricekxx['kategori_id']
                            )); 
                            $kategoricekxx=$kategorisecxx->fetch(PDO::FETCH_ASSOC);
                            $kategorisecsay=$kategorisecxx->rowCount();
                            ?>
                            <?php if ($sayim==$egitmenkategorisay) {
                              echo $kategoricekxx['kategori_ad'];
                            } else {
                              echo $kategoricekxx['kategori_ad'].",";
                            } ?>
                          <?php } ?>
                        </span>
                        <br>
                        <?php $sehirsecyeni=$db->prepare("SELECT * from sehirler where sehir_id=:id");
                        $sehirsecyeni->execute(array(
                          "id" => $egitmencek['kullanici_il']
                        ));
                        $sehircekyeni=$sehirsecyeni->fetch(PDO::FETCH_ASSOC);
                        
                        ?>
                        <span style="color:#707070;"><i style="color: #e74c3c;" class="fas fa-map-marker-alt"></i><?php echo " ".$sehircekyeni['sehir_ad']; ?></span>

                        <?php

if ($egitmencek['kullanici_sertifika']==1) { ?>
  <br>

                         <span style="color: #707070;"><i style="color: #FFA726;" class="fas fa-certificate"></i> Sertifikalı Eğitmen</span>
<?php }

                         ?>


                       
                       


                      </div>
                    </div>
                  </div>

                  </a>
                </div>

              
              
            <?php } ?> 


       
                   
                  
                </div>
               
            </div>
        </div>
       
 
  <!-- Newest Products Area End Here -->
  <!-- Trending Products Area Start Here -->
  

      <!-- Trending Products Area End Here -->
      <!-- Why Choose Area Start Here -->
      <div class="why-choose-area bg-primaryText section-space-default"> 
        <div class="container">
          <h2 class="title-textPrimary">Neden eğitmenkampı?</h2> 
        </div>
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="why-choose-box">
                <a href="javascript:void(0);"><i class="fas fa-user-tie"></i></a>
                <h3><a href="javascript:void(0);">Kaliteli</a></h3>
                <p>Eğitmen profillerindeki <u>Profili Bildir</u> butonu sayesinde size yalan söyleyen,sizi dolandırmaya çalışan veya <a href="topluluk-kurallari">Topluluk Kuralları</a>'nı ihlal eden eğitmenleri barındırmaz,maksimum kalitede eğitmenleri bünyemizde tutmaya çalışırız.</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="why-choose-box">
                <a href="javascript:void(0);"><i class="fas fa-th"></i></a>
                <h3><a href="javascript:void(0);">Çeşitli</a></h3>
                <p>Toplamda 100'den fazla kategoride eğitmenleri bünyemizde barındırıyor,özel ders alınabilecek her konuda sizlere hizmet vermeye özen gösteriyoruz.</p>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
              <div class="why-choose-box">
                <a href="javascript:void(0);"><i class="fas fa-rocket"></i></a>
                <h3><a href="javascript:void(0);">Hızlı</a></h3>
                <p>Öncelikli amacımız öğrencilerimizin sayfamıza girdikten sonra 15 saniye içerisinde istediği kategoride ve semtte eğitmenleri göz gezdiriyor olmalarıdır.Bu yüzden basit ve anlaşılır bir arayüzü sizlere sunuyoruz.</p>
              </div>
            </div>
          </div>
        </div>
      </div>


            
        


        <?php require_once 'footer.php'; ?>
        <script type="text/javascript">
          

    $('#sehirsec').change(function(){
       
      $sehirid=$('#sehirsec').val();

        $.ajax({
            type : 'POST',
            url : 'nedmin/production/netting/ajaxsehirseckategoriler.php',
            data : {"sehir_id":$.trim($sehirid)},
            success : function(e){
                $('#ilcesec').html(e);
            }
        });

    });

    $('#personal-info-form').submit(function(){



      var sehir=$('#sehirsec').val();
      var kategori=$('#kategorisec').val();

    

     if (sehir==null && kategori==null) {

      event.preventDefault();

     } else if(sehir==null){

      event.preventDefault();

     } else if(kategori==null){

event.preventDefault();

     } 



    })
        </script>
      