<?php 	require_once 'header.php'; ?>

<head>
  
<title>Gizlilik - Eğitmenkampı</title>

</head>


<div style="padding:30px;" class="container">
	
	
	<h2>Gizlilik Prensipleri</h2>

<p>Kullanıcıların kişisel özellik ve mahremiyeti Eğitmenkampı.com için son derece önemlidir. "Gizlilik Prensipleri", sizin hakkınızda topladığımız bilgileri ve bu bilgilere ne olabileceğini tanımlar. </p>

<h3 style="text-decoration: underline;">Topladığımız Bilgiler</h3>


<p>Eğitmenkampı.com'a üye olduğunuzda, sizlerden elektronik posta adresinizi ve şifrenizi, sizin kişisel tanıtıcı bilginiz olarak talep etmekteyiz. Eğer elektronik posta adresinizi kullanıcı adınızmış gibi kullanırsanız, bunun da sitedeki diğer kişiler tarafından görülebildiğini kabul etmek zorundasınızdır. Sitemize özel öğretmen bulmak amaçlı uğrayan ziyaretçilere aradıkları öğretmeni en kolay şekilde bulabilmeleri ve en uygun kişilerle iletişim kurmalarını sağlamak amacıyla üyelerimizin yaş, cinsiyet ve meslek bilgileri profil sayfalarında yer almaktadır ve tüm site kullanıcıları tarafından görülebilmektedir. </p>

<p>Eğitmenkampı.com, ders almak isteyenler ve ders vermek isteyen üyelerimiz arasındaki iletişimi, site içi mesajlaşma sistemi aracılığı ile kolaylaştırır. Eğitmenkampı.com'un özel mesaj yollama sistemi ile gönderilen mesajlar, sadece sizin E-Posta adresinizle tanımlanır ve kullanıcıların kişisel email adresleri ifşa edilmez. Biz sizlerin elektronik posta adreslerinizi, sizinle ilgili idari tebligatları ve uyarıları, Eğitmenkampı.com'u kullanımınızla ilgili iletişimlerde, sizlerle temasa geçmek için kullanırız. </p>

<p>Sizler, email adresi ve şifreniz dahil olmak üzere kişisel tanıtım bilgilerinizi her zaman profil sayfanızdaki "Profilimi Güncelle" bilgi linkine tıklamak suretiyle; yeniden gözden geçirebilir, güncelleştirebilir veya değiştirebilirsiniz.</p>


<p>Eğitmenkampı.com spam'e (istenilmeyen elektronik posta'ya) asla müsamaha göstermez. Dolayısıyla spam yollamanıza hiçbir şekilde izin verilemez. Eğitmenkampı.com'u kullanarak spam gönderen kullanıcıyı şikayet etmek için bize ulaşınız. 
</p>

<p>Sizin hakkınızda elimizde bulunan bilgileri ve geçmişteki ve halen site üzerinden gerçekleştirmekte olduğunuz aktivitelerinizden elde ettiğimiz diğer bilgileri; ihtilafları çözmek, çıkabilecek sorunları gidermek ve kullanıcı sözleşmemizin yürürlüğünü sağlamak için kullanabiliriz. Zaman zaman, hesap bilgilerinize ve işlem tarihlerinize, sorunları tanımlamak veya uyuşmazlıkları çözmek için bakabiliriz. Ayrıca, bu gibi bilgiler, teknik sınırlamalardan dolayı ve sistemimizi sürekli yedeklememizden dolayı, hiçbir zaman veri tabanımızdan tamamen kaldırılamayabilir. 
</p>

<p>Eğitmenkampı.com; site kullanım bilgilerini, sitemizi ziyaret edenlerin sayısını, ziyaret sıklığını ve bunlardan meydana çıkan diğer bir takım unsurları otomatik olarak biriktirir. Eğitmenkampı.com, bu bilgileri, sizin kişisel kimliğinizi saptar bir biçimde değil, sadece istatistiksel ve bir araya getirilmiş toplam veriler şeklinde kullanır. </p>


<p>Eğitmenkampı.com sizin IP adreslerinizi, sunucumuzla ilgili problemleri teşhis etmek, problemlere çare bulmak ve siteye hizmet etmek için kullanır. Genellikle, IP adresleri, kişinin bize bağlandığı yeri, kişinin hangi servis uygulamalarını kullandığını ve kullanıcının sitede hangi bölümleri ziyaret ettiğini gösterir. Biz sizin IP adreslerinizle hiçbir şekilde özel olarak kimliğinizi saptayabilecek bir bağlantı kurmayız. Sahtekarlık ve dolandırıcılığı önlemek amacıyla, IP adreslerini takip etme hakkımızı ve bu adresleri, gerektiğinde yargı mercileriyle paylaşma hakkımızı da saklı tutmaktayız. </p>


<p>Eğitmenkampı.com'un, kendisine gönderilen elektronik posta haberleşmelerini, ve diğer kullanıcıların veya üçüncü şahısların aktiviteleriyle ilgili haberleşme bilgilerini de toplama ve saklama hakkı mahfuzdur. Bu bilgileri gerektiğinde yargı mercileriyle paylaşma hakkımızı da saklı tutmaktayız. </p>


<h3 style="text-decoration: underline;">Sizin Bilgilerinizin Bizim Tarafından Açıklanması</h3>

<p>Hiçbir kişisel tanımlayıcı bilgiyi üçüncü şahıslara satmayız, kiralamayız ve bu bilgiyle ticaret yapmayız, kullanıcılarımızın elektronik posta adreslerini talep edilmemiş pazarlama için kullanmayız. Bu durumun yegane istisnaları ya izninizin alınmış olması ya da bu bölümde belirtilen diğer durumlardır. Bazı hallerde devlet, kişileri ya da kuruluşları, sizin hakkınızda bilgi ifşaatına icbar edebilir. Eğitmenkampı.com uygun gördüğü takdirde, bu gibi hallerde, sizin yetki vermenize gerek kalmadan bu duruma uyacaktır. Eğitmenkampı.com, mevcut veya muhtemel bir hukuk davasında, gerçeğe erişmeyi kolaylaştırmak amacıyla, (a) eğer gerekli görürse (b) böyle açıklamaların kendisinin potansiyel mükellefiyetini hafifleteceğine inanırsa veya (c) kendi haklarını icra etmek için bazı kişisel bilgilerinizi paylaşmayı uygun görürse, bu duruma muvafakat etme mecburiyetiniz bulunmaktadır. Eğitmenkampı.com'un bütün aktif değeriyle birlikte satılması halinde veya iktisap edilmesi ile, tipik olarak işin aktif değerlerinden biri olmaları dolayısıyla, müşteri bilgileri de transfer olur. Bu gibi transferlerin vukuu her zaman mümkün olabileceğinden, kişisel bilgilerinizi, Eğitmenkampı.com'u iktisap edenin ileriye dönük olarak, kullanmaya devam edebileceğini, peşinen kabul etmiş sayılırsınız. </p>

<h3>Reklamcılık</h3>

<p>Eğitmenkampı.com'un, diğer sitelerle ağ bağlantısı bulunabilir. Eğitmenkampı.com bu gibi web sitelerinin gizlilik uygulamalarından veya içeriklerinden sorumlu değildir. Bu sitelerin gizlilik politika ve prensiplerini gözden geçirmenizi tavsiye ederiz. Eğitmenkampı.com'da neşrolunan reklamlar, reklamcılık yapan iş ortaklarımız aracılığı ile kullanıcılarımıza dağıtılır. Bu ortaklar, mevcut ortamda bir takım tanımlama bilgileri kurabilirler. Bunu yapmak, reklam sahibinin size her çevrimiçi ilan göndermesinde bilgisayarınızı tanımasını sağlar. Bu da reklam verenlerin, sizin veya bilgisayarınızı kullanan diğer herhangi birisinin, onların verdiği hangi reklamı gördüğünü veya hangisine, üzerine tıklamak suretiyle, eriştiğini saptamayı mümkün kılar. Eğitmenkampı.com'un, reklam veren üçüncü şahısların reklam sunucularına ve reklam ağlarına yerleştirilmiş olabilen tanımlama bilgilerine ulaşabilme ve onları kontrol etme imkanı veya hakkı yoktur. Buradaki Gizlilik Prensipleri, sadece Eğitmenkampı.com'un tanımlama bilgilerinin kullanılmasını kapsar, bunlar dışındaki herhangi bir reklam verenin tanımlama bilgilerinin kullanılmasını kapsamaz. </p>

<h3>Üyelik İptal Etme Prosedürleri</h3>

<p>Eğitmenkampı.com'daki üyeliğinizi iptal etmeye karar verdiyseniz, siteye giriş yaptıktan sonra 'Üyeliğimi İptal Et' linkini kullanarak üyeliğinizi sonlandırabilirsiniz. Son 2 yıl süresince aktif olmayan ve üyelik girişi yapılmayan hesaplar 2 yılın sonunda otomatik olarak geçici şekilde iptal olmaktadır. Geçici şekilde iptal olan üyenin profili yayından kaldırılmaktadır ve arama sonuçlarında gözükmemektedir. Üye, geçici şekilde iptal olan hesabına 6 ay içinde giriş yaparak üyeliğini tekrar aktif hale getirebilir. Geçici şekilde iptal olduktan sonra 6 ay boyunca giriş yapılmayan hesaplar kalıcı şekilde iptal olup sitemizden üyeliğe ait tüm bilgiler silinmektedir. </p>

</div>	


<?php 	require_once 'footer.php'; ?>