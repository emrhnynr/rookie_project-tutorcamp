﻿<?php require_once 'header.php'; ?>

<head>
  
<title>Favorilerim - eğitmenkampı</title>

</head>



<?php if (empty($_SESSION['kullanicioturum'])) {
  header("Location:404");
} ?>







            <div class="pagination-area bg-secondary">
                <div class="container">
                    <div class="pagination-wrapper">
                        <ul>
                            <li><a href="index.php">Anasayfa</a><span> -</span></li>
                            <li>Favorilerim</li>
                        </ul>
                    </div>
                </div>  
            </div> 
            <!-- Inner Page Banner Area End Here -->          
            <!-- Sales Statement Page Start Here -->
            <div class="sales-statement-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <h2 class="title-section">Favorilerim</h2>
                    <div class="sales-statement-wrapper inner-page-padding">

                        <?php   if ($_GET['sil']=="ok") { ?>
                           
                           <div class="alert alert-success"><i class="fas fa-check"></i> Eğitmen Favorilerden Başarıyla Kaldırıldı!</div>
                     <?php   } else if($_GET['sil']=="no"){ ?>

                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Kaldırma İşlemi Esnasında Hata Oluştu.</div>


                       <?php  } ?>
                        
                       
                                   <?php    if ($favorisay1>0) { ?>



                                     <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                    <th>#</th>
                                    <th>Fotoğraf</th>
                                    <th>İsim</th>
                                    <th><i class="fas fa-user-tie"></i> Alan / Alanlar</th>
                                    <th><i class="far fa-building"></i> Şehir / İlçe</th>
                                    <th></th>
                                    <th></th>
                                    </tr>
                                </thead>
                                <tbody>

                                     <?php $sayfavori=0; while ($favoricek1=$favorisec1->fetch(PDO::FETCH_ASSOC)) {



                                    $egitmensec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
                                    $egitmensec->execute(array(

"id" => $favoricek1['favalinan_id']
                                    )) ;

                                    $egitmencek=$egitmensec->fetch(PDO::FETCH_ASSOC);


$sehirsec=$db->prepare("SELECT * from sehirler where sehir_durum=:durum and sehir_id=:id");
$sehirsec->execute(array(

"durum" => 1,
"id" => $egitmencek['kullanici_il']
));


$sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC);

$ilcesec=$db->prepare("SELECT * from ilceler where ilce_durum=:durum and ilce_id=:id");
$ilcesec->execute(array(

"durum" => 1,
"id" => $egitmencek['kullanici_ilce']
));


$ilcecek=$ilcesec->fetch(PDO::FETCH_ASSOC);

                                        $sayfavori++;
                                        ?>
                                         <tr>
                                        <th scope="row"><?php echo $sayfavori; ?>.</th>
                                        <td> <?php if (!empty($egitmencek['kullanici_resim'])) { ?>


                                                             <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="<?php echo $egitmencek['kullanici_resim']; ?>">
                                                            

                                                      <?php  } else {


                                                        if ($egitmencek['kullanici_yetki']=="0") {


                                                            if (empty($egitmencek['kullanici_cinsiyet'])) { ?>


                                                                <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">


                                                                

                                                          <?php  } else if ($egitmencek['kullanici_cinsiyet']=="1") { ?>

                                                             <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/3.jpg">
                                                                

                                                           <?php } else if($egitmencek['kullanici_cinsiyet']=="2"){ ?>


                                                             <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/5.jpg">


                                                           <?php }

                                                            

                                                        } else if($egitmencek['kullanici_yetki']=="1" or $egitmencek['kullanici_yetki']=="2" or $egitmencek['kullanici_yetki']=="3"){


                                                            if ($egitmencek['kullanici_cinsiyet']=="1") { ?>


                                                                 <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/9.jpg">
                                                              

                                                          <?php  } else { ?>


                                                            <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/11.jpg">



                                                        <?php  }





                                                        }




                                                      } ?> </td>
                                        <td><a style="color:#8bc34a;font-weight: bold;" href="profil-<?php echo $egitmencek['kullanici_id'];  ?>"><?php   echo $egitmencek['kullanici_ad']." ".substr($egitmencek['kullanici_soyad'],0,1)."."; ?></a></td>
                                        <td><?php

                                         $egitmenkategorisecxx=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:id and kategori_enalt=:enalt");
                                      $egitmenkategorisecxx->execute(array(

"id" => $egitmencek['kullanici_id'],
"enalt" => 1

                                      ));

                                      $egitmenkategorisay=$egitmenkategorisecxx->rowCount();
                                                        $sayim=0;



                                                         echo '<span>';while ($egitmenkategoricekxx=$egitmenkategorisecxx->fetch(PDO::FETCH_ASSOC)) {  

$sayim++;
                                                          $kategorisecxx=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_id=:id");
                                                           $kategorisecxx->execute(array(

"durum" => 1,
"id" => $egitmenkategoricekxx['kategori_id']
                                                           )); 

$kategoricekxx=$kategorisecxx->fetch(PDO::FETCH_ASSOC);
$kategorisecsay=$kategorisecxx->rowCount();




                                                           ?>

                                                         
                                                            

                                                         

                                                                  <?php
                                                            
                                                           if ($egitmenkategorisay==1) { ?>

                                                             <?php echo $kategoricekxx['kategori_ad'];?>

                                                         <?php } else if($egitmenkategorisay==2){ ?>

                                                        <?php  if ($sayim==2) {
                                                          
                                                           echo $kategoricekxx['kategori_ad'];
                                                        } else {

                                                          echo $kategoricekxx['kategori_ad']." & ";

                                                         
                                                        } ?>



                                                       <?php  } else if($egitmenkategorisay==3){ ?>


                                                        <?php  if ($sayim==3) {
                                                          
                                                           echo $kategoricekxx['kategori_ad'];
                                                        } else {

                                                          echo $kategoricekxx['kategori_ad']." & ";

                                                         
                                                        } ?>




                                                      <?php } else if($egitmenkategorisay==4){ ?>


                                                        

                                                        <?php  if ($sayim==4) {
                                                          
                                                           echo $kategoricekxx['kategori_ad'];
                                                        } else {

                                                          echo $kategoricekxx['kategori_ad']." & ";

                                                         
                                                        } ?>








                                                    <?php  }  ?>



                                                            <?php }  ?>
                                                          </span>

                                                       </td>

                                                       <td><?php    echo $sehircek['sehir_ad']." / ".$ilcecek['ilce_ad']; ?></td>
                                        <td align="right">
                                            
                                           <a href="profil-<?php echo $egitmencek['kullanici_id'];  ?>">

                                            <i style="color:green;" data-toggle='tooltip' data-placement='top' title="Profile Git" class="fas fa-eye"></i>
                                               
                                           </a>
                                        </td>

                                        <td align="center"><a id="favorisil" href="nedmin/production/netting/musteriislem.php?favoricikar2=ok&egitmen_id=<?php    echo $egitmencek['kullanici_id']; ?>"><i style="color:red;" data-toggle='tooltip' data-placement='top' title="Favorilerden Çıkar" class="fas fa-trash-alt"></i></a></td>
                                    </tr>
                                   <?php } ?>
                                   
                                   
                                       
                                  <?php } else { ?>


                                    <h4 align="center"><i class="far fa-bookmark"></i> Henüz Kimseyi Favorilerinize Eklememişsiniz.</h4>



                                 <?php  } ?>
                                </tbody>
                            </table>
                        </div>
                         
                    </div> 
                </div> 
            </div> 
            <?php require_once 'footer.php'; ?>

            <script type="text/javascript">
              
              $(document).ready(function () {
    $("a#favorisil").one("click", function() {
    $(this).click(function () { return false; });
});
});

            </script>