<?php  require_once 'header.php'; ?>


<head>
  
<title>Eğitmen Kayıt Tamamlama | EğitmenKampı</title>

</head>



 
<head><style type="text/css">
   /* Customize the label (the container) */
.checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
}

</style></head>

<?php if ($kullanicioturumcek['kullanici_yetki']!=2 or $egitmenkategoritestsay!=0)   {
   
Header("Location:404");

} ?>





            <!-- Header Area End Here -->
            <!-- Main Banner 1 Area Start Here -->
           
            <!-- Main Banner 1 Area End Here --> 
            <!-- Inner Page Banner Area Start Here -->
            
            <!-- Inner Page Banner Area End Here -->          
            <!-- Registration Page Area Start Here -->
            <div class="registration-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <h2 class="title-section">Eğitmen Kaydı Tamamlama Adım : 1 / 2</h2>

                    <div class="registration-details-area inner-page-padding">

                      

                                     <div id="infobox" class="alert alert-warning">

                                        • Lütfen aşağıdaki bilgileri doldurunuz.<br><br>


                                        • Ekleyeceğiniz <b>İlan Başlığı</b> Kısa ve Öz olmalıdır. Yaratıcı bir başlık sizi bir adım öne geçirir.<br><br>

                                   
                                   • Birbirinden çok farklı kategorileri seçmeniz öğrencilerin gözünde konuya olan hakimiyetiniz konusunda şüphe etmelerine neden olur. (Örn.Hem Matematik hem de Boks kursunu işaretlemeniz <u>önerilmez</u>.)<br>



                                 </div>







                                  


                            



                               


                               







                                    <br>
                       

                        <form class="formaise" action="nedmin/production/netting/musteriislem.php" method="POST" id="personal-info-form">


                          <h4 style="text-transform: capitalize;text-align: center;">Öncelikle lütfen kendinizi,özgeçmişinizi ve ders tarzınızı açıklayan en fazla 2000, En Az 100 karakter uzunluğunda bir tanıtım yazısı yazınız. (<span style="color:#707070;" class="karaktersay">2000</span>)</h4>

                          <textarea class="col-md-12" id="egitmenhakkinda"  name="kendinitanit" style="height: 200px;"></textarea>

                      



                       

                          <br><br>

                          <hr>

                          <h4 align="center">Bir İlan Başlığı Ekleyin (Minimum <b>20</b>, Maksimum <b>150</b> Karakter)</h4>
                          <input class="form-control" maxlength="150" placeholder="Örn. Matematik Öğrenmek İsteyenler İçin Bulunmaz Fırsat, Türkiye Şampiyonu Boks Eğitmeninden Boks Dersi vs."  type="text" id="ilanbaslik" name="kullanici_ilanbaslik">
                          <span style="font-size: 14px;color: #707070;" id="baslikkaraktersay">150</span>

                           <br><br>

                          <hr>


                          <h4 align="center">Ders Verebileceğiniz Mekanlar</h4>
                          <input class="form-control" maxlength="500" placeholder="Örn. Öğrencinin Evi, Öğretmenin Evi vs."  type="text" id="yerler" name="kullanici_yerler">




                          <br><br><hr>



                           <h4 align="center">Ders Tarzınız</h4>
                          <input class="form-control" maxlength="500" placeholder="Örn. Birebir Ders, Grup Dersi vs."  type="text" id="derstarzi" name="kullanici_derstarzi">




                          <br><br><hr>


                           <h4 align="center">Sunduğunuz Kolaylıklar (Zorunlu Değil)</h4>
                          <input class="form-control" maxlength="1000" placeholder="Örn. Grup İndirimi, 10'lu Paket X TL vs."  type="text" id="ekstraucret" name="kullanici_ekstraucret">


                          <br><br><hr>



                          <h3>İlk Ders Ücretsiz <small>* İlk dersi ücretsiz vermek tercih edilme olasılığınızı ciddi miktarda artırır.</small></h3>



                        
<label class="checklabell">
  <input  name="kullanici_ilkdersucretsiz"  checked="checked" value="1"  id="ilkdersucretsiz"  type="checkbox">
  <span class="checkmark"></span>
</label>
    






<br><br>

<hr>

<h3>Online Ders Verebilirim</h3>



                        
<label class="checklabell">
  <input  name="kullanici_onlineders"   value="0"  id="onlineders"  type="checkbox">
  <span class="checkmark"></span>
</label>
    






<br><br>




                          <hr>


                          

                          

                          


                                 



                               
                                


                                   


                          <h4>Özel Ders Vermek İstediğiniz Kategorileri Seçiniz <u>(En Fazla 8 Alan)</u></h4>


                          



<h4 align="center" style="border-bottom:2px solid #8bc34a;">Branş Dersleri</h4>



                    <?php $kategorisecx=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_enalt=:enalt and kategori_enust=:enust order by kategori_ad ASC");
                    $kategorisecx->execute(array(

"durum" => 1,
"enalt" => 1,
"enust" => 140

                    )); 



while ($kategoricekx=$kategorisecx->fetch(PDO::FETCH_ASSOC)) { ?>
    
    





<div class="col-md-4" > 

     <label class="checklabell"><?php  echo $kategoricekx['kategori_ad']; ?>
  <input class="kategoricheckbox" id="k<?php echo $kategoricekx['kategori_id']; ?>" name="egitmensecim[]" value="<?php   echo $kategoricekx['kategori_id']; ?>"      type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>









    
    
<?php }  ?>

<h4 align="center" class="col-md-12" style="border-bottom:2px solid #8bc34a;">Spor</h4>

 <?php $kategorisec2x=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_enalt=:enalt and kategori_enust=:enust order by kategori_ad ASC");
                    $kategorisec2x->execute(array(

"durum" => 1,
"enalt" => 1,
"enust" => 22

                    )); 



while ($kategoricek2x=$kategorisec2x->fetch(PDO::FETCH_ASSOC)) { ?>
    
    





<div class="col-md-4" > 

     <label class="checklabell"><?php  echo $kategoricek2x['kategori_ad']; ?>
  <input class="kategoricheckbox" id="k<?php echo $kategoricek2x['kategori_id']; ?>" name="egitmensecim[]" value="<?php   echo $kategoricek2x['kategori_id']; ?>"      type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>









    
    
<?php }  ?>



<h4 align="center" class="col-md-12" style="border-bottom:2px solid #8bc34a;">Yabancı Dil</h4>

 <?php $kategorisec3x=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_enalt=:enalt and kategori_enust=:enust order by kategori_ad ASC");
                    $kategorisec3x->execute(array(

"durum" => 1,
"enalt" => 1,
"enust" => 62

                    )); 



while ($kategoricek3x=$kategorisec3x->fetch(PDO::FETCH_ASSOC)) { ?>
    
    





<div class="col-md-4" > 

     <label class="checklabell"><?php  echo $kategoricek3x['kategori_ad']; ?>
  <input class="kategoricheckbox" id="k<?php echo $kategoricek3x['kategori_id']; ?>" name="egitmensecim[]" value="<?php   echo $kategoricek3x['kategori_id']; ?>"      type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>









    
    
<?php }  ?>




<h4 align="center" class="col-md-12" style="border-bottom:2px solid #8bc34a;">Sanat</h4>

 <?php $kategorisec4x=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_enalt=:enalt and kategori_enust=:enust order by kategori_ad ASC");
                    $kategorisec4x->execute(array(

"durum" => 1,
"enalt" => 1,
"enust" => 61

                    )); 



while ($kategoricek4x=$kategorisec4x->fetch(PDO::FETCH_ASSOC)) { ?>
    
    





<div class="col-md-4" > 

     <label class="checklabell"><?php  echo $kategoricek4x['kategori_ad']; ?>
  <input class="kategoricheckbox" id="k<?php echo $kategoricek4x['kategori_id']; ?>" name="egitmensecim[]" value="<?php   echo $kategoricek4x['kategori_id']; ?>"      type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>









    
    
<?php }  ?>

<h4 align="center" class="col-md-12" style="border-bottom:2px solid #8bc34a;">Yazılım</h4>

 <?php $kategorisec5x=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_enalt=:enalt and kategori_enust=:enust order by kategori_ad ASC");
                    $kategorisec5x->execute(array(

"durum" => 1,
"enalt" => 1,
"enust" => 99

                    )); 



while ($kategoricek5x=$kategorisec5x->fetch(PDO::FETCH_ASSOC)) { ?>
    
    





<div class="col-md-4" > 

     <label class="checklabell"><?php  echo $kategoricek5x['kategori_ad']; ?>
  <input class="kategoricheckbox" id="k<?php echo $kategoricek5x['kategori_id']; ?>" name="egitmensecim[]" value="<?php   echo $kategoricek5x['kategori_id']; ?>"      type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>









    
    
<?php }  ?>

<h4 align="center" class="col-md-12" style="border-bottom:2px solid #8bc34a;">Bilgisayar Programları</h4>

 <?php $kategorisec6x=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_enalt=:enalt and kategori_enust=:enust order by kategori_ad ASC");
                    $kategorisec6x->execute(array(

"durum" => 1,
"enalt" => 1,
"enust" => 124

                    )); 



while ($kategoricek6x=$kategorisec6x->fetch(PDO::FETCH_ASSOC)) { ?>
    
    





<div class="col-md-4" > 

     <label class="checklabell"><?php  echo $kategoricek6x['kategori_ad']; ?>
  <input class="kategoricheckbox" id="k<?php echo $kategoricek6x['kategori_id']; ?>" name="egitmensecim[]" value="<?php   echo $kategoricek6x['kategori_id']; ?>"      type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>









    
    
<?php }  ?>


<h4 align="center" class="col-md-12" style="border-bottom:2px solid #8bc34a;">Diğer</h4>

<div class="col-md-4" > 

     <label class="checklabell">Psikolog
  <input name="egitmensecim[]" value="75"   class="kategoricheckbox"   type="checkbox">
  <span class="checkmark"></span>
</label>

<br>

</div>

<div class="col-md-4" > 

     <label class="checklabell">Sürüş
  <input name="egitmensecim[]" value="158"   class="kategoricheckbox"   type="checkbox">
  <span class="checkmark"></span>
</label>

<br>

</div>

<div class="col-md-4" > 

     <label class="checklabell">Pazarlama
  <input name="egitmensecim[]" value="157"  class="kategoricheckbox"    type="checkbox">
  <span class="checkmark"></span>
</label>

<br>

</div>

<div class="col-md-4" > 

     <label class="checklabell">Yaşam Koçluğu
  <input name="egitmensecim[]" value="159"   class="kategoricheckbox"    type="checkbox">
  <span class="checkmark"></span>
</label>

<br>

</div>

<div class="col-md-4" > 

     <label class="checklabell">Tercih Koçluğu
  <input name="egitmensecim[]" value="160"   class="kategoricheckbox"   type="checkbox">
  <span class="checkmark"></span>
</label>

<br>

</div>

<div class="col-md-4" > 

     <label class="checklabell">Diyetisyen
  <input name="egitmensecim[]" value="74"   class="kategoricheckbox"   type="checkbox">
  <span class="checkmark"></span>
</label>

<br>

</div>




















             




                   



                    

                    







                  


                   





                            


                           




                            


                           



 
                            
                               
                                                            
                          
             

                           
                            <div class="row">


                               
                               
                                 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 

                   
                     <div style="display: none;" id="fazlasecim" class="alert alert-danger"><i class="fas fa-exclamation"></i> En fazla <b>8</b> alanda özel ders verebilirsiniz.</div>

                      <div style="display: none;" id="secimyok" class="alert alert-danger"><i class="fas fa-exclamation"></i> Özel ders vermek istediğiniz alan/alanları seçmediniz.</div>

                       <div style="display: none;" id="karakterproblem" class="alert alert-danger"><i class="fas fa-exclamation"></i> 
                       Girdiğiniz Tanıtım Yazısı Maksimum <b>2000</b> Karakter Uzunluğunda Olabilir.</div>

                        <div style="display: none;" id="karakterproblem2" class="alert alert-danger"><i class="fas fa-exclamation"></i> 
                       Girdiğiniz Tanıtım Yazısı Minimum <b>100</b> Karakter Uzunluğunda Olabilir.</div>

                       <div style="display: none;" id="baslikproblem" class="alert alert-danger"><i class="fas fa-exclamation"></i> 
                       Girdiğiniz İlan Başlığı Minimum <b>20</b> Karakter Uzunluğunda Olabilir.</div>

                        <div style="display: none;" id="derstarziproblem" class="alert alert-danger"><i class="fas fa-exclamation"></i> 
                       Girdiğiniz Ders Tarzı Minimum <b>6</b> Karakter Uzunluğunda Olabilir.</div>

                        <div style="display: none;" id="yerlerproblem" class="alert alert-danger"><i class="fas fa-exclamation"></i> 
                       Ders Verebileceğiniz Mekanlar Minimum <b>4</b> Karakter Uzunluğunda Olabilir.</div>


                                    <div class="pLace-order">
                                        <button class="update-btn disabled" type="submit" name="kayittamamla1">İlerle</button>
                                    </div>
                                </div>
                            </div> 
                        </form>                      
                    </div> 
                </div>
            </div>
            <!-- Registration Page Area End Here -->
            <!-- Footer Area Start Here -->

            
           
            <?php require_once 'footer.php'; ?>

             <script type="text/javascript">

              $('#ilkdersucretsiz').change(function(){


if ($('#ilkdersucretsiz').prop('checked')) {

  
 $('#ilkdersucretsiz').val('1');
  
} else {

  $('#ilkdersucretsiz').val('0');
 
};


              });


$('#onlineders').change(function(){


if ($('#onlineders').prop('checked')) {

  
 $('#onlineders').val('1');
  
} else {

  $('#onlineders').val('0');
 
};


              })


              $('#ilanbaslik').keydown(function(){

                var basliksay=$.trim($('#ilanbaslik').val()).length;


$('#ilanbaslik').css('font-weight','Bold');

$('#baslikkaraktersay').text(150-basliksay);


              })


              

            CKEDITOR.replace('egitmenhakkinda');

            

CKEDITOR.instances['egitmenhakkinda'].on('key', function () {
  //Do something here.



   function stripHtml(html)
{
   var tmp = document.createElement("DIV");
   tmp.innerHTML = html;
   return tmp.textContent || tmp.innerText || "";
};


var editordegeruzunluk=$.trim(stripHtml(CKEDITOR.instances.egitmenhakkinda.getData())).length;






  

$('.karaktersay').html(2000-editordegeruzunluk);
        


    
});


            















           </script>

           
            <script type="text/javascript">


              $('#personal-info-form').submit(function(){

                function stripHtml2(html)
{
   var tmp = document.createElement("DIV");
   tmp.innerHTML = html;
   return tmp.textContent || tmp.innerText || "";
};


var editordegeruzunluk2=$.trim(stripHtml2(CKEDITOR.instances.egitmenhakkinda.getData())).length;   
var baslikdeger=$.trim($('#ilanbaslik').val()).length;
var derstarzideger=$.trim($('#derstarzi').val()).length;
var yerlerdeger=$.trim($('#yerler').val()).length;
var ekstraucretdeger=$.trim($('#ekstraucret').val()).length;




                var secilmischeckbox=$('.kategoricheckbox:checkbox:checked').length;


               if (editordegeruzunluk2>2000) {

                event.preventDefault();

                $('#karakterproblem').show();
                $('#fazlasecim').hide();
                $('#secimyok').hide();
                $('#karakterproblem2').hide();
                $('#baslikproblem').hide();
                $('#yerlerproblem').hide();
                $('#derstarziproblem').hide();
               } 
               else if (editordegeruzunluk2<100) {

                event.preventDefault();

                $('#karakterproblem2').show();
                $('#fazlasecim').hide();
                $('#secimyok').hide();
                $('#karakterproblem').hide();
                $('#baslikproblem').hide();
                 $('#yerlerproblem').hide();
                $('#derstarziproblem').hide();
               }

              

               else if (baslikdeger<20) {

                event.preventDefault();

                $('#karakterproblem').hide();
                $('#fazlasecim').hide();
                $('#secimyok').hide();
                $('#karakterproblem2').hide();
                $('#baslikproblem').show();
                 $('#yerlerproblem').hide();
                $('#derstarziproblem').hide();
               }

               else if (yerlerdeger<4) {

                event.preventDefault();

                $('#karakterproblem').hide();
                $('#fazlasecim').hide();
                $('#secimyok').hide();
                $('#karakterproblem2').hide();
                $('#baslikproblem').hide();
                $('#derstarziproblem').hide();
                $('#yerlerproblem').show();
               }

               else if (derstarzideger<6) {

                event.preventDefault();

                $('#karakterproblem').hide();
                $('#fazlasecim').hide();
                $('#secimyok').hide();
                $('#karakterproblem2').hide();
                $('#baslikproblem').hide();
                 $('#yerlerproblem').hide();
                $('#derstarziproblem').show();
               }

               

               else if (secilmischeckbox==0) {

                event.preventDefault();

                $('#karakterproblem').hide();
                $('#fazlasecim').hide();
                $('#secimyok').show();
                $('#karakterproblem2').hide();
                $('#baslikproblem').hide();
                 $('#yerlerproblem').hide();
                $('#derstarziproblem').hide();
               }

               else if (secilmischeckbox>8) {

                event.preventDefault();

                $('#karakterproblem').hide();
                $('#fazlasecim').show();
                $('#secimyok').hide();
                $('#karakterproblem2').hide();
                $('#baslikproblem').hide();
                 $('#yerlerproblem').hide();
                $('#derstarziproblem').hide();
               } else {


 if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };

               }

              });



            </script>


            