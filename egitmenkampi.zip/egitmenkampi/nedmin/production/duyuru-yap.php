<?php include 'header.php'; ?>


 



<div class="right_col" role="main">
          
            
              
              
            <div class="clearfix"></div>

            <div class="row">
            	
<form action="../../phpmailer/duyurumail.php" method="POST">
<div class="col-md-12">
	<input type="texxt" class="col-md-12" placeholder="Konu giriniz" name="duyurukonu">
  <textarea name="duyurumetin" id="duyuruyap" class="col-md-12 ckeditor" style="height: 500px;"></textarea>
  <br>

  <input align="left" type="submit" name="duyurugonder">
</div>



</form>



<script type="text/javascript">
  
  CKEDITOR.replace('duyuruyap');
</script>




            </div>







<?php include 'footer.php'; ?>