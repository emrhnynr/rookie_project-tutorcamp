<?php include 'header.php'; ?>


 <?php if (empty($_SESSION['kullanicioturum'])) {
   header("Location:404");
 } ?>



<div class="right_col" role="main">
          
            
              
              
            <div class="clearfix"></div>

            <div class="row">
            	

<div class="col-md-9">


  <a href="netting/islem.php?tumbildirimsil2=ok"><strong>Tümünü Sil</strong></a>



<?php $bildirimsec2=$db->prepare("SELECT * from bildirimler where bildirim_durum=:durum order by bildirim_zaman DESC");
$bildirimsec2->execute(array(

"durum" => 1

));

 ?>




                     
                    <?php  while ($bildirimcek2=$bildirimsec2->fetch(PDO::FETCH_ASSOC)) {


$musterisecbakalim2=$db->prepare("SELECT * from musteriler where musteri_id=:id");
$musterisecbakalim2->execute(array(

"id" => $bildirimcek2['musteri_id']

));

$mustericekbakalim2=$musterisecbakalim2->fetch(PDO::FETCH_ASSOC);







$urunsecbakalim2=$db->prepare("SELECT * from urunler where urun_id=:id");
$urunsecbakalim2->execute(array(

"id" => $bildirimcek2['urun_id']

));

$uruncekbakalim2=$urunsecbakalim2->fetch(PDO::FETCH_ASSOC);











 

                     ?>
                      
                    

                    <li>
 <a href="netting/islem.php?bildirim_id=<?php echo $bildirimcek2['bildirim_id'] ?>&bildirimsil2=ok&urun_adrescubuk=<?php   echo 'http://'.$_SERVER['HTTP_HOST' ].$_SERVER['REQUEST_URI']; ?>">
                 
                        <span class="image"><img style="width: 80px; height: 80px;" src="../../<?php if(empty($mustericekbakalim2['musteri_resim'])) {

echo "dimg/logo-yok.png";

                        } else {

echo $mustericekbakalim2['musteri_resim'];

                        } ?>" alt="Profile Image" /></span>
                        <span>
                          <span><?php echo $mustericekbakalim2['musteri_ad']." ".$mustericekbakalim2['musteri_soyad']; ?></span>
                          <span class="time"><?php echo $bildirimcek2['bildirim_zaman']; ?></span>
                        </span>
                        <span class="message">
                          <?php 

if ($bildirimcek2['bildirim_turu']==0) {
  
  echo "Giriş yapan kullanıcı!";

} else if($bildirimcek2['bildirim_turu']==1) {

echo "Yeni Üye Kaydı";


} else if($bildirimcek2['bildirim_turu']==2) {


echo $uruncekbakalim2['urun_ad']." adlı ürününe yorum yaptı!";

};

                           ?>
                        </span>
                      </a>
                    </li>
                   
            <?php     } ?>
                   






 


</div>




            </div>







<?php include 'footer.php'; ?>