

<?php require_once 'netting/baglann.php'; ?>
<?php include 'fonksiyon.php' ;?>





  <?php 

$bilgiisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
$bilgiisec->execute(array(

"id" => $_GET['kategoriid']


));

$bilgiicek=$bilgiisec->fetch(PDO::FETCH_ASSOC);


 ?>







<?php include 'header.php' ?>


 <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            
              
              
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Kategori Düzenleme<small>İşlem Durumu <?php if ($_GET['updatedurum']=="ok") {

                      echo "<b style='color:green;'>  Düzenleme Başarılı !</b>";
                      
                    } else if($_GET['updatedurum']=="no") {

                   echo "<b style='color:red;'> Düzenleme Esnasında Hata Oluştu.</b>";

                    };


                    ?></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">


    <form action="netting/adminislem.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">

                     

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Ad <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" value="<?php echo $bilgiicek['kategori_ad'] ?>" name='kategori_ad' id="first-name"   class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>



<div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Url <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" value="<?php echo $bilgiicek['kategori_url'] ?>" id="first-name" name='kategori_url'  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Üst <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" value="<?php echo $bilgiicek['kategori_ust'] ?>" name='kategori_ust' id="first-name"   class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>




                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Sıra <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                         <input type="text" value="<?php echo $bilgiicek['kategori_sira'] ?>" id="first-name" name='kategori_sira'  class="form-control col-md-7 col-xs-12">
                         
                        </div>
                      </div>





                        

                        <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori SeoUrl <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" value="<?php echo $bilgiicek['kategori_seourl'] ?>" id="first-name" name='kategori_seourl'  class="form-control col-md-7 col-xs-12">
                            
                          
                        </div>
                      </div>

                      

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori Durum <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <select name="kategori_durum" class="form-control">
                            
                      <?php 
 if ($bilgiicek['kategori_durum']=="1") {?>
   
 <option value="1">Aktif</option>
 <option value="0">Pasif</option>


<?php   } elseif ($bilgiicek['kategori_durum']=="0") { ?>


 <option value="0">Pasif</option>
 <option value="1">Aktif</option>


<?php } ?>

                

                        ?>


                          </select>
                            
                          
                        </div>
                      </div>







                        <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Kategori İcon <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" value="<?php echo $bilgiicek['kategori_icon'] ?>" id="first-name" name='kategori_icon'  class="form-control col-md-7 col-xs-12">
                            
                          
                        </div>
                      </div>





                     


                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="hidden" value="<?php echo $bilgiicek['kategori_id'] ?>" name='kategori_id'  required="required" class="form-control col-md-7 col-xs-12">
                            
                          
                        </div>
                      </div>
                    

                      
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button type="submit" name="kategoriduzenle" class="btn btn-success">Düzenle</button>
                        </div>
                      </div>

                    </form>

                </div>
                    
                    


              <!-- Bitiyor -->  <!-- CTRL+SHİFT+A içerisinde bulunduğunuz tag in içeriğini işaretler -->




              
              

        <!-- footer content -->
        <?php include 'footer.php'; ?>