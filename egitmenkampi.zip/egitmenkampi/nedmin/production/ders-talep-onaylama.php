

<?php require_once 'netting/baglann.php'; ?>




<?php include 'header.php' ?>






 <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          
            
              
              
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ders Talebi Onaylama<small>İşlem Durumu <?php if ($_GET['duzenledurum']=="ok") {

                      echo "<b style='color:green;'>  Düzenleme Başarılı !</b>";
                      
                    } else if($_GET['duzenledurum']=="no") {

                   echo "<b style='color:red;'> Düzenleme Esnasında Hata Oluştu.</b>";

                    };


                    ?>
                    	

<?php if ($_GET['sildurum']=="ok") {
	
	echo "<b style='color:green;'>  Veri Silme Başarılı !</b>";

} else if($_GET['sildurum']=="no"){

echo "<b style='color:red;'>Veri Silinemedi.</b>";


}; ?>



                    </small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">




<div class="tab-content">
  

  <div class="tab-pane fade active in" id="onaylanmis">


 <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          
                           <th>Kayıt Tarihi</th>
                          <th>İsim</th>
                          <th>Soyisim</th>
                          <th>Kategori</th>
                          
                         
      

                        </tr>
                      </thead>


                      <tbody>


                        <?php    $derstalebisec=$db->prepare("SELECT * from ders_talepleri where talep_durum=:durum  order by talep_zaman DESC");
          $derstalebisec->execute(array(

"durum" => 0

          ));


$sayim=0;
           ?>



<?php 






while ($derstalebicek=$derstalebisec->fetch(PDO::FETCH_ASSOC)) { $sayim++; 


$kullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id");
$kullanicisec->execute(array(
"id" => $derstalebicek['kullanici_id']
));

$kullanicicek=$kullanicisec->fetch(PDO::FETCH_ASSOC);



$talepkategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
$talepkategorisec->execute(array(
"id" => $derstalebicek['talep_kategori']
));

$talepkategoricek=$talepkategorisec->fetch(PDO::FETCH_ASSOC);

  ?>
  


 


                        <tr>
                          
                          <td><?php echo $derstalebicek['talep_zaman'] ?></td>

                          <td><?php echo $kullanicicek['kullanici_ad']; ?></td>
                          <td><?php echo $kullanicicek['kullanici_soyad'] ?></td>
                            <td><?php echo $talepkategoricek['kategori_ad']; ?></td>
                         

                         <td align="right">

                          <a href="ders-talep-duzenle?talep_id=<?php echo $derstalebicek['talep_id']; ?>"><button class="btn btn-warning btn-xs">Düzenle</button></a>

                          <a href="netting/adminislem.php?talep_id=<?php echo $derstalebicek['talep_id']; ?>&derstalebionayla=ok"><button class="btn btn-success btn-xs">Onayla</button></a>

                         <a href="netting/adminislem.php?talep_id=<?php echo $derstalebicek['talep_id']; ?>&derstalebisil=ok"><button class="btn btn-danger btn-xs">Sil</button></a>
                            
                        </td>
                         
                      
                        </tr>

                  <?php  } ?>


                          </tbody>
                    </table>
  </div>


   





    
    	
    	


    		
    	



   

                </div>
                    
                    


              <!-- Bitiyor -->  <!-- CTRL+SHİFT+A içerisinde bulunduğunuz tag in içeriğini işaretler -->




              
              

        <!-- footer content -->
        <?php include 'footer.php'; ?>