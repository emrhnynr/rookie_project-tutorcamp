<?php require_once 'header.php'; ?>

<head>
  
<title>Hesap Ayarları | EğitmenKampı</title>

</head>

<?php if ($kullanicioturumcek['kullanici_yetki']==2 or $kullanicioturumcek['kullanici_yetki']==3 or $kullanicioturumcek['kullanici_yetki']==4 or empty($_SESSION['kullanicioturum'])) {
                            
                            Header("location:404");


                        } ; ?>

<style type="text/css">

.checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
}

    
 .more-product-item-wrapper .more-product-item {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-flex;
  display: -ms-flex;
  display: -o-flex;
  display: flex;
  margin-bottom: 30px;
  -webkit-box-shadow: 0px 1px 2px 0px rgba(205, 214, 222, 0.75);
  -moz-box-shadow: 0px 1px 2px 0px rgba(205, 214, 222, 0.75);
  box-shadow: 0px 1px 2px 0px rgba(205, 214, 222, 0.75);
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
@media (min-width: 768px) and (max-width: 991px) {
   .more-product-item-wrapper .more-product-item {
    display: inherit;
  }
}
@media only screen and (max-width: 574px) {
  .more-product-item-wrapper .more-product-item {
    display: inherit;
  }
}
 .more-product-item-wrapper .more-product-item:hover {
  -webkit-box-shadow: 0px 5px 10px 0px rgba(205, 214, 222, 0.75);
  -moz-box-shadow: 0px 5px 10px 0px rgba(205, 214, 222, 0.75);
  box-shadow: 0px 5px 10px 0px rgba(205, 214, 222, 0.75);
}
 .more-product-item-wrapper .more-product-item .more-product-item-img {
  -webkit-box-flex: 3;
  -moz-flex: 3;
  -webkit-flex: 3;
  flex: 3;
}
 .more-product-item-wrapper .more-product-item .more-product-item-img img {
  width: 100%;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details {
  -webkit-box-flex: 4;
  -moz-flex: 4;
  -webkit-flex: 4;
  flex: 4;
  background: #ffffff;
  padding: 10px 12px;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details h4 {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 2px;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details h4 a {
  color: #263238;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details h4 a:hover {
  color: #8bc34a;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details .p-title {
  font-size: 12px;
  color: #8bc34a;
  margin-bottom: 2px;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details .p-price {
  font-size: 18px;
  color: #263238;
  font-weight: 700;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details .a-item {
  font-size: 12px;
  color: #8bc34a;
  margin-bottom: 0;
  margin-top: 10px;
}
 .more-product-item-wrapper .more-product-item .more-product-item-details .a-followers {
  font-size: 12px;
  color: #8bc34a;
  margin-bottom: 0;
}

</style>

            <div class="pagination-area bg-secondary">
                <div class="container">
                    <div class="pagination-wrapper">

                        <?php


$blogsec=$db->prepare("SELECT * from bloglar where blog_durum=:durum and kullanici_id=:id");
$blogsec->execute(array(

"durum" => 1,
"id" => $kullanicioturumcek['kullanici_id']

));


$blogsay=$blogsec->rowCount();
                        ?>
                        <ul>
                            <li><a href="index.php">Anasayfa</a><span> -</span></li>
                            <li>Hesap Ayarları</li>
                        </ul>
                    </div>
                </div>  
            </div> 
            <!-- Inner Page Banner Area End Here -->          
            <!-- Settings Page Start Here -->
            <div class="settings-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <div class="row settings-wrapper">
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                            <ul class="settings-title">
                                <?php if (empty($_GET) or isset($_GET['update'])) { ?>

                                    <li class="active"><a href="#kisisel" data-toggle="tab" aria-expanded="false">Kişisel Bilgilerim</a></li>
                                   
                               <?php } else { ?>

                                <li><a href="#kisisel" data-toggle="tab" aria-expanded="false">Kişisel Bilgilerim</a></li>


                             <?php  } ?>

                             <?php if ($kullanicioturumcek['kullanici_yetki']==1) { ?>

                                  <?php if (isset($_GET['aciklamaupdate'])) { ?>
   <li class="active"><a href="#hakkimda" data-toggle='tab' aria-expanded='false'>Hakkımda</a></li>
<?php } else { ?>

 <li><a href="#hakkimda" data-toggle='tab' aria-expanded='false'>Hakkımda</a></li>

<?php } ?>
                                  
                              <?php  } ?>


                             

                                 


                                <li><a href="fotografim" aria-expanded="false">Profil Fotoğrafı</a></li>

                                <?php if ($kullanicioturumcek['kullanici_yetki']==1 or $kullanicioturumcek['kullanici_yetki']==3) { ?>
                                  <li><a href="sertifikalarim" aria-expanded="false">Sertifika Yükle</a></li>
                             <?php   } ?>

                                


                                






                               

                                
                                
                               
                                <?php if ($kullanicioturumcek['kullanici_yetki']!="0") { ?>



                                     
                                        
                                    

                                        <li><a href="kurs-bilgileri" aria-expanded='false'>Kurs Bilgilerim</a></li>



                                    <?php if ($kullanicioturumcek['kullanici_yetki']==1) { ?>


                                        <?php if (isset($_GET['deleteb']) or isset($_GET['editb'])) { ?>

                                           <li class="active"><a href="#bloglar" data-toggle='tab' aria-expanded='false'>Bloglarım (<?php echo $blogsay; ?>)</a></li>
                                        <?php } else { ?>
                                                                           

                                    <li><a href="#bloglar" data-toggle='tab' aria-expanded='false'>Bloglarım (<?php echo $blogsay; ?>)</a></li>

                                    <?php }  } ?>
                                    
                             <?php   } ?>

                             <li><a href="sifreguncelle.php"  aria-expanded="false">Şifre Değişikliği</a></li>
                               
                               
                            </ul>
                        </div>
                        <div  class="col-lg-9 col-md-9 col-sm-8 col-xs-12"> 
                            
                                <div class="settings-details tab-content">
                                    <?php if (empty($_GET) or isset($_GET['update'])) { ?>
                                        <div class="tab-pane fade active in" id="kisisel">
                                  <?php  } else { ?>

                                    <div class="tab-pane fade" id="kisisel">


                                 <?php } ?>
                                    

                                        <?php if (@$_GET['update']=="nameerror") { ?>

                                            <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen adınızı doğru giriniz.</div>
                                            
                                       <?php } else if(@$_GET['update']=="surnameerror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen soyadınızı doğru giriniz.</div>


                                     <?php  } else if(@$_GET['update']=="bornerror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen doğrum yılınızı doğru giriniz.</div>

                                        
                                      <?php } else if(@$_GET['update']=="joberror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen mesleğinizi doğru giriniz.</div>

                                        
                                      <?php } else if(@$_GET['update']=="schoolerror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen okul ve bölümünüzü doğru giriniz.</div>

                                        
                                      <?php } else if(@$_GET['update']=="mekanhata"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen ders verebileceğiniz mekanları doğru giriniz.</div>

                                        
                                      <?php } else if(@$_GET['update']=="derstarzihata"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen ders tarzınızı doğru giriniz.</div>

                                        
                                      <?php } else if(@$_GET['update']=="gsmerror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen GSM numaranızı doğru giriniz.</div>

                                        
                                       <?php } else if(@$_GET['update']=="cityerror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen şehrinizi giriniz.</div>

                                        
                                       <?php } else if(@$_GET['update']=="gendererror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Lütfen cinsiyetinizi giriniz.</div>

                                        
                                     <?php  }  else if(@$_GET['update']=="bannedgsm"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Bu telefon numarası (GSM) kullanılamaz.</div>

                                        
                                      <?php } else if(@$_GET['update']=="existgsm"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Böyle bir telefon numarası (GSM) zaten mevcut.</div>

                                        
                                      <?php } else if(@$_GET['update']=="titleerror"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Girdiğiniz ilan başlığı minimum <b>20</b> karakter uzunluğunda olmalıdır.</div>

                                        
                                      <?php } else if(@$_GET['update']=="ok"){ ?>

                                        <div class="alert alert-success"><i class="fas fa-check"></i> <b>Bilgi güncelleme başarılı !</b> Değişiklikler kısa sürede editör onayından geçip yayınlanacaktır.</div>


                                     <?php }  else if(@$_GET['update']=="error"){ ?>

                                        <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Güncelleme esnasında bir hata oluştu.</div>


                                     <?php } ?>
                                        
                                        <h2 class="title-section">Kişisel Bilgilerim</h2>
                                        <div class="personal-info inner-page-padding"> 

                                            <?php if ($kullanicioturumcek['kullanici_yetki']==2 or $kullanicioturumcek['kullanici_yetki']==1 or $kullanicioturumcek['kullanici_yetki']==3 ) {?>
                                                
                                            
                                            <form class="form-horizontal formaise" action="nedmin/production/netting/musteriislem.php" method="POST" id="personal-info-form">
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Ad*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_ad']; ?>" name="kullanici_ad" maxlength="20" class="form-control" id="ad" type="text">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Soyad*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_soyad']; ?>" name="kullanici_soyad" maxlength="20" class="form-control" id="soyad" type="text">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">E-Mail Adresi*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_mail'] ?>" name="kullanici_mail" disabled="" class="form-control" id="mail" type="text">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Şehir*</label>
                                                <div class="col-sm-9">

                                                            <?php $sehirsec=$db->prepare("SELECT * from sehirler where sehir_id=:id");

                                                            $sehirsec->execute(array(

                                                              "id" => $kullanicioturumcek['kullanici_il'] ));

                                                              $sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC); ?>
                                                    <div class="custom-select">

                                                      <input value="<?php echo $sehircek['sehir_ad']; ?>" name="" disabled="" class="form-control" id="mail" type="text">

                                                     

                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">İlçe*</label>
                                                <div class="col-sm-9">
                                                    <div class="custom-select">
                                                        <select name="kullanici_ilce" id="ilce" class='select2'>

                                                          <?php $ilcesec=$db->prepare("SELECT * from ilceler where sehir_id=:id");

                                                          $ilcesec->execute(array(

                                                            "id" => $sehircek['sehir_id'] 
                                                          ));

                                                           ?>

                                                           <?php while ($ilcecek=$ilcesec->fetch(PDO::FETCH_ASSOC)) {

                                                           if ($ilcecek['ilce_id']==$kullanicioturumcek['kullanici_ilce']) { ?>
                                                            <option selected="" value="<?php echo $ilcecek['ilce_id']; ?>"><?php echo $ilcecek['ilce_ad']; ?></option>
                                                           <?php } else { ?>

                                                            <option value="<?php echo $ilcecek['ilce_id']; ?>"><?php echo $ilcecek['ilce_ad']; ?></option>


                                                        <?php   } ?>


                                                             

                                                           <?php } ?>

                                                           
                                                            
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                           
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Cinsiyet*</label>
                                                <div class="col-sm-9">
                                                    <div class="custom-select">

                                                      <?php if ($kullanicioturumcek['kullanici_cinsiyet']==1) { ?>
                                                       <input value="Kadın" name="" disabled="" class="form-control" id="mail" type="text">
                                                     <?php } else { ?>

                                                      <input value="Erkek" name="" disabled="" class="form-control" id="mail" type="text">


                                                     <?php } ?>
                                                        
                                                    </div>
                                                </div>
                                            </div>  


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Cep Telefonu (GSM)*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_gsm']; ?>" placeholder='Bu alan zorunludur'  class="form-control" maxlength="11" name="kullanici_gsm" id="gsm" type="text">
                                                </div>
                                            </div>  

                                             <div class="form-group">
                                                <label class="col-sm-3 control-label">Doğum Yılı*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_dogum'] ?>" class="form-control" maxlength="4" name="kullanici_dogum" id="dogum" type="text">
                                                </div>
                                            </div>  



                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Meslek*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_meslek'] ?>" name="kullanici_meslek" maxlength="20" class="form-control" id="meslek" type="text">
                                                </div>
                                            </div>  



                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Okul ve Bölüm*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_okulbolum'] ?>" name="kullanici_okulbolum" maxlength="70" class="form-control" id="okulbolum" type="text">
                                                </div>
                                            </div>  

                                             <div class="form-group">
                                                <label class="col-sm-3 control-label">Ders Verebileceğiniz Mekanlar*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_yerler']; ?>" placeholder="Örn. Öğrencinin Evi, Öğretmenin Evi" name="kullanici_yerler" maxlength="200" class="form-control" id="yerler" type="text">
                                                </div>
                                            </div>  

                                             <div class="form-group">
                                                <label class="col-sm-3 control-label">Ders Tarzınız*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_derstarzi']; ?>" name="kullanici_derstarzi" maxlength="70" class="form-control" id="derstarzi" type="text">
                                                </div>
                                            </div>  

                                             <div class="form-group">
                                                <label class="col-sm-3 control-label">Sunduğunuz Kolaylıklar</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_ekstraucret'] ?>" placeholder="Örn. Grup İndirimi, 10'lu Paket X TL vs." name="kullanici_ekstraucret" maxlength="600" class="form-control" id="ekstraucret" type="text">
                                                </div>
                                            </div>  

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">İlan Başlığı*</label>
                                                <div class="col-sm-9">
                                                    <input style="font-weight: bold;" value="<?php echo $kullanicioturumcek['kullanici_ilanbaslik'] ?>" name="kullanici_ilanbaslik" maxlength="150" class="form-control" id="ilanbaslik" type="text">
                                                    <span id="ilanbasliksay" style=""><?php echo 150-strlen($kullanicioturumcek['kullanici_ilanbaslik']); ?></span>

                                                </div>
                                            </div>  

                                            <hr>


                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"><b>İlk Ders Ücretsiz</b></label>
                                                <div class="col-sm-9">
                                                    
                                            <label class="checklabell">


  
 <?php if ($kullanicioturumcek['kullanici_ilkdersucretsiz']==1) { ?>
    <input  name="kullanici_ilkdersucretsiz" checked="checked" value="1"    id="ilkdersucretsiz"  type="checkbox">
<?php } else if ($kullanicioturumcek['kullanici_ilkdersucretsiz']==0) { ?>


<input  name="kullanici_ilkdersucretsiz"  value="0"    id="ilkdersucretsiz"  type="checkbox">

<?php } ?>




  <span class="checkmark"></span>
</label>

<br>

                                                </div>
                                            </div>  

                                            <div class="form-group">
                                                <label class="col-sm-3 control-label"><b>Online Ders Verebilirim</b></label>
                                                <div class="col-sm-9">
                                                    
                                            <label class="checklabell">


  
 <?php if ($kullanicioturumcek['kullanici_onlineders']==1) { ?>
    <input  name="kullanici_onlineders" checked="checked" value="1"    id="onlineders"  type="checkbox">
<?php } else if ($kullanicioturumcek['kullanici_onlineders']==0) { ?>


<input  name="kullanici_onlineders"  value="0"    id="onlineders"  type="checkbox">

<?php } ?>




  <span class="checkmark"></span>
</label>

<br>

                                                </div>
                                            </div>  

                                             <div class="form-group">
                                                <label class="col-sm-3 control-label"><b>Telefon Numaram Gözüksün</b></label>
                                                <div class="col-sm-9">
                                                    
                                            <label class="checklabell">


  
 <?php if ($kullanicioturumcek['kullanici_gsmgozuksun']==1) { ?>

    <input  name="kullanici_gsmgozuksun" checked="checked" value="1"    id="gsmgozuksun"  type="checkbox">

<?php } else if ($kullanicioturumcek['kullanici_gsmgozuksun']==0) { ?>


<input  name="kullanici_gsmgozuksun"  value="0"    id="gsmgozuksun"  type="checkbox">

<?php } ?>




  <span class="checkmark"></span>
</label>

<br>

                                                </div>
                                            </div>  

                                            







                                             <button  name="egitmenkisiselbilgiguncelle"  type="submit" class="update-btn" id="save">Güncelle</button>
                                              </form>


                                          <?php  } ?>


                                          <?php if ($kullanicioturumcek['kullanici_yetki']==0) { ?>
                                              
                                              <form class="form-horizontal formaise" action="nedmin/production/netting/musteriislem.php" method="POST" id="personal-info-form">


                                                 <div class="form-group">
                                                <label class="col-sm-3 control-label">Ad*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_ad']; ?>" name="kullanici_ad" maxlength="20" class="form-control" id="ad" type="text">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">Soyad*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_soyad']; ?>" name="kullanici_soyad" maxlength="20" class="form-control" id="soyad" type="text">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-3 control-label">E-Mail Adresi*</label>
                                                <div class="col-sm-9">
                                                    <input value="<?php echo $kullanicioturumcek['kullanici_mail'] ?>" name="kullanici_mail" disabled="" class="form-control" id="mail" type="text">
                                                </div>
                                            </div>

                                            <button style="margin-left:655px;" name="ogrencikisiselbilgiguncelle"  type="submit" class="update-btn" id="save">Güncelle</button>


                                        </form>


                                         <?php } ?>









                                         




                                        </div> 
                                    </div> 

                                    

                                   
                               


     

                                    

 <?php if ($kullanicioturumcek['kullanici_yetki']==1) { ?>

  <?php if (isset($_GET['aciklamaupdate'])) {  ?>

  <div class="tab-pane fade active in" id="hakkimda">
  
<?php } else { ?>

  <div class="tab-pane fade" id="hakkimda">
  
<?php } ?>
 

  
  
  <h3 class="title-section">Hakkımda</h3>

  <div style="height: 650px;" class="public-profile inner-page-padding" align="right">

    <?php if (@$_GET['aciklamaupdate']=="ok") { ?>

    <div align="left" class="alert alert-success"><i class="fas fa-check"></i> <b>Düzenleme Başarılı !</b> Metniniz Editör Onayından Geçip Profilinizde Hızlıca Yayınlanacaktır.</div>
    
  <?php } else if (@$_GET['aciklamaupdate']=="no") { ?>

    <div align="left" class="alert alert-danger"><i class="fas fa-exclamation"></i> Düzenleme esnasında bir hata oluştu.</div>
    
  <?php }  else if (@$_GET['aciklamaupdate']=="sametext") { ?>

    <div align="left" class="alert alert-warning"><i class="fas fa-info-circle"></i> Düzenleme yapabilmek için metinde değişiklik yapmalısınız.</div>
    
  <?php } ?> 

    <div style="display: none;" align="left" id="karakterhatakutu" class="alert alert-danger"></div>

   

    <form class="formaise" action="nedmin/production/netting/musteriislem.php" id="hakkindaguncelle"  method="POST">

     
    
   <textarea name="egitmenaciklama" id="egitmenhakkinda" style="height: 350px;" class="col-md-12"><?php   echo $kullanicioturumcek['kullanici_hakkinda']; ?></textarea>



 
     
     <span  class="karaktersay" style="margin-right: 30px;"><?php   echo 2000-mb_strlen($kullanicioturumcek['kullanici_hakkinda']); ?></span><button type="submit" name="hakkindaelat" class="update-btn">Düzenle</button>

   

   </form>
  </div>

</div>




  <?php } ?>



 



<?php if (@$kullanicioturumcek['kullanici_yetki']==1) { ?>


                                         <?php if (isset($_GET['deleteb']) or isset($_GET['editb'])) { ?>
                                             <div class="tab-pane fade active in" id="bloglar">
                                         <?php } else { ?>

                                            <div class="tab-pane fade" id="bloglar">


                                       <?php  } ?>
                                        <h2 class="title-section">Bloglarım</h2>
                                        <div class="personal-info inner-page-padding"> 

                                          <?php if (@$_GET['deleteb']=="ok") { ?>

                                            <div class="alert alert-success"><i class="fas fa-check"></i> Blog yazınız başarıyla kaldırıldı !</div>
                                            

                                         <?php } else if(@$_GET['deleteb']=="no"){ ?>

                                          <div class="alert alert-danger"> Blog yazınız kaldırılamadı.</div>


                                       <?php   } ?>


                                          <?php    ?>
                                            
                                           <div class="row more-product-item-wrapper">

                                            <?php   if ($blogsay==0) { ?>
                                              <p style="text-align: center;color: #707070;text-transform: capitalize;">Henüz Blog Yazısı Paylaşmamışsınız. Blog Yazısı Paylaşmak Blog Sayfasında reklamınızı yapmak ve tercih edilme olasılığınızı artırmak için büyük fırsattır.
                                                <br>
                                                <a href="blog.php">Hemen Paylaş !</a></p>
                                           <?php } ?>


                                          <?php while ($blogcek=$blogsec->fetch(PDO::FETCH_ASSOC)) { 

$kategorices=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_id=:id");
$kategorices->execute(array(

"durum" => 1,
"id" => $blogcek['blog_kategori']

));

$kategorikec=$kategorices->fetch(PDO::FETCH_ASSOC);
                                            ?>


                                             <div  class="col-md-6">
                                                <div style="height: 120px;" class="more-product-item">
                                                    
                                                    <div class="more-product-item-details">
                                                        <div class="row">
                                                        <h4 class="col-md-6"><a href="blog-<?php  echo seo($blogcek['blog_baslik'])."-".$blogcek['blog_id']; ?>"><?php echo @$blogcek['blog_baslik'];  ?></a></h4>

                                                        <div align="right" class="col-md-6"><a data-toggle='modal' href='#blogsil'><i style="color:red;" class="fas fa-trash-alt"></i></a>  </div>

                                                        </div>
                                                        <div class="p-title"><?php echo @$kategorikec['kategori_ad']; ?></div>
                                                        
                                                    </div>
                                                </div>
                                            </div>  


                                             <div class="modal fade" id="blogsil"> 
  <div   class="modal-dialog modal-lg">
    <div  class="col-md-3 modal-content">
        <a class="close" data-dismiss="modal" href=""><span>&times;</span></a>
      





    <h4>Bu Blog Yazısını Silmek İstediğinize Emin Misiniz?</h4>
  







<div class="modal-footer">
  
  <a id="blogsil2" href="nedmin/production/netting/musteriislem.php?blogkaldir=ok&blog_id=<?php echo $blogcek['blog_id'] ?>"><button class="btn btn-success btn-xs">Evet</button></a>
    <button class="btn btn-danger btn-xs" data-dismiss="modal">İptal</button>
</div>
    </div>

  </div>



</div>




 
                                            
                                        <?php  } ?>
                                           
                                           
                                        </div>
                                                                      
                                        </div> 
                                    </div>


                                     
 
                             

                                       
                                   <?php } ?>

                                   





                                   


                                     
                                    
                                    
                                                             
                                </div> 

                            </form> 
                        </div>  
                    </div>  
                </div>  
            </div> 
      <?php require_once 'footer.php'; ?>

       <script type="text/javascript">

        


        $('#ilkdersucretsiz').change(function(){


if ($('#ilkdersucretsiz').prop('checked')) {

  
 $('#ilkdersucretsiz').val('1');
  
} else {

  $('#ilkdersucretsiz').val('0');
 
};


              });


 $('#onlineders').change(function(){


if ($('#onlineders').prop('checked')) {

  
 $('#onlineders').val('1');
  
} else {

  $('#onlineders').val('0');
 
};


              });

 

  $('#gsmgozuksun').change(function(){


if ($('#gsmgozuksun').prop('checked')) {

  
 $('#gsmgozuksun').val('1');
  
} else {

  $('#gsmgozuksun').val('0');
 
};




              });
       

$('#ilanbaslik').keydown(function(){

  var ilanbasliksay=$.trim($(this).val()).length;

$(this).css('font-weight','Bold');
$('#ilanbasliksay').text(150-ilanbasliksay);

})


        CKEDITOR.replace('egitmenhakkinda');
                            
                         CKEDITOR.instances['egitmenhakkinda'].on('key', function () {
  //Do something here.


    function stripHtml(html)
{
   var tmp = document.createElement("DIV");
   tmp.innerHTML = html;
   return tmp.textContent || tmp.innerText || "";
};


var editordegeruzunluk=$.trim(stripHtml(CKEDITOR.instances.egitmenhakkinda.getData())).length;






  

$('.karaktersay').html(2000-editordegeruzunluk);
        


    
});

                         


$('#hakkindaguncelle').submit(function(){

  function stripHtml2(html)
{
   var tmp = document.createElement("DIV");
   tmp.innerHTML = html;
   return tmp.textContent || tmp.innerText || "";
};


var editordegeruzunluk2=$.trim(stripHtml2(CKEDITOR.instances.egitmenhakkinda.getData())).length;

  

if (editordegeruzunluk2>2000) {

event.preventDefault();
$('#karakterhatakutu').show();
$('#karakterhatakutu').html("<i class='fas fa-exclamation'></i> Girdiğiniz Tanıtım Yazısı Maksimum <b>2000</b> Karakter Uzunluğunda Olabilir.");


} else if(editordegeruzunluk2<100){

event.preventDefault();
$('#karakterhatakutu').show();
$('#karakterhatakutu').html("<i class='fas fa-exclamation'></i> Girdiğiniz Tanıtım Yazısı Minimum <b>100</b> Karakter Uzunluğunda Olabilir.");

} else {


 if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };

}

});



                          </script>


      <script type="text/javascript">

        
          
           $('#sehir').change(function(){


            $sehirid=$('#sehir').val();


$.ajax({


type : 'POST',
url : 'nedmin/production/netting/ajaxsehirsec2.php',
data : {"sehir_id":$.trim($sehirid)},
success : function(e){


$('#ilce').html(e);


}


});


          }).change();




      </script>

       <script type="text/javascript">

          $(document).ready(function () {
    $("a#blogsil2").one("click", function() {
    $(this).click(function () { return false; });
});
});

         $(document).ready(function () {
    $("a#profilfotosil2").one("click", function() {
    $(this).click(function () { return false; });
});
});
             
          



           </script>

      

