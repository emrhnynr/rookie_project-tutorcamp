<?php require_once 'header.php'; ?>,


<head>
  
  <title>Bildirimlerim - eğitmenkampı</title>
</head>


<?php if (empty($_SESSION['kullanicioturum']) or $kullanicioturumcek['kullanici_yetki']==0) {
    
    header("Location:404");
} ?>

<style type="text/css">



  

 .ul-bildirim li {
  border-bottom: 1px solid #dfdfdf;
  padding-left: 15px;
  padding-right: 15px;
  padding-bottom: 15px;
  padding-top: 15px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-flex;
  display: -ms-flex;
  display: -o-flex;
  display: flex;
}
 .ul-bildirim li:first-child .notify-notification-sign {
  color: #ef6c00;
}
 .ul-bildirim li:last-child {
  border-bottom: none;
}
 .ul-bildirim li:hover {
  background: #ffffff;
}
 .ul-bildirim li .notify-notification-img {
  -webkit-box-flex: 1;
  -moz-flex: 1;
  -webkit-flex: 1;
  flex: 1;
}
 .ul-bildirim li .notify-notification-info {
  margin-left: 10px;
  text-align: left;
  -webkit-box-flex: 3;
  -moz-flex: 3;
  -webkit-flex: 3;
  flex: 3;
}
 .ul-bildirim li .notify-notification-info .notify-notification-subject {
  font-size: 17px;
  color: #8bc34a;
}
 .ul-bildirim li .notify-notification-info .notify-notification-date {
  font-size: 15px;
  color: #707070;
}
 .ul-bildirim li .notify-notification-sign {
  padding-top: 15px;
  -webkit-box-flex: 1;
  -moz-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  color: #b0bec5;
}



</style>
            <div class="pagination-area bg-secondary">
                <div class="container">
                    <div class="pagination-wrapper">
                        <ul>
                            <li><a href="index.php">Anasayfa</a><span> -</span></li>
                            <li>Bildirimlerim</li>
                        </ul>
                    </div>
                </div>  
            </div> 
            <!-- Inner Page Banner Area End Here -->          
            <!-- Settings Page Start Here -->

             




            <div class="settings-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <div class="row settings-wrapper">
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                           
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12"> 

                            
                                    <?php if ($_GET['bildirimsil']=="ok") { ?>

                                        <div class="alert alert-success"><i class="fas fa-check"></i> Bildirim Başarıyla Kaldırıldı!</div>

                                   


                                         





                                   <?php } else if($_GET['bildirimsil']=="no"){ ?>

                                    <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Bildirim silinemedi.</div>


                                  <?php  } ?>
                          
                                <div class="settings-details tab-content">
                                    <div class="tab-pane fade active in" id="gelen">

                                      <?php $bildirimsectumu=$db->prepare("SELECT * from bildirimler where bildirim_durum=:durum and egitmen_id=:id order by bildirim_okundu ASC");


$bildirimsectumu->execute(array(

"id" => $kullanicioturumcek['kullanici_id'],
"durum" => 1

));


$tumbildirimsay=$bildirimsectumu->rowCount();


                                       ?>

                                        <h2 class="title-section">Bildirimlerim</h2>
                                        <div class="personal-info inner-page-padding">


                                          <?php if ($tumbildirimsay>0) { ?>


                                            
                                                    
                                              
                                              <ul class="ul-bildirim">

                                                <?php while ($bildirimcektumu=$bildirimsectumu->fetch(PDO::FETCH_ASSOC)) { 


                                                   

                                                  $blogbildirimsec=$db->prepare("SELECT * from bloglar where blog_durum=:durum and blog_id=:id");
                                                  $blogbildirimsec->execute(array(

"durum" => 1,
"id" => $bildirimcektumu['blog_id']
                                                  ));

                                                  $blogbildirimcek=$blogbildirimsec->fetch(PDO::FETCH_ASSOC);

$bildirimtumukullanicisec=$db->prepare("SELECT * from kullanici where kullanici_durum=:durum and kullanici_id=:id");
$bildirimtumukullanicisec->execute(array(

"durum" => 1,
"id" => $bildirimcektumu['kullanici_id']

));

$bildirimtumukullanicicek=$bildirimtumukullanicisec->fetch(PDO::FETCH_ASSOC);
                                                  ?>
                                                
                                             
                                                    
                                                  <?php if ($bildirimcektumu['bildirim_okundu']==0) { ?>

                                                     <li style="background: rgba(197, 109, 131, 0.1);">
                                                    
                                                 <?php } else if($bildirimcektumu['bildirim_okundu']==1){ ?>

                                                  <li>


                                              <?php   } ?>
                                                        <div class="notify-notification-img">
                                                             <?php if (!empty($bildirimtumukullanicicek['kullanici_resim'])) { ?>


                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="<?php echo $bildirimtumukullanicicek['kullanici_resim']; ?>">
                                                            

                                                      <?php  } else {


                                                        if ($bildirimtumukullanicicek['kullanici_yetki']=="0") {


                                                            if (empty($bildirimtumukullanicicek['kullanici_cinsiyet'])) { ?>


                                                                <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">


                                                                

                                                          <?php  } else if ($bildirimtumukullanicicek['kullanici_cinsiyet']=="1") { ?>

                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/3.jpg">
                                                                

                                                           <?php } else if($bildirimtumukullanicicek['kullanici_cinsiyet']=="2"){ ?>


                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/5.jpg">


                                                           <?php }

                                                            

                                                        } else if($bildirimtumukullanicicek['kullanici_yetki']=="1" or $bildirimtumukullanicicek['kullanici_yetki']=="2" or $bildirimtumukullanicicek['kullanici_yetki']=="3"){


                                                            if ($bildirimtumukullanicicek['kullanici_cinsiyet']=="1") { ?>


                                                                 <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/9.jpg">
                                                              

                                                          <?php  } else { ?>


                                                            <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/11.jpg">



                                                        <?php  }





                                                        }




                                                      } ?>
                                                        </div>
                                                        <div class="notify-notification-info">
                                                            <div  class="notify-notification-subject"> <?php if ($bildirimcektumu['bildirim_turu']==1) { ?>

                                                                   <a style="color:#8bc34a;" href="profil-<?php echo $_SESSION['kullanici_id'] ?>"><?php echo $bildirimtumukullanicicek['kullanici_ad']." ".mb_substr($bildirimtumukullanicicek['kullanici_soyad'],0,1).", profiline bir yorum bıraktı.";?></a>
                                                                    

                                                               <?php } else if($bildirimcektumu['bildirim_turu']==2) { ?>



                                                                    <a style="color:#8bc34a;" href="blog-<?php echo seo($blogbildirimcek['blog_baslik'])."-".$bildirimcektumu['blog_id'];  ?>"><?php  echo $bildirimtumukullanicicek['kullanici_ad']." ".mb_substr($bildirimtumukullanicicek['kullanici_soyad'],0,1).", blog yazına yorum yaptı."; ?></a>






                                                               <?php } ?></div>
                                                            <div class="notify-notification-date"><?php if (substr($bildirimcektumu['bildirim_zaman'],5,2)=="01") {
                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Ocak";
                                            } 
                                            else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="02"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Şubat";



                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="03"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Mart";



                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="04"){

                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Nisan";




                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="05"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Mayıs";



                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="06"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Haz";




                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="07"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Tem";



                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="08"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Ağu";




                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="09"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Eylül";




                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="10"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Ekim";



                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="11"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Kasım";




                                            } else if(substr($bildirimcektumu['bildirim_zaman'],5,2)=="12"){


                                                echo substr($bildirimcektumu['bildirim_zaman'],8,2)." Aralık";




                                            } ?> <?php echo substr($bildirimcektumu['bildirim_zaman'], 0,4)."   ".substr($bildirimcektumu['bildirim_zaman'], 11,5) ?></div>
                                                        </div>
                                                        <div class="notify-notification-sign">
                                                            <a id="silbuton" data-toggle="tooltip" data-placement="bottom" title="Bu Bildirimi Sil" href="nedmin/production/netting/musteriislem.php?bildirim_id=<?php echo $bildirimcektumu['bildirim_id'] ?>&bildirimsil=ok"><i style="color:#e74c3c;" class="fas fa-trash"></i></a>
                                                        </div>
                                                    </li>
                                                


                                                   <?php } ?>

                                                   </ul>
                                            
                                                    
                                               

                                           
                                         <?php } else { ?>

<p align="center"><i class="fas fa-bell-slash"></i> Şuan Herhangi Bir Bildiriminiz Yok</p>


                                        <?php } ?>





                                         





                                        

                                         
                                                <?php $hazirla=$db->prepare("UPDATE bildirimler set 

bildirim_okundu=:bildirim_okundu


where egitmen_id={$_SESSION['kullanici_id']}


");


$update=$hazirla->execute(array(

"bildirim_okundu" => 1



));

 ?>
                                            
                                                                              
                                        </div> 
                                    </div> 






                                 
                                                                           
                                </div> 

                            
                        </div>  
                    </div>  
                </div>  
            </div> 
           <?php require_once 'footer.php'; ?>

           <script type="text/javascript">
             
             $(document).ready(function () {
    $("a#silbuton").one("click", function() {
    $(this).click(function () { return false; });
});
});

           </script>

          