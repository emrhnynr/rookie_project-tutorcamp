<!doctype html>
<?php
ob_start();
session_start();
date_default_timezone_set("Europe/Istanbul");
require_once 'nedmin/production/netting/baglann.php'; 
require_once 'nedmin/production/fonksiyon.php';?>
<style type="text/css">
  .update-btn-arama {
    margin-top: 0px;
    text-align: center;
    color: #ffffff;
    padding: 0px;
    background: #8bc34a;
    text-transform: capitalize;
    font-size: 15px;
    font-weight: 500;
    display: inline-block;
    border: 2px solid #8bc34a;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
  }

 
</style>

<!-- Süresi biten ayrıcalıkları sonlandırma -->





<!---- ------------>

<?php $anaayarsec=$db->prepare("SELECT * from anaayarlar where ayar_id=:id");
$anaayarsec->execute(array(
  "id" => 0
));
$anaayarcek=$anaayarsec->fetch(PDO::FETCH_ASSOC);
$kullanicioturumsec=$db->prepare("SELECT * from kullanici where kullanici_durum=:durum and kullanici_mail=:mail");
$kullanicioturumsec->execute(array(
  "durum" => 1,
  "mail" => @$_SESSION['kullanicioturum']
));
$kullanicioturumcek=$kullanicioturumsec->fetch(PDO::FETCH_ASSOC);
$kullaniciadsoyad=$kullanicioturumcek['kullanici_ad']." ".$kullanicioturumcek['kullanici_soyad'];
$_SESSION['kullanici_id']=$kullanicioturumcek['kullanici_id'];
$egitmenkategoritestsec=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:id");
$egitmenkategoritestsec->execute(array(
  "id" => $_SESSION['kullanici_id']
));
$egitmenkategoritestsay=$egitmenkategoritestsec->rowCount();
$engelliegitmensor=$db->prepare("SELECT * from engelliegitmenler where kullanici_mail=:mail");
$engelliegitmensor->execute(array(
  "mail" => @$_SESSION['kullanicioturum']
));
$engelliegitmensay=$engelliegitmensor->rowCount();
if ($engelliegitmensay==1) {
  $engelliegitmensil=$db->prepare("DELETE from engelliegitmenler where kullanici_mail=:mail");
  $engelliegitmensil->execute(array(
    "mail" => $_SESSION['kullanicioturum']
  ));

  unset($_SESSION['kullanicioturum']);
  unset($_SESSION['kullanici_id']);
  header("Location:index");
}
$songirisim=$kullanicioturumcek['kullanici_songiris'];
$suan=time(); 
$fark=$suan-$songirisim;
if ($fark>600) {

  $hazirla=$db->prepare("UPDATE kullanici set 
    kullanici_songiris=:kullanici_songiris
    where kullanici_id={$kullanicioturumcek['kullanici_id']}
    ");
  $derle=$hazirla->execute(array(
    "kullanici_songiris" => date("Y-m-d H:i:s")
  ));
};


   $ipAdres=$_SERVER['REMOTE_ADDR']; 
  

   
   
  
  

?>
<html class="no-js" lang="">
<head>

  <!-- Hotjar Tracking Code for www.egitmenkampi.com -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:1877612,hjsv:6};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
</script>


<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(66736708, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/66736708" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="description" content="<?php echo $anaayarcek['ayar_description'] ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="<?php echo $anaayarcek['ayar_keywords'] ?>">
  <meta name="author" content="<?php echo $anaayarcek['ayar_author'] ?>" > 
  <!-- Favicon -->
  <link s rel="shortcut icon" type="image/x-icon" href="img/favicon.png"> <!-- Buraya logo gelicek -->
  <!-- Normalize CSS --> 
  <link rel="stylesheet" href="css/normalize.css">
  <!-- Main CSS --> 
  <link rel="stylesheet" href="css/main.css">
  <!-- Bootstrap CSS --> 
  <link rel="stylesheet" href="css/bootstrap.min.css">

 <link rel="stylesheet" type="text/css" href="src/sweetalert2.scss">
  <!-- Animate CSS --> 
  <link rel="stylesheet" href="css/animate.min.css">
  <!-- CK EDİTÖR -->
  <script src="ckeditor/ckeditor.js"></script>
  <!-- Font-awesome CSS-->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Owl Caousel CSS -->
  <link rel="stylesheet" href="vendor/OwlCarousel/owl.carousel.min.css">
  <link rel="stylesheet" href="vendor/OwlCarousel/owl.theme.default.min.css">
  <!-- Main Menu CSS --> 
  <link rel="stylesheet" href="css/meanmenu.min.css">
  <!-- Select2 CSS -->
  <link rel="stylesheet" href="css/select2.min.css">
  <!-- Datetime Picker Style CSS -->
  <link rel="stylesheet" href="css/jquery.datetimepicker.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
  <!-- ReImageGrid CSS -->
  <link rel="stylesheet" href="css/reImageGrid.css">
  <!-- Switch Style CSS -->
  <link rel="stylesheet" href="css/hover-min.css">
  <!-- Nouislider Style CSS -->
  <link rel="stylesheet" href="vendor/noUiSlider/nouislider.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="style.css">
  <!-- Modernizr Js -->
  <script src="js/modernizr-2.8.3.min.js"></script>
  <script type="text/javascript" src="src/sweetalert2.js"></script>
  <style type="text/css">
    .notify-message .tumunugoster a {
      background: white;
      border-radius: 0px;
      text-align: center;
      display: block;
      height: 20px;
      width: 100%;
      color: #8bc34a;
      font-size: 14px;
      margin-left:45px;
    }
    .notify-notification .tumunugoster a {
      background: white;
      border-radius: 0px;
      text-align: center;
      display: block;
      height: 20px;
      width: 100%;
      color: #8bc34a;
      font-size: 14px;
      margin-left:45px;
    }

@media screen and (max-width: 991px) {

#enkapsamli {

display: none;

}

}



  </style>
</head>
<body>


  
 
<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->
<!-- Add your site or application content here -->
<!-- Preloader Start Here -->
<div id="preloader"></div>
<!-- Preloader End Here -->
<!-- Main Body Area Start Here -->
<div id="wrapper">
  <!-- Header Area Start Here -->
  <header> 
     <div style="padding: 7px;display: none; background-color: #EBE10D;font-family: arial;font-size: 15px;" align="center" id="goruspaylas" class="col-md-12"><b>Görüşlerinizi Paylaşın</b> | Sizlere mükemmel hizmeti verebilmek için sitemizi sürekli olarak geliştirmeye çalışıyoruz ve bunun için siz değerli eğitmenlerimizden ilham alıyoruz !<br>
      <a href="iletisim.php">İletişim</a> modülünü kullanarak tarafımıza şikayet ve önerilerinizi belirtmenizi rica ediyoruz. İyi Dersler !</div>
    <div id="header2" class="header2-area right-nav-mobile">
      <div class="header-top-bar">
        <div class="container">
          <div class="row"> 
            <div class="col-lg-2 col-md-2 col-sm-2 hidden-xs">
              <div style="width: 175px;border-right:0.5px solid rgba(112, 112, 112,0.4);" class="logo-area">
                <a href="index.php"><img style="width: 165px;height: 38px;" class="img-responsive" src="<?php echo $anaayarcek['ayar_logo']; ?>" alt="logo"></a>
              </div>
            </div>
            <div class="col-md-10">
              <div class="row">
                  
                  <div class='col-md-6' id='enkapsamli'>
                      
                      <p style='margin-top:30px;color:#707070;'>Özel Ders Almanın Kolay Yolu</p>
                  </div>



               
               
                <div class="col-md-6" style="min-width: 450px; float: right;">

                  <ul class="profile-notification">
                    <li>
                      <div class="notify-contact"></div>
                    </li>
                    <?php if (isset($_SESSION['kullanicioturum'])) { ?>
                      <style type="text/css">
                        @media only screen and (max-width: 415px) {
                          #cikisyapbuton {
                            padding: 8px;
                          }
                          #cikisyapbuton {
                            display: none;
                          }
                        }
                      </style>

                      <?php if ($kullanicioturumcek['kullanici_yetki']==0) { ?>
                        <li>
                          <div data-toggle='tooltip' data-placement='bottom'  class="notify-notification">
                          
                          <a href="javascript:void(0);"><i class="far fa-smile-beam" aria-hidden="true"></i></a>
                        
                        </div>
                        </li>
                     <?php } ?>

                      <?php $favorisec1=$db->prepare("SELECT * from kullanicifavoriler where favalan_id=:id order by kayit_zaman DESC");
                      $favorisec1->execute(array(
                        "id" => $_SESSION['kullanici_id']
                      ));
                      $favorisay1=$favorisec1->rowCount();
                      ?>
                      <li>
                        <div data-toggle='tooltip' data-placement='bottom' title='Favorilerim' class="notify-notification">
                          <a href="favorilerim"><i class="fa fa-bookmark" aria-hidden="true"></i><span style="background-color:#8bc34a;"><?php if ($favorisay1>99) {
                            echo "99+";
                          } else {
                            echo $favorisay1;
                          } ?></span></a>
                        </div>
                      </li>
                      
                      <li>
                        <?php if ($kullanicioturumcek['kullanici_yetki']==1 or $kullanicioturumcek['kullanici_yetki']==2 or $kullanicioturumcek['kullanici_yetki']==3 ) { ?>
                          <?php $bildirimsec=$db->prepare("SELECT * from bildirimler where bildirim_durum=:durum and bildirim_okundu=:okundu and egitmen_id=:id order by bildirim_zaman DESC"); 
                          $bildirimsec->execute(array(
                            "durum" => 1,
                            "okundu" => 0,
                            "id" => $kullanicioturumcek['kullanici_id']
                          ));
                          $bildirimsay=$bildirimsec->rowCount();
                          ?>
                          <div data-toggle='tooltip' data-placement='bottom' title='Bildirimlerim' class="notify-notification">
                            <a href="bildirimlerim"><i class="fas fa-bell"></i><span><?php if ($bildirimsay>99) {
                              echo "99+";
                            } else {
                              echo $bildirimsay;
                            } ?></span></a>
                            <?php if ($bildirimsay>0) { 
                              $bildirimsayisi=0;
                              ?>
                              <ul>
                                <?php while ($bildirimcek=$bildirimsec->fetch(PDO::FETCH_ASSOC)) { 
                                  $bildirimsayisi++;
                                  if ($bildirimsayisi<=5) { ?>
                                    <?php $bildirimkullanicisec=$db->prepare("SELECT * from kullanici where kullanici_durum=:durum and kullanici_id=:id");
                                    $bildirimkullanicisec->execute(array(
                                      "durum" => 1,
                                      "id" => $bildirimcek['kullanici_id']
                                    ));
                                    $bildirimkullanicicek=$bildirimkullanicisec->fetch(PDO::FETCH_ASSOC);
                                    ?>
                                    <li>
                                      <div class="notify-notification-img">
                                        <?php if (!empty($bildirimkullanicicek['kullanici_resim'])) { ?>
                                          <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="<?php echo $bildirimkullanicicek['kullanici_resim']; ?>">
                                        <?php } else {
                                          if ($bildirimkullanicicek['kullanici_yetki']=="0") {
                                            if (empty($bildirimkullanicicek['kullanici_cinsiyet'])) { ?>
                                              <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">
                                            <?php } else if ($bildirimkullanicicek['kullanici_cinsiyet']=="1") { ?>
                                              <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/3.jpg">

                                            <?php } else if($bildirimkullanicicek['kullanici_cinsiyet']=="2"){ ?>
                                              <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/5.jpg">
                                            <?php }
                                          } else if($bildirimkullanicicek['kullanici_yetki']=="1" or $bildirimkullanicicek['kullanici_yetki']=="2" or $bildirimkullanicicek['kullanici_yetki']=="3"){
                                            if ($bildirimkullanicicek['kullanici_cinsiyet']=="1") { ?>
                                              <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/9.jpg">

                                            <?php } else { ?>
                                              <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/11.jpg">
                                            <?php }
                                          }
                                        } ?>
                                      </div>
                                      <div class="notify-notification-info">
                                        <div class="notify-notification-subject">
                                          <?php if ($bildirimcek['bildirim_turu']==1) { ?>
                                            <?php echo $bildirimkullanicicek['kullanici_ad']." ".mb_substr($bildirimkullanicicek['kullanici_soyad'],0,1).", profiline bir yorum bıraktı.";

                                          } else if($bildirimcek['bildirim_turu']==2) {
                                            echo $bildirimkullanicicek['kullanici_ad']." ".mb_substr($bildirimkullanicicek['kullanici_soyad'],0,1).", blog yazına yorum yaptı.";
                                          } ?>
                                        </div>
                                        <div class="notify-notification-date"><?php if (substr($bildirimcek['bildirim_zaman'],5,2)=="01") {
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Ocak";
                                        } 
                                        else if(substr($bildirimcek['bildirim_zaman'],5,2)=="02"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Şubat";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="03"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Mart";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="04"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Nisan";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="05"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Mayıs";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="06"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Haz";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="07"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Tem";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="08"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Ağu";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="09"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Eylül";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="10"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Ekim";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="11"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Kasım";
                                        } else if(substr($bildirimcek['bildirim_zaman'],5,2)=="12"){
                                          echo substr($bildirimcek['bildirim_zaman'],8,2)." Aralık";
                                        } ?> <?php echo substr($bildirimcek['bildirim_zaman'], 0,4)." ".substr($bildirimcek['bildirim_zaman'], 11,5) ?>
                                      </div>
                                    </div>
                                  </li>
                                <?php } ?>
                              <?php } ?>
                              <li>
                                <div class="notify-message-subject tumunugoster"><a href="bildirimlerim">Tümünü göster</a></div>
                              </li>
                            </ul>
                          <?php } ?>
                        </div>
                      </li>
                    <?php } ?>
                    <li>
                      <div data-toggle='tooltip' data-placement='bottom' title='Mesajlarım' class="notify-message">
                        <?php $mesajsec=$db->prepare("SELECT * from mesajlar where mesaj_okundu=:okundu and mesaj_alici=:alici and mesaj_turu=:turu order by mesaj_zaman DESC");
                        $mesajsec->execute(array(
                          "okundu" => 0,
                          "alici" => $_SESSION['kullanici_id'],
                          "turu" => 0
                        ));
                        $mesajsay=$mesajsec->rowCount();?>
                        <a href="mesajlarim.php"><i class="fas fa-envelope"></i> <span><?php if ($mesajsay>99) {
                          echo "99+";
                        } else {
                          echo $mesajsay;
                        } ?></span></a>
                        <?php if ($mesajsay>0) { ?>
                          <ul>
                            <?php $headermesajsay=0; ?>
                            <?php while ($mesajcekheader=$mesajsec->fetch(PDO::FETCH_ASSOC)) {
                              $headermesajsay++;
                              if ($headermesajsay<=5) { ?>
                                <?php 
                                $kullanicisecheader=$db->prepare("SELECT * from kullanici where kullanici_id=:id and kullanici_durum=:durum");
                                $kullanicisecheader->execute(array(
                                  "durum" => 1,
                                  "id" => $mesajcekheader['mesaj_gonderen']
                                ));
                                $kullanicicekheader=$kullanicisecheader->fetch(PDO::FETCH_ASSOC);
                                ?>
                                <li>
                                  <div class="notify-message-img">
                                    <?php if (!empty($kullanicicekheader['kullanici_resim'])) { ?>
                                      <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="<?php echo $kullanicicekheader['kullanici_resim']; ?>">
                                    <?php } else {
                                      if ($kullanicicekheader['kullanici_yetki']=="0") {
                                        if (empty($kullanicicekheader['kullanici_cinsiyet'])) { ?>
                                          <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">
                                        <?php } else if ($kullanicicekheader['kullanici_cinsiyet']=="1") { ?>
                                          <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/3.jpg">
                                        <?php } else if($kullanicicekheader['kullanici_cinsiyet']=="2"){ ?>
                                          <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/5.jpg">
                                        <?php }
                                      } else if($kullanicicekheader['kullanici_yetki']=="1" or $kullanicicekheader['kullanici_yetki']=="2" or $kullanicicekheader['kullanici_yetki']=="3"){
                                        if ($kullanicicekheader['kullanici_cinsiyet']=="1") { ?>
                                          <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/9.jpg">
                                        <?php } else { ?>
                                          <img style="width: 48px;height: 48px;" class="img-responsive img-circle" src="dimg/11.jpg">
                                        <?php }
                                      }
                                    } ?>
                                  </div>
                                  <div class="notify-message-info">
                                    <div class="notify-message-sender"><?php echo $kullanicicekheader['kullanici_ad']." ".mb_substr($kullanicicekheader['kullanici_soyad'], 0,1)."."; ?></div>
                                    <div class="notify-message-subject"><?php if (mb_strlen($mesajcekheader['mesaj_icerik'])>60) { 
                                      echo mb_substr($mesajcekheader['mesaj_icerik'],0,60)."...";
                                    } else {
                                      echo $mesajcekheader['mesaj_icerik'];
                                    } ?></div>
                                    <div class="notify-message-date"><?php if (substr($mesajcekheader['mesaj_zaman'],5,2)=="01") {
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Ocak";
                                    } 
                                    else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="02"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Şubat";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="03"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Mart";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="04"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Nisan";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="05"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Mayıs";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="06"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Haz";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="07"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Tem";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="08"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Ağu";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="09"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Eylül";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="10"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Ekim";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="11"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Kasım";
                                    } else if(substr($mesajcekheader['mesaj_zaman'],5,2)=="12"){
                                      echo substr($mesajcekheader['mesaj_zaman'],8,2)." Aralık";
                                    } ?> <?php echo substr($mesajcekheader['mesaj_zaman'], 0,4)." ".substr($mesajcekheader['mesaj_zaman'], 11,5) ?></div>
                                  </div>
                                </li>
                              <?php } ?>
                            <?php } ?>
                            <li><div class="notify-message-subject tumunugoster"><a href="mesajlarim">Tümünü göster</a></div></li>
                          </ul>
                        <?php } ?>
                      </div>
                    </li>
                    <li>
                      <div class="user-account-info">
                        <div class="user-account-info-controler">
                          <div class="user-account-img">
                            <?php if (!empty($kullanicioturumcek['kullanici_resim'])) { ?>
                              <img style="width: 45px;height: 45px;" class="img-responsive img-circle" src="<?php echo $kullanicioturumcek['kullanici_resim']; ?>">
                            <?php } else {
                              if ($kullanicioturumcek['kullanici_yetki']=="0" or $kullanicioturumcek['kullanici_yetki']=="4") {
                                if (empty($kullanicioturumcek['kullanici_cinsiyet'])) { ?>
                                  <img style="width: 45px;height: 45px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">

                                <?php } else if ($kullanicioturumcek['kullanici_cinsiyet']=="1") { ?>
                                  <img style="width: 45px;height: 45px;" class="img-responsive img-circle" src="dimg/3.jpg">

                                <?php } else if($kullanicioturumcek['kullanici_cinsiyet']=="2"){ ?>
                                  <img style="width: 45px;height: 45px;" class="img-responsive img-circle" src="dimg/5.jpg">
                                <?php }
                              } else if($kullanicioturumcek['kullanici_yetki']=="1" or $kullanicioturumcek['kullanici_yetki']=="2" or $kullanicioturumcek['kullanici_yetki']=="3"){
                                if ($kullanicioturumcek['kullanici_cinsiyet']=="1") { ?>
                                  <img style="width: 45px;height: 45px;" class="img-responsive img-circle" src="dimg/9.jpg">

                                <?php } else { ?>
                                  <img style="width: 45px;height: 45px;" class="img-responsive img-circle" src="dimg/11.jpg">
                                <?php }
                              }
                            } ?>
                          </div>
                          <div class="user-account-title">
                            <div style="font-size: 12px; min-width: 100px; padding-top: 5px" class="user-account-name"><?php if (mb_strlen($kullaniciadsoyad)>13) { 
                              echo mb_substr($kullaniciadsoyad,0,13)."...";
                            } else { 
                              echo $kullaniciadsoyad; ?>
                              <?php } ?></div>
                              <div class="user-account-balance"><?php if ($kullanicioturumcek['kullanici_yetki']=="0" or $kullanicioturumcek['kullanici_yetki']=="4") { ?>
                                Öğrenci
                              <?php } else if($kullanicioturumcek['kullanici_yetki']=="1" or $kullanicioturumcek['kullanici_yetki']=="2" or $kullanicioturumcek['kullanici_yetki']=="3") { ?>
                                Eğitmen
                              <?php } ?>
                            </div>
                          </div>
                          <div class="user-account-dropdown">
                            <?php if (isset($_SESSION['kullanicioturum'])) { ?>
                              <i class="fa fa-angle-down" aria-hidden="true"></i>
                            <?php } ?>

                          </div>
                        </div>
                        <?php if (isset($_SESSION['kullanicioturum'])) { ?>
                          <ul>

                            <?php if ($kullanicioturumcek['kullanici_yetki']==1 or $kullanicioturumcek['kullanici_yetki']==0) { ?>
                             <li><a href="hesap-ayarlari.php">Hesap Ayarları</a></li>
                         <?php   } ?>

                         <?php if ($kullanicioturumcek['kullanici_onecikan']==1) { ?>
                             <li><a href="ayricalikli-uyeligim">Ayrıcalıklı Üyeliğim</a></li>
                             <li><a href='oneriler'>Öneriler</a></li>
                         <?php   } ?>

                        

                         <?php if ($kullanicioturumcek['kullanici_yetki']==1 or $kullanicioturumcek['kullanici_yetki']==3) { ?>
                             <li><a href="fotografim">Profil Fotoğrafı Değiştir</a></li>
                         <?php   } ?>


                         <?php if ($kullanicioturumcek['kullanici_yetki']==1 or $kullanicioturumcek['kullanici_yetki']==3) { ?>
                             <li><a href="sertifikalarim">Sertifika Yükle</a></li>
                         <?php   } ?>
                            
                            <?php if ($kullanicioturumcek['kullanici_yetki']==1) { ?>
                              <li><a href="profil-<?php echo $kullanicioturumcek['kullanici_id']; ?>">Profilim</a></li>
                              

                            <?php } ?>
                            <li><a href="logout">Çıkış Yap</a></li>
                          </ul>
                        <?php } ?>
                      </div>
                    </li>
                    <li><a id="cikisyapbuton" class="apply-now-btn" href="logout.php?kullanici_id=<?php echo $_SESSION['kullanici_id']; ?>" id="logout-button">Çıkış Yap <i class="fas fa-sign-in-alt" style="display: none"></i></a></li>
                  <?php } else { ?>
                    <style type="text/css">
                      @media only screen and (max-width: 767px) {
                      

                        .header2-area.right-nav-mobile .profile-notification {
                          right: -234px;
                        }


                     
                      }
                      @media only screen and (max-width: 479px) {
                        

                        

                        .header2-area.right-nav-mobile .profile-notification {
                          right: -198px;
                        }



                      
                      }
                      @media only screen and (max-width: 320px) {
                        

                        .header2-area.right-nav-mobile .profile-notification {
                          right: -180px;
                        }


                    
                      }
                    </style>
                    <li>
                      <a id="cikisyapbuton" class="apply-now-btn-color" href="egitmenkayit.php">Kayıt Ol <i class="fas fa-user-plus"></i></a>
                    </li>
                    <li>
                      <a id="cikisyapbuton" class="apply-now-btn" href="login.php">Giriş Yap <i class="fas fa-sign-in-alt"></i></a>
                    </li>
                  <?php } ?>
                </ul>
              </div>
            </div> 
          </div> 
        </div> 
      </div>
    </div>
    <div class="main-menu-area bg-primaryText" id="sticker">
      <div class="container">
        <nav id="desktop-nav">
          <ul>
            <li<?php if (strstr($_SERVER['SCRIPT_NAME'], "index.php")) {echo " class='active'";} ?>><a href="index.php">Anasayfa</a></li>
            <?php $menusec=$db->prepare("SELECT * from menu where menu_durum=:durum order by menu_sira ASC");
            $menusec->execute(array(
              "durum" => 1
            ));
            while ($menucek=$menusec->fetch(PDO::FETCH_ASSOC)) { ?>


<?php if ($kullanicioturumcek['kullanici_yetki']==1 and $kullanicioturumcek['kullanici_onecikan']!=1) { ?>

  <?php if ($kullanicioturumcek['kullanici_il']==35 or $kullanicioturumcek['kullanici_il']==36 or $menucek['menu_id']!=12) { ?>

<li<?php if (strstr($_SERVER['SCRIPT_NAME'], $menucek['menu_url'])) {echo " class='active'";} ?>><a href="<?php echo $menucek['menu_url']; ?>"><?php echo $menucek['menu_ad']; ?></a></li>
 
<?php } ?>



<?php } else if($kullanicioturumcek['kullanici_yetki']==1 and $kullanicioturumcek['kullanici_onecikan']==1){ ?>


<?php if ($menucek['menu_id']!=12) { ?>

  <li<?php if (strstr($_SERVER['SCRIPT_NAME'], $menucek['menu_url'])) {echo " class='active'";} ?>><a href="<?php echo $menucek['menu_url']; ?>"><?php echo $menucek['menu_ad']; ?></a></li>

<?php } ?>


<?php } else { ?>

<?php if ($menucek['menu_id']!=12) { ?>
 
<li<?php if (strstr($_SERVER['SCRIPT_NAME'], $menucek['menu_url'])) {echo " class='active'";} ?>><a href="<?php echo $menucek['menu_url']; ?>"><?php echo $menucek['menu_ad']; ?></a></li>
 
<?php } ?>

<?php } ?>


              
            <?php } ?>
          </ul>
        </nav>
      </div>
    </div>
  </div>
  <!-- Mobile Menu Area Start -->
  <div class="mobile-menu-area">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="mobile-menu">
            <nav id="dropdown">
              <ul>
                <li class="active"><a href="index.php">Anasayfa</a></li>
                <?php $menusec=$db->prepare("SELECT * from menu where menu_durum=:durum order by menu_sira ASC");
                $menusec->execute(array(
                  "durum" => 1
                ));
                while ($menucek=$menusec->fetch(PDO::FETCH_ASSOC)) { ?>

                 
                  <?php if ($kullanicioturumcek['kullanici_yetki']==1 and $kullanicioturumcek['kullanici_onecikan']!=1) { ?>
                  
                  
                  <?php if ($kullanicioturumcek['kullanici_il']==35 or $menucek['menu_id']!=12) { ?>

                    
                      
                   

                     <li<?php if (strstr($_SERVER['SCRIPT_NAME'], $menucek['menu_url'])) {echo " class='active'";} ?>><a href="<?php echo $menucek['menu_url']; ?>"><?php echo $menucek['menu_ad']; ?></a></li>

                      
<?php } ?>
                  <?php  } else if($kullanicioturumcek['kullanici_yetki']==1 and $kullanicioturumcek['kullanici_onecikan']==1){ ?>

                    <?php if ($menucek['menu_id']!=12) { ?>
                      
                       <li<?php if (strstr($_SERVER['SCRIPT_NAME'], $menucek['menu_url'])) {echo " class='active'";} ?>><a href="<?php echo $menucek['menu_url']; ?>"><?php echo $menucek['menu_ad']; ?></a></li>

                  <?php  } ?>


                   




                  <?php } else { ?>

                    <?php if ($menucek['menu_id']!=12) { ?>

                       <li<?php if (strstr($_SERVER['SCRIPT_NAME'], $menucek['menu_url'])) {echo " class='active'";} ?>><a href="<?php echo $menucek['menu_url']; ?>"><?php echo $menucek['menu_ad']; ?></a></li>



                  <?php  } ?>


              <?php    } ?>
                

                <?php } ?>
              </ul>
            </nav>
          </div> 
        </div>
      </div>
    </div>
  </div> 
  <?php $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_ust=:ust and kategori_durum=:durum order by kategori_sira ASC");
  $kategorisec->execute(array(
    "ust" => 0,
    "durum" => 1
  )); ?>
</header>

<!-- jquery-->  
<script src="js\jquery-2.2.4.min.js" type="text/javascript"></script>
