<?php  require_once 'header.php'; ?>

<head>
  
<title>Kurs Bilgilerim - eğitmenkampı</title>

</head>


<?php if ($kullanicioturumcek['kullanici_yetki']!=1) {
  header("Location:404");
} ?>

<head>
    
    <style type="text/css">

    .checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}

        
        .product-details-tab-area .product-details-title {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-flex;
  display: -ms-flex;
  display: -o-flex;
  display: flex;
  text-align: center;
  border-bottom: 1px solid #dfdfdf;
}
@media only screen and (max-width: 500px) {
   .product-details-tab-area .product-details-title {
    display: inherit;
  }
}
 .product-details-tab-area .product-details-title li {
  -webkit-box-flex: 1;
  -moz-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  position: relative;
  border-right: 1px solid #dfdfdf;
  -webkit-transition: all 0.5s ease-out;
  -moz-transition: all 0.5s ease-out;
  -ms-transition: all 0.5s ease-out;
  -o-transition: all 0.5s ease-out;
  transition: all 0.5s ease-out;
}
@media only screen and (max-width: 500px) {
   .product-details-tab-area .product-details-title li {
    border-right: none;
    border-bottom: 1px solid #dfdfdf;
  }
}
 .product-details-tab-area .product-details-title li:last-child {
  border-right: none;
  border-bottom: none;
}
 .product-details-tab-area .product-details-title li:before {
  content: "";
  height: 3px;
  width: 100%;
  background: #8bc34a;
  position: absolute;
  z-index: 1;
  bottom: 0;
  left: 0;
  right: 0;
  margin: 0 auto;
  opacity: 0;
  visibility: hidden;
}
 .product-details-tab-area .product-details-title li a {
  font-size: 16px;
  display: block;
  width: 100%;
  color: #70838d;
  padding: 17px 0;
  text-transform: capitalize;
  -webkit-transition: all 0.5s ease-out;
  -moz-transition: all 0.5s ease-out;
  -ms-transition: all 0.5s ease-out;
  -o-transition: all 0.5s ease-out;
  transition: all 0.5s ease-out;
}
@media only screen and (max-width: 479px) {
   .product-details-tab-area .product-details-title li a {
    display: block!important;
  }
}
 .product-details-tab-area .product-details-title li:hover a {
  color: #263238;
}
 .product-details-tab-area .product-details-title .active a {
  color: #263238;
  text-decoration: none;
}
 .product-details-tab-area .product-details-title .active:before {
  opacity: 1;
  visibility: visible;
}
 .product-details-tab-area .tab-content {
  padding-top:  30px;
}
 .product-details-tab-area .tab-content .product-details-content li {
  position: relative;
  padding-left: 15px;
  font-size: 16px;
  color: #707070;
  margin-bottom: 10px;
  display: inline-block;
  width: 40%;
}
@media only screen and (max-width: 500px) {
   .product-details-tab-area .tab-content .product-details-content li {
    display: inherit;
    width: 100%;
  }
}
 .product-details-tab-area .tab-content .product-details-content li:before {
  content: "\f105";
  position: absolute;
  z-index: 1;
  font-family: fontawesome;
  top: 0;
  left: 0;
  font-size: 16px;
  color: #8bc34a;
};
    </style>
</head>







            <!-- Header Area End Here -->
            <!-- Main Banner 1 Area Start Here -->
           
            <!-- Main Banner 1 Area End Here --> 
            <!-- Inner Page Banner Area Start Here -->
            
            <!-- Inner Page Banner Area End Here -->          
            <!-- Registration Page Area Start Here -->
            <div class="registration-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <h2 class="title-section">Kurs Bilgilerim</h2>



                    <div class="registration-details-area inner-page-padding">

                        

                        <?php if (@$_GET['update']=="no") { ?>
                          <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Güncelleme Esnasında Bir Hata Oluştu.</div>
                        <?php }  ?> <?php if(@$_GET['update']=="ok") { ?>


                          <div class="alert alert-success"><i class='fas fa-check'></i> <b>Güncelleme İşlemi Başarılı !</b> Değişiklikleriniz Editör Onayından Geçtiği Takdirde Hızlıca Yayınlanacaktır.</div>


                        <?php } ?>

                        <?php if (@$_GET['update']=="yetersizsecim") { ?>
                          
                          <div class="alert alert-danger"> Kursunuz İçin En Az <b>1</b> İlçe / Semt Seçmelisiniz.</div>
                      <?php  } ?>
                        
                       
<div class="public-profile inner-page-padding">

                                          



                                          

                                              <div class="row profile-wrapper">
                        
                        <div  class="col-lg-12 col-md-8 col-sm-8 col-xs-12"> 
                            <div  class="tab-content">


                            
                               
                                


                                    <?php   $egitmenkategorisec=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:egitmenid and kategori_enalt=:enalt and egitmen_kategoridurum=:durum"); 

                                    $egitmenkategorisec->execute(array(

                                        "egitmenid" => $_SESSION['kullanici_id'],
                                        "durum" => 1,
                                        "enalt" => 1

                                    ));

                                    $say=0;

                                    ?>
                                  

                                  <div  class="product-details-tab-area">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <ul class="product-details-title">

                                                <?php while ($egitmenkategoricek=$egitmenkategorisec->fetch(PDO::FETCH_ASSOC)) { $say++; 


                                                    $kategorisecegitmen=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
                                                    $kategorisecegitmen->execute(array(

                                                        "id" => $egitmenkategoricek['kategori_id'])
                                                    );

                                                    $kategoricekegitmen=$kategorisecegitmen->fetch(PDO::FETCH_ASSOC); ?>


                                                     <?php if ($say==1) { ?>

                                                         <li class="active"><a href="#<?php echo $egitmenkategoricek['kategori_id']; ?>" data-toggle="tab" aria-expanded="false"><?php echo $kategoricekegitmen['kategori_ad']; ?></a></li>

                                                   <?php  } else { ?>

                                                     <li><a href="#<?php echo $kategoricekegitmen['kategori_id']; ?>" data-toggle="tab" aria-expanded="false"><?php echo $kategoricekegitmen['kategori_ad']; ?></a></li>


                                                  <?php } ?>

                                             <?php   } ?>
                                               
                                                
                                            </ul>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12">
                                            <div  class="tab-content">


                                                <?php $egitmenkategorisec2=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:id and kategori_enalt=:enalt and egitmen_kategoridurum=:durum");

                                                $egitmenkategorisec2->execute(array(

                                                    "id" => $_SESSION['kullanici_id'],
                                                    "enalt" => 1,
                                                    "durum" => 1)) ?>

                                                <?php $say2=0; while ($egitmenkategoricek2=$egitmenkategorisec2->fetch(PDO::FETCH_ASSOC)) { $say2++; 

                                                  

                                                    $kategorisecegitmen2=$db->prepare("SELECT * from kategoriler where kategori_id=:id");

                                                    $kategorisecegitmen2->execute(array(

                                                        "id" => $egitmenkategoricek2['kategori_id']

                                                    ));

                                                    $kategoricekegitmen2=$kategorisecegitmen2->fetch(PDO::FETCH_ASSOC);

                                                     ?>


                                                  <?php if ($say2==1) { ?>
                                                      <div  class="tab-pane fade active in" id="<?php echo $egitmenkategoricek2['kategori_id']; ?>">
                                                 <?php } else { ?>

                                                    <div class="tab-pane fade" id="<?php echo $egitmenkategoricek2['kategori_id']; ?>">
                                                <?php } ?>


                                                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">

                                <div  class="panel-group help-page-wrapper" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#<?php echo $say2; ?>">
                                          <?php echo $kategoricekegitmen2['kategori_ad']; ?> Dersini Verebileceğiniz İlçe / Semtler
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="<?php echo $say2; ?>" role="tabpanel" class="panel-collapse collapse in">
                                    <div style="background: white;" class="panel-body">

                                        <?php $egitmenilcesec=$db->prepare("SELECT * from ilceler where ilce_durum=:durum and sehir_id=:id");

                                        $egitmenilcesec->execute(array(

                                            "durum" => 1,
                                            "id" => $kullanicioturumcek['kullanici_il']
                                        ));  ?>


                                        <form class="form-horizontal checkboxform" action="nedmin/production/netting/musteriislem.php" method="POST" id="checkboxform">



                                    <?php   while ($egitmenilcecek=$egitmenilcesec->fetch(PDO::FETCH_ASSOC)) {

                                       $checkboxkontrolsec=$db->prepare("SELECT * from kategoriilce where egitmen_id=:egitmenid and kategori_id=:katid and ilce_id=:ilceid");

                                       $checkboxkontrolsec->execute(array(

                                        "egitmenid" => $_SESSION['kullanici_id'],
                                        "katid" => $egitmenkategoricek2['kategori_id'],
                                        "ilceid" => $egitmenilcecek['ilce_id']

                                    )) ;

                                       $checkboxkontrolsay=$checkboxkontrolsec->rowCount();

                                        ?>
                                             
                                      <div class="col-md-3" > 

     <label class="checklabell"><?php  echo $egitmenilcecek['ilce_ad']; ?>
  <input name="ilceguncelle[]" value="<?php   echo $egitmenilcecek['ilce_id']; ?>"  <?php if ($checkboxkontrolsay==1) { ?>
     checked=''
 <?php } ?>    type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>
                                        <?php  }  ?>

                                        



                                      

                                        


                                      


                                       



                                        
                                    </div>
                                </div>
                            </div>
                                                      
                        </div>
                   
                                
                                  
                              </div>
                                



                                                

                                                        

                                                 
                                                 

                                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">  

                                    <div class="form-group">
                                        <label class="control-label" for="email">Ücret Türü*</label>
                                        <div class="custom-select">
                                        <select name="egitmen_kategoriodeme" id="sehirsec" class="select2 form-control">

                                          <?php   if ($egitmenkategoricek2['egitmen_kategoriodeme']==1) { ?>
                                            <option selected="" value="1">Saatlik</option>
                                            <option value="2">Aylık</option>
                                            <option value="3">Yıllık</option>
                                            <option value="4">Kurs Bitene Kadar</option>

                                       <?php   } else if($egitmenkategoricek2['egitmen_kategoriodeme']==2){ ?>

                                         <option value="1">Saatlik</option>
                                            <option selected=""  value="2">Aylık</option>
                                            <option value="3">Yıllık</option>
                                            <option value="4">Kurs Bitene Kadar</option>


                                      <?php } else if($egitmenkategoricek2['egitmen_kategoriodeme']==3){ ?>

                                         <option value="1">Saatlik</option>
                                            <option value="2">Aylık</option>
                                            <option selected="" value="3">Yıllık</option>
                                            <option value="4">Kurs Bitene Kadar</option>

                                        
                                     <?php } else if($egitmenkategoricek2['egitmen_kategoriodeme']==4){ ?>

                                       <option value="1">Saatlik</option>
                                            <option value="2">Aylık</option>
                                            <option value="3">Yıllık</option>
                                            <option selected=""  value="4">Kurs Bitene Kadar</option>

                                        
                                     <?php  } ?>

                                           
                                            



                                              
                                        </select>
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">  

                                    <div class="form-group">
                                        <label class="control-label" for="first-name">Ücret*</label>
                                        <input name="egitmen_kategoriucret" required=""  value="<?php   echo $egitmenkategoricek2['egitmen_kategoriucret']; ?>"      maxlength="20" type="text" id="first-name" class="form-control ucret">

                                    </div>

                                </div>


                                



                                



                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">  

                                    <div class="form-group">
                                        <label class="control-label" for="first-name">Özel Ders Tecrübeniz*</label>
                                        <input name="egitmen_kategoritecrube"  required="" value="<?php   echo $egitmenkategoricek2['egitmen_kategoritecrube']; ?>"      maxlength="20" type="text" id="first-name" class="form-control ucret">

                                    </div>

                                   
                                </div>

                                <input type="hidden" value="<?php   echo $egitmenkategoricek2['kategori_id']; ?>"     name="kategori_id">

                                 <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">

                                  <div  align="right">
                                        <button class="update-btn disabled" type="submit" id="loginbuton" name="egitmenkategoriguncelle">Düzenle</button>
                                    </div>

                                  </div>
                                               
                                                        
                                                    
                                                        
                                                       
                                                    
                                                </div>

                                                </form>


                                                    
                                               <?php } ?>

                                               
                                                
                                                                                          
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                              

                              
                                </div>                                        
                            
                        </div>  
                    </div>
            


                                                
                                          


                                           

                                           
                                        </div> 
                                     
                                            
                    </div> 
                </div>
            </div>
            <!-- Registration Page Area End Here -->
            <!-- Footer Area Start Here -->

            
            <?php require_once 'footer.php'; ?>
            <script type="text/javascript">
              
$(document).ready(function() {
  $('.checkboxform').submit(function() {


    $('#loginbuton').html("Düzenleniyor...");



    if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };






  });


});

            </script>

           

            