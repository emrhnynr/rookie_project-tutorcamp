<?php require_once 'header.php'; ?>
<?php $kategoridetayidsec=$db->prepare("SELECT * from kategoriler where kategori_id=:katid and kategori_durum=:katdurum");
$kategoridetayidsec->execute(array(
  "katid" => $_GET['kategori_id'],
  "katdurum" => 1
));
$kategoridetayidsay=$kategoridetayidsec->rowCount();
if ($kategoridetayidsay==0) {
  header("Location:404");
}
?>
<style type="">
  .update-btn2 {
    height: 35px;
    text-align: center;
    color: #ffffff;
    padding-left:6px;
    padding-right:6px;
    background: #e74c3c;
    text-transform: capitalize;
    font-size: 15px;
    font-weight: 500;
    display: inline-block;
    border: 2px solid #e74c3c;
    -webkit-transition: all 0.3s ease-out;
    -moz-transition: all 0.3s ease-out;
    -ms-transition: all 0.3s ease-out;
    -o-transition: all 0.3s ease-out;
    transition: all 0.3s ease-out;
  }









</style>
<?php   $kategorisec=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_id=:id");
$kategorisec->execute(array(
  "durum" => 1,
  "id" => $_GET['kategori_id']
));
$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC); ?>
<head>
  <title><?php echo $kategoricek['kategori_ad']." Kategorisindeki Eğitmenler"; ?> | eğitmenkampı</title>
</head>
<?php $altkategorisec=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_ust=:ust order by kategori_sira ASC");
$altkategorisec->execute(array(
  "durum" => 1,
  "ust" => $kategoricek['kategori_id']
));
$altkategorisay=$altkategorisec->rowCount(); 

?>
<div style="background-color:#8bc34a">
  <div  class="upload-info-field">
    <div id="kategori_ust_genel" class="row">
      <form id="filtreleform" class="form-horizontal" method="GET" action="filtrele">
        <div style="margin-top: 10px;" class="col-md-3 custom-select">
          <label style="color: #ffffff; font-size: 17px; margin-bottom: 8px;font-weight: 100;">Şehir</label>
          <select style="border:none;outline:none;" name="sehir" id="sehirsec" class="select2 form-control">
            <?php   $sehirsec=$db->prepare("SELECT * from sehirler where sehir_durum=:durum order by sehir_ad ASC");
            $sehirsec->execute(array(
              "durum" => 1
            )); ?>
            <?php    while ($sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC)) {  ?>
              <?php if ($sehircek['sehir_id']==35) { ?>
                <option  selected="" value="<?php   echo $sehircek['sehir_id']; ?>"><?php   echo $sehircek['sehir_ad']; ?></option>
              <?php } else { ?>
                <option  value="<?php   echo $sehircek['sehir_id']; ?>"><?php   echo $sehircek['sehir_ad']; ?></option>
              <?php  } ?>
            <?php } ?>
          </select>
        </div>
        <div  style="margin-top: 10px;" class="col-md-3 custom-select">
          <label style="color: #ffffff; font-size: 17px; margin-bottom: 8px;font-weight: 100">İlçe / Semt</label>
          <select style="border:none;outline:none;" name="ilce" id="ilcesec" class="select2 form-control">
          </select>
        </div>
        <div style="margin-top: 10px;" class="col-md-3 custom-select">
          <label style="color: #ffffff; font-size: 17px; margin-bottom: 8px;font-weight: 100">Eğitmen Cinsiyet</label>
          <select style="border:none;outline:none;" name="cinsiyet" id="cinsiyetsec" class="select2 form-control">
            <option value="0" selected="">Tümü</option>
            <option value="1" >Kadın</option>
            <option value="2">Erkek</option>
          </select>
        </div>
        <input type="hidden" value="<?php echo $kategoricek['kategori_id']; ?>"  name="kategori">
        <div align="left" class="col-md-3">
          <button type="submit"  class="update-btn2 ust_45px sol_30yuzde" style="width: 100px; margin-top: 43px;">Filtrele</button>
          <img id="loader" style="display:none;margin-top: 43px;height: 26px;margin-left: auto;margin-right: auto;" src="ajax-loader-blog.gif">
        </div>
      </form>
    </div>
  </div>
</div>
<div class="pagination-area bg-secondary">
  <div class="container">
    <div class="pagination-wrapper">
      <ul>
        <li><a href="index.php">Anasayfa</a><span> -</span></li>
        <li><?php if ($kategoricek['kategori_ust']==0) {  ?>
          <?php echo $kategoricek['kategori_ad']; ?>
        <?php } else {
          $kategoriseca=$db->prepare("SELECT * from kategoriler where kategori_id=:id and kategori_durum=:durum");
          $kategoriseca->execute(array(
            "durum" => 1,
            "id" => $kategoricek['kategori_ust']
          ));
          $kategoriceka=$kategoriseca->fetch(PDO::FETCH_ASSOC); ?>
          <a href="c-<?php echo seo($kategoriceka['kategori_ad'])."-".$kategoriceka['kategori_id']; ?>"><?php echo $kategoriceka['kategori_ad']; ?></a><span> -</span></li>
          <li><?php echo $kategoricek['kategori_ad']; ?></li>
        <?php } ?>
      </ul>
    </div>
  </div>
</div> 
<!-- Inner Page Banner Area End Here --> 
<!-- Product Page Grid Start Here -->
<div class="product-page-grid bg-secondary section-space-bottom">       
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 col-lg-pull-9 col-md-pull-8 col-sm-pull-8" style="float: left; position: static">
        <div class="fox-sidebar">
          <?php if ($altkategorisay>0) { ?>
            <div class="sidebar-item">
              <div class="sidebar-item-inner">
                <h3 class="sidebar-item-title"><?php echo $kategoricek['kategori_ad']; ?></h3>
                <ul class="sidebar-categories-list">
                  <?php
                  while ($altkategoricek=$altkategorisec->fetch(PDO::FETCH_ASSOC)) { 
                    $altkategoriegitmensec=$db->prepare("SELECT * from egitmenkategori where kategori_id=:id and egitmen_kategoriyetki=:yetki and egitmen_kategoridurum=:durum");
                    $altkategoriegitmensec->execute(array(
                      "id" => $altkategoricek['kategori_id'],
                      "yetki" => 1,
                      "durum" => 1
                    ));
                    $altkategoriegitmensay=$altkategoriegitmensec->rowCount();
                    ?>
                    <li><a href="<?php  echo "c-".seo($altkategoricek['kategori_ad'])."-".$altkategoricek['kategori_id']; ?>"><?php   echo $altkategoricek['kategori_ad'] ?> <?php if ($altkategoricek['kategori_enalt']!=0) { ?>
                      <span><?php echo $altkategoriegitmensay; ?></span>
                  <?php  } ?></a></li>
                  <?php }  ?>
                </ul>
              </div>
            </div>
          <?php } ?>
        </div>

        <?php if ($kategoricek['kategori_id']==163 or $kategoricek['kategori_id']==181 or $kategoricek['kategori_id']==162) { ?>

            <div class="fox-sidebar">
     
            <div class="sidebar-item">
              <div class="sidebar-item-inner">
                <h3 class="sidebar-item-title">Matematik</h3>
                <ul class="sidebar-categories-list">
                   <li><a href="c-matematik-ilkokul-162">İlkokul Matematik</a></li>
                   <li><a href="c-matematik-ortaokul-181">Ortaokul Matematik</a></li>
                   <li><a href="c-matematik-lise-163">Lise Matematik</a></li>
                </ul>
              </div>
            </div>
         
        </div>
          

      <?php  } else if ($kategoricek['kategori_id']==154 or $kategoricek['kategori_id']==187 ){ ?>

          <div class="fox-sidebar">
     
            <div class="sidebar-item">
              <div class="sidebar-item-inner">
                <h3 class="sidebar-item-title">Fen Bilgisi</h3>
                <ul class="sidebar-categories-list">
                   <li><a href="c-fen-bilgisi-ilkokul-154">İlkokul Fen Bilgisi</a></li>
                   <li><a href="c-fen-bilgisi-ortaokul-187">Ortaokul Fen Bilgisi</a></li>
                  
                </ul>
              </div>
            </div>
         
        </div>



   <?php   } else if($kategoricek['kategori_id']==182 or $kategoricek['kategori_id']==183 or $kategoricek['kategori_id']==145){ ?>


          <div class="fox-sidebar">
     
            <div class="sidebar-item">
              <div class="sidebar-item-inner">
                <h3 class="sidebar-item-title">Türkçe</h3>
                <ul class="sidebar-categories-list">
                   <li><a href="c-turkce-ilkokul-183">İlkokul Türkçe</a></li>
                   <li><a href="c-turkce-ortaokul-182">Ortaokul Türkçe</a></li>
                   <li><a href="c-turkce-lise-145">Lise Türkçe</a></li>
                  
                </ul>
              </div>
            </div>
         
        </div>

  <?php }  else if($kategoricek['kategori_id']==186 or $kategoricek['kategori_id']==168 or $kategoricek['kategori_id']==166 or $kategoricek['kategori_id']==167){ ?>


          <div class="fox-sidebar">
     
            <div class="sidebar-item">
              <div class="sidebar-item-inner">
                <h3 class="sidebar-item-title">İngilizce</h3>
                <ul class="sidebar-categories-list">
                   <li><a href="c-ingilizce-ilkokul-168">İlkokul İngilizce</a></li>
                   <li><a href="c-ingilizce-ortaokul-186">Ortaokul İngilizce</a></li>
                   <li><a href="c-ingilizce-lise-166">Lise İngilizce</a></li>
                  <li><a href="c-yds-hazirlik-167">YDS Hazırlık</a></li>
                </ul>
              </div>
            </div>
         
        </div>

  <?php } ?>


      
      </div>

      
      <div id="eklee" class="col-lg-9 col-md-8 col-sm-8 col-xs-12 col-lg-push-3 col-md-push-4 col-sm-push-4" style="margin-top: 20px; float: right; position: static;">
  <div class="inner-page-main-body">
    <?php $sayfa=@$_GET['s'];
    if (empty($_GET['s'])) {
      $sayfa=1;
    };
    $egitmenkategorisec=$db->prepare("SELECT * from egitmenkategori where kategori_id=:id and egitmen_kategoridurum=:durum and egitmen_kategoriyetki=:yetki");
    $egitmenkategorisec->execute(array(
      "id" => $_GET['kategori_id'],
      "durum" => 1,
      "yetki" => 1
    ));
    $kacar=20;
    $egitmenkategorisay=$egitmenkategorisec->rowCount();
    $sayfasayisi=ceil($egitmenkategorisay/$kacar);
    $baslangic=($kacar*$sayfa)-$kacar;




?>

    
   <?php if ($egitmenkategorisay>0 and $sayfa==1) { ?>
     <h3 id="tum"><?php    echo "<span style='color:green;'>".$kategoricek['kategori_ad']."</span>"." Kategorisinde Ders Veren Eğitmenler";?></h3>
  <?php } else if($egitmenkategorisay==0) { ?>

<h3 id="tum"><i class="fas fa-exclamation"></i> Maalesef bu alanda eğitmen kaydı bulunamadı.</h3>

  <?php } ?>
    <div class="tab-content">
      <div role="tabpanel" class="tab-pane fade clear active in products-container" id="list-view">
        <div class="product-list-view">
          <?php $egitmenkategorisec=$db->prepare("SELECT * from egitmenkategori where kategori_id=:id and egitmen_kategoridurum=:durum and egitmen_kategoriyetki=:yetki order by kullanici_onecikan DESC,premium_baslangic ASC,kategori_resimvarmi DESC limit $baslangic,$kacar");
          $egitmenkategorisec->execute(array(
            "id" => $_GET['kategori_id'],
            "durum" => 1,
            "yetki" => 1
          ));
          while ($egitmenkategoricek=$egitmenkategorisec->fetch(PDO::FETCH_ASSOC)) { 
            $egitmensec=$db->prepare("SELECT * from kullanici where kullanici_yetki=:yetki and kullanici_durum=:durum and kullanici_id=:id");
            $egitmensec->execute(array(
              "id" => $egitmenkategoricek['egitmen_id'],
              "durum" => 1,
              "yetki" => 1
            ));
            $egitmencek=$egitmensec->fetch(PDO::FETCH_ASSOC);
            $egitmenkategorisec2=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:id and kategori_enalt=:enalt");
            $egitmenkategorisec2->execute(array(
              "id" => $egitmencek['kullanici_id'],
              "enalt" => 1
            ));
            $egitmenkategorisay2=$egitmenkategorisec2->rowCount();
            $sehirsec=$db->prepare("SELECT * from sehirler where sehir_durum=:durum and sehir_id=:id");
            $sehirsec->execute(array(
              "durum" => 1,
              "id" => $egitmencek['kullanici_il']
            ));
            $sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC);
            $ilcesec=$db->prepare("SELECT * from ilceler where ilce_durum=:durum and ilce_id=:id");
            $ilcesec->execute(array(
              "durum" => 1,
              "id" => $egitmencek['kullanici_ilce']
            ));
            $ilcecek=$ilcesec->fetch(PDO::FETCH_ASSOC);
            $yorumsor=$db->prepare("SELECT * from yorumlar where egitmen_id=:id and yorum_durum=:durum");
            $yorumsor->execute(array(
              "durum" => 1,
              "id" => $egitmencek['kullanici_id']
            ));
            $yorumsay=$yorumsor->rowCount();
            ?>
           
            <div <?php if ($egitmencek['kullanici_onecikan']==1) { ?>
             style='border:1px solid #8bc34a;'
          <?php  } ?> class="single-item-list">
          <a  href="profil-<?php echo $egitmencek['kullanici_id']; ?>">
              <div align='center' class="item-img">
                
                  <?php if (!empty($egitmencek['kullanici_resim'])) { ?>
                    <img class="img-responsive resim_239-214px resim_181px" src="<?php echo $egitmencek['kullanici_resim']; ?>">
                  <?php  } else {
                    if ($egitmencek['kullanici_yetki']=="0") {
                      if (empty($egitmencek['kullanici_cinsiyet'])) { ?>
                        <img class="img-responsive resim_239-214px resim_181px" src="dimg/unisex-avatar.jpg">
                      <?php  } else if ($egitmencek['kullanici_cinsiyet']=="1") { ?>
                        <img class="img-responsive resim_239-214px resim_181px" src="dimg/3.jpg">
                      <?php } else if($egitmencek['kullanici_cinsiyet']=="2"){ ?>
                        <img class="img-responsive resim_239-214px resim_181px" src="dimg/5.jpg">
                      <?php }
                    } else if($egitmencek['kullanici_yetki']=="1" or $egitmencek['kullanici_yetki']=="2" or $egitmencek['kullanici_yetki']=="3"){
                      if ($egitmencek['kullanici_cinsiyet']=="1") { ?>
                        <img class="img-responsive resim_239-214px resim_181px" src="dimg/9.jpg">
                      <?php  } else { ?>
                        <img class="img-responsive resim_239-214px resim_181px" src="dimg/11.jpg">
                      <?php  }
                    }
                  } ?>
                
                

                
              </div>
            </a>
              
              <div class="item-content">
                 <a  href="profil-<?php echo $egitmencek['kullanici_id']; ?>">
                <div  class="item-info">
                  <div  class="item-title itemtitleheight">
                    <h3><?php if ($egitmencek['kullanici_onecikan']==1) { ?>
                      <div style="background-color: green;" class="badge badge-success">Öne Çıkan</div>
                   <?php } ?><?php echo $egitmencek['kullanici_ad']." ".mb_substr($egitmencek['kullanici_soyad'],0,1)."."; ?></h3>
                    <span style="color:#565555;"><?php echo date("Y")-$egitmencek['kullanici_dogum'] ?> Yaşında / <?php if ($egitmencek['kullanici_cinsiyet']==1) {
echo "Kadın";
                    } else if ($egitmencek['kullanici_cinsiyet']==2) {

echo "Erkek";

                    } ?></span>

<span style="color: #565555;"><i style="color: #e74c3c;font-size: 14px;" class="fas fa-map-marker-alt"></i> <?php echo $sehircek['sehir_ad']." / ".$ilcecek['ilce_ad']; ?></span>

                    <?php $sayim=0; ?>
                   
<?php if ($kategoricek['kategori_enalt']!=1) { ?>
  
 <span style="color:green;"><i class="fas fa-tags"></i><?php while ($egitmenkategoricek2=$egitmenkategorisec2->fetch(PDO::FETCH_ASSOC)) {
                      $sayim++; 
                      $kategorisecc=$db->prepare("SELECT * from kategoriler where kategori_durum=:durum and kategori_id=:id");
                      $kategorisecc->execute(array(
                        "durum" => 1,
                        "id" => $egitmenkategoricek2['kategori_id']
                      ));
                      $kategoricekk=$kategorisecc->fetch(PDO::FETCH_ASSOC);
                      ?>
                      <?php if ($egitmenkategorisay2==$sayim) {
                        echo $kategoricekk['kategori_ad'];
                      } else {
                        echo $kategoricekk['kategori_ad'].", ";
                      } ?>
                    <?php } ?>
                  </span>

<?php } ?>

                 

                  


                  <span style="color:#565555;"><i style="color:green;" class="fas fa-user-graduate"></i> <?php echo $egitmencek['kullanici_okulbolum']; ?></span>
                  <?php if ($egitmencek['kullanici_onlineders']==1) { ?>
                    <span style="color:#565555;"><i style="color:green;" class="fas fa-globe-europe"></i> Online Ders İçin Uygun</span>
                  <?php } ?>


                  <?php   if ($egitmencek['kullanici_ilkdersucretsiz']==1) { ?>
                    <span style="color: #565555;"><i style="color: green;" class="fas fa-bolt"></i> İlk Ders Ücretsiz</span>
               <?php   } ?>
                  

                   <?php if ($egitmencek['kullanici_sertifika']==1 and $egitmencek['kullanici_onecikan']==1) { ?>
                    <span style="color: #565555;"><i style="color: #FFA726;" class="fas fa-certificate"></i> Sertifikalı Eğitmen</span>
                 <?php  } ?>

                 <?php if ($egitmencek['kullanici_onecikan']==1 and $yorumsay>1) { ?>


                  <span style="color: #565555;"><i style="color: green" class="fas fa-comments"></i> <?php echo  $yorumsay." Referans Yorumu"; ?></span>



                 <?php   } ?>

                    

                 
                  
                  <span style='font-weight:600;color:#707070;'><i style="color: green;font-size:13px;" class="fas fa-quote-left"></i> <?php  echo $egitmencek['kullanici_ilanbaslik']; ?></span>
                  
                </div>
               
                   
                  
                  
              </div>
              <div class="item-profile">

                <?php $odemeyontemi=$egitmenkategoricek['egitmen_kategoriodeme']; if ($kategoricek['kategori_enalt']==1) { ?>
                  <div class="col-md-4"><span style="color:#707070;"><i class="fas fa-money"></i> <b><?php echo $egitmenkategoricek['egitmen_kategoriucret']; ?> ₺</b> / <i><?php switch ($odemeyontemi) {
                    case '1':
                      echo "Saat";
                      break;

                       case '2':
                      echo "Ay";
                      break;

                       case '3':
                      echo "Yıl";
                      break;

                       case '4':
                      echo "Kurs Boyunca";
                      break;
                    
                    
                  } ?></i></span></div>
              <?php  } ?>
                
              <div align="right" class="col-md-8 profile-rating-info">
                
              </div>
            </div>
          </a>
          </div>
        </div>
      
        
      <?php } ?>
      <div class="row">
        

<?php if ($egitmenkategorisay>0) { ?>
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <?php $s=0;
          ?>
          <ul class="pagination-align-center">
            <?php if ($sayfa!=1) { ?>
              <li><a href="c-<?php echo seo($kategoricek['kategori_ad'])."-".$kategoricek['kategori_id']; ?>?s=<?php echo $sayfa-1;   ?>"><i class="fas fa-angle-left"></i></a></li>
          <?php  } ?>
            <?php   while ($s<$sayfasayisi) {$s++;?>
              
              <?php if ($s<=$sayfa+4 && $s>=$sayfa) { ?>
                <?php   if ($sayfa!=$s) { ?>
                <li><a href="c-<?php echo seo($kategoricek['kategori_ad'])."-".$kategoricek['kategori_id']; ?>?s=<?php echo $s;   ?>"><?php   echo $s; ?></a></li>
              <?php } else { ?>
                <li ><a style="background-color:#e74c3c;color:white;" href="javascript:void(0);"><?php   echo $s; ?></a></li>
              <?php } ?>
            <?php  } ?>
            <?php } ?>
            <?php if ($sayfa!=$sayfasayisi) { ?>
              <li><a href="c-<?php echo seo($kategoricek['kategori_ad'])."-".$kategoricek['kategori_id']; ?>?s=<?php echo $sayfa+1;   ?>"><i class="fas fa-angle-right"></i></a></li>
          <?php  } ?>
          </ul>
        </div>
     
<?php } ?>

         </div>
    </div>
  </div>
</div>
</div>
</div>
     
    
  </div>
</div>
</div>
<?php require_once 'footer.php'; ?>
<script type="text/javascript">
  $('#sehirsec').change(function(){
    $sehirid=$('#sehirsec').val();
    $.ajax({
      type : 'POST',
      url : 'nedmin/production/netting/ajaxsehirseckategoriler.php',
      data : {"sehir_id":$.trim($sehirid)},
      success : function(e){
        $('#ilcesec').html(e);
      }
    });
  }).change();
</script>
