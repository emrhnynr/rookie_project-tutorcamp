 


<?php   require_once 'header.php'; ?>

<head>
  
<title>Hakkımızda | Eğitmenkampı</title>

</head>


           
            <div   class="about-page-area bg-secondary  section-space-bottom">
                <div class="container">
                    <div class="row">
                    <h2 class="col-md-12 title-section">Biz Kimiz?</h2>
                    
                    <div  class="col-md-12 inner-page-details inner-page-padding">
                        <p>Eğitmenkampı.com, özel ders almak isteyen öğrencileri <b>140+</b> Kategoride <b>2000+</b> Alanında Yetkin Eğitmenimiz ile buluşturup başarılarına başarı katmalarına olanak sağlayan sağlayan bir platformdur. </p>

                        <h3><i  class="fas fa-trophy"></i> Amacımız</h3>

                        <p>Eğitmenkampı.com'un en büyük amacı, özel ders alınabilecek her alanda profesyonel,alanında yetkin eğitmenleri bünyesine kazandırıp kaliteli ders almayı hak eden öğrenciler ile onları buluşturmaktır.</p>

                        <h3>Sadelik Mükemmelliktir</h3>

                        <p>Websitemizi olabilecek en basit ve etkili olacak şekilde dizayn ettik. Websitemize kayıt olmak isteyen eğitmenler çok basit ve anlaşılır şekilde adımları doldurup kayıtlarını tamamlamaktadırlar. Ayrıca websitemizdeki profesyonel eğitmenlerimizden ders almak isteyen öğrenci ve veliler için de oldukça basit bir arayüz oluşturduk. Bu sayede <b>15 saniye</b> içerisinde kendi şehir ve semtlerinde kendilerine uygun eğitmenler arasında göz gezdirebilir duruma geliyorlar.</p>

                        <p></p>
                    </div>


                     

                    </div>
                </div>  
            </div> 
            
            <?php   require_once 'footer.php'; ?>