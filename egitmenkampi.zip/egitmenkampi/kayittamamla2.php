<?php  require_once 'header.php'; ?>

<head>
  
<title>Eğitmen Kayıt Tamamlama 2 - eğitmenkampı</title>

</head>

<head><style type="text/css">
   /* Customize the label (the container) */
.checklabell {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checklabell input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;
  background-color: #eee;
}

/* On mouse-over, add a grey background color */
.checklabell:hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.checklabell input:checked ~ .checkmark {
  background-color: #43DE09;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checklabell input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checklabell .checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
}

</style></head>
    
   





<?php 

 if ($egitmenkategoritestsay==0 or $kullanicioturumcek['kullanici_yetki']!=2) {
  Header("Location:404"); //Kullanıcı tüm kursları gönderince yetkisi 3,onaylandığında 1 olucak ve buraya giremeyecek.
} 

$egitmenkategorisec=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:id and kategori_enalt=:enalt and egitmen_kategoriyetki=:yetki");
$egitmenkategorisec->execute(array(

"id" => $_SESSION['kullanici_id'],
"enalt" => 1,
"yetki" => 2

));

$egitmenkategorisay=$egitmenkategorisec->rowCount();


$egitmensec0=$db->prepare("SELECT * from kullanici where  kullanici_id=:id");
$egitmensec0->execute(array(

"id" => $_SESSION['kullanici_id']
));

$egitmencek0=$egitmensec0->fetch(PDO::FETCH_ASSOC);



?>






 


 





            <!-- Header Area End Here -->
            <!-- Main Banner 1 Area Start Here -->
           
            <!-- Main Banner 1 Area End Here --> 
            <!-- Inner Page Banner Area Start Here -->
            
            <!-- Inner Page Banner Area End Here -->          
            <!-- Registration Page Area Start Here -->
            <div class="registration-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <h2 class="title-section">Eğitmen Kayıt Tamamlama 
                    Adım : 2 / 2</h2>


                   

                    <div class="registration-details-area inner-page-padding">

                      
                        
                                     <div id="infobox" class="alert alert-warning">

                                        • Lütfen <b>Tüm</b> Kurs Detay Bilgilerinizi <b>Tek Tek</b> ve <b>Dikkatlice</b> Doldurup Gönderin.<br>
                                        • Doldurulması Zorunlu Alanlar <b>*</b> İle Belirtilmiştir.

                                   

                                  


                            



                               </div>

                               <?php if ($_GET['durum']=="yetersizsecim") { ?>

                                <div  class="alert alert-danger">

                                Kursunuz İçin En Az <b>1</b> İlçe / Semt Seçmelisiniz.


                               </div>
                                 
                              <?php };


                              if ($_GET['durum']=="ok") { ?>

                                <?php $ceksay=$db->prepare("SELECT * from egitmenkategori where egitmen_id=:egitmenid ") ?>


                                <div class="alert alert-success"><i class="fas fa-check"></i> Kayıt Başarılı! Kaydetmeniz gereken <b><?php echo $egitmenkategorisay ?></b> Kurs Kaldı.</div>
                                 


                             <?php  } ?>

                               






                              

                                    <br>

                                  
                       

                        

<form action="nedmin/production/netting/musteriislem.php" class="kayittamamla2form" method="POST" id="personal-info-form">

  <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12">

                                <div class="panel-group help-page-wrapper" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                        <a aria-expanded="false" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#ackapat">
                                           Ders Verebileceğiniz İlçe / Semtler
                                        </a>
                                    </div>
                                </div>
                                <div aria-expanded="false" id="ackapat" role="tabpanel" class="panel-collapse collapse in">
                                    <div style="background: white;" class="panel-body">


                                      <?php $ilcesecders=$db->prepare("SELECT * from ilceler where sehir_id=:id order by ilce_ad ASC");
                                      $ilcesecders->execute(array(

"id" => $egitmencek0['kullanici_il']
                                      ));

while ($ilcecekders=$ilcesecders->fetch(PDO::FETCH_ASSOC)) { ?>


                                       

                                      <div class="col-md-3" > 

     <label class="checklabell"><?php  echo $ilcecekders['ilce_ad']; ?>
  <input class="ilcecheckbox" name="ilcesecim[]" value="<?php   echo $ilcecekders['ilce_id']; ?>"   type="checkbox">
  <span class="checkmark"></span>
</label>

<br>




</div>

<?php } ?>
                                        
                                    </div>
                                </div>
                            </div>
                                                      
                        </div>
                   
                                  
                                  
                              </div>

                            



    <?php while ($egitmenkategoricek=$egitmenkategorisec->fetch(PDO::FETCH_ASSOC)) { 


$kategorisec=$db->prepare("SELECT * from kategoriler where kategori_id=:id");
$kategorisec->execute(array(
"id" => $egitmenkategoricek['kategori_id']
));

$kategoricek=$kategorisec->fetch(PDO::FETCH_ASSOC);
        ?>
        
   



<div style="margin-top:30px;" class="col-md-12">
    <h3 align="center"><span style="color:#43DE09;"><?php echo $kategoricek['kategori_ad']."</span> Kursunuz"; ?><hr></h3>


   





   
                               
                              


                              



                                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">  

                                    <div class="form-group">
                                        <label class="control-label" for="email">Ücret Türü*</label>
                                        <div class="custom-select">
                                        <select name="egitmen_kategoriodeme<?php echo $egitmenkategoricek['egitmenkategori_id']; ?>" id="sehirsec" class="select2 form-control">

                                            <option value="1">Saatlik</option>
                                            <option value="2">Aylık</option>
                                            <option value="3">Yıllık</option>
                                            <option value="4">Kurs Bitene Kadar</option>
                                            



                                              
                                        </select>
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">  

                                    <div class="form-group">
                                        <label class="control-label" for="first-name">Ücret*</label>
                                        <input name="egitmen_kategoriucret<?php echo $egitmenkategoricek['egitmenkategori_id']; ?>" required=""  placeholder="Türk Lirası Cinsinden Yazınız."    maxlength="20" type="text" id="first-name" class="form-control ucret">

                                    </div>

                                </div>







                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">  

                                    <div class="form-group">
                                        <label class="control-label" for="first-name">Özel Ders Tecrübeniz*</label>
                                        <input name="egitmen_kategoritecrube<?php echo $egitmenkategoricek['egitmenkategori_id']; ?>"  required="" placeholder="Örn.12 yıl"    maxlength="20" type="text" id="first-name" class="form-control ucret">

                                    </div>

                                   
                                </div>

                                <input type="hidden" value="<?php   echo $kategoricek['kategori_id']; ?>"     name="kategori_id">







                                 


</div>



<div class="row">


                               
                               
                                 
                            </div> 
                          

<?php } ?>


<div style="display: none;" class="alert alert-danger ilcesecuyari"><i class="fas fa-exclamation"></i> Öncelikle ilçe/semt seçimi yapmalısınız.</div>




                                    
                                        <button style="margin-left:30px;"   name="egitmenkategorikaydet" class="update-btn disabled" id="kayittamamlaok" type="submit">Gönder</button>
                                    
                                


</form>   





<br><br>










    


                             









                            


                           




                            


                           



 
                            
                               
                                                            
                          
             

                           
                                             
                    </div> 
                </div>
            </div>
            <!-- Registration Page Area End Here -->
            <!-- Footer Area Start Here -->

            
            <?php require_once 'footer.php'; ?>
           <script type="text/javascript">
             
           $(document).ready(function() {
  $('.kayittamamla2form').submit(function() {

    var secilmischeckbox=$('.ilcecheckbox:checkbox:checked').length;

    if (secilmischeckbox==0) {


event.preventDefault();
     $('.ilcesecuyari').show();



    } else { 


$('.ilcesecuyari').hide();

      $('#kayittamamlaok').html('Bu işlem biraz sürebilir...');



    if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };



    }




    





  });


});

           </script>

            
            
            

            