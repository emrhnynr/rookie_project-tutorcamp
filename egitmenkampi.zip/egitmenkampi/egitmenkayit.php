<?php require_once 'header.php'; ?>
<head>
    <title>Eğitmen Kaydı - eğitmenkampı</title>
</head>
<?php if (isset($_SESSION['kullanicioturum'])) {
    Header("Location:index");
}; ?>

<style type="text/css">



 
    
    @media screen and (min-width: 991px) {
  #bilgikutu {


height: 1078px;

  }
  }

[type="checkbox"]
{
    vertical-align:middle;
}


</style>

<!-- Inner Page Banner Area End Here --> 
<!-- Registration Page Area Start Here -->
<div style="border:1px;" class="registration-page-area bg-secondary section-space-bottom">
    <br>
    <div class="container">
        <h2 style="color:#43DE09;" class="title-section col-md-12">Eğitmen Kaydı </h2>
        <div class="registration-details-area inner-page-padding col-md-6">
            <div class="row">
                <form role='form' method="POST" id="personal-info-form" onsubmit="return false;" class="formegitmen">
                    <div class="col-md-12">
                        <div id="infobox" class="alert alert-warning">• Şifrenizin en az <b>6</b> karakter uzunluğunda olması gerekmektedir.<br>
                            • Şifrenizin güçlü olması için en az <b>8</b> karakter olması,rakam ve özel karakterler içermesi <u>önerilir</u>.<br>
                            • Tüm alanların doldurulması zorunludur.
                        </div>
                        <div id="uyarikutu" style="display: none;" class="alert alert-danger"></div>
                    </div>

                    
                                                                    <div  style="margin-bottom:18px;" class="col-lg-12 col-md-6 col-sm-6 col-xs-12">
    
    <li style="list-style: none;">
    <input class="topluluksozlesmesi"   type="checkbox" >
    <input type="hidden" name="topluluksozlesmesionay" class="topluluksozlesmesihidden" value="0">
    <label style="word-wrap:break-word;"><a href="topluluk-kurallari" target="_blank">Topluluk Kuralları</a>'nı okudum ve kabul ediyorum.</label>
</li>

</div>




                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="first-name">Adınız*</label>
                            <input name="kullanici_ad" maxlength="20" type="text" id="first-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="last-name">Soyadınız*</label>
                            <input name="kullanici_soyad" maxlength="20" type="text" id="last-name" class="form-control"></input>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="company-name">E-Mail Adresiniz*</label>
                            <input name="kullanici_mail" maxlength="100" type="email" id="company-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Şifre*</label>
                            <input name="kullanici_sifre" maxlength="20" type="password" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Şifre Tekrar*</label>
                            <input name="kullanici_sifre2" maxlength="20" type="password" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Doğum Yılınız*</label>
                            <input name="kullanici_dogum" maxlength="4" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Mesleğiniz*</label>
                            <input name="kullanici_meslek" maxlength="60" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="first-name">Okuduğunuz / Mezun Olduğunuz Okul ve Bölüm*</label>
                            <input name="kullanici_okulbolum" maxlength="70" type="text" id="first-name" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Cep Telefonu(GSM)*</label>
                            <input name="kullanici_gsm" maxlength="11" type="text" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Yaşadığınız Şehir*</label>
                            <div class="custom-select">
                                <select name="kullanici_il" id="sehirsec" class="select2 form-control">
                                    <option selected="selected" disabled="" hidden="">Seçiniz</option>
                                    <?php $sehirsec=$db->prepare("SELECT * from sehirler where sehir_durum=:durum order by sehir_plaka ASC");
                                    $sehirsec->execute(array(
                                        "durum" => 1
                                    ));
                                    while ($sehircek=$sehirsec->fetch(PDO::FETCH_ASSOC)) { ?>
                                        <option value="<?php echo $sehircek['sehir_id']; ?>"><?php echo $sehircek['sehir_ad']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Yaşadığınız İlçe/Semt*</label>
                            <div class="custom-select">
                                <select name="kullanici_ilce" id="ilcesec" class="form-control">
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-6 col-sm-6 col-xs-12"> 
                        <div class="form-group">
                            <label class="control-label" for="email">Cinsiyetiniz*</label>
                            <select class="form-control" name="kullanici_cinsiyet">
                                <option disabled="" selected="" hidden="">Seçiniz</option>
                                <option value="1">Kadın</option>
                                <option value="2">Erkek</option>
                            </select>
                        </div>
                    </div>

                    <br>

                     <div   class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="form-group">
                                                        
                                                        <img id="captcha" src="securimage/securimage_show.php"><br>
                                                        <a href="javascript:void(0);" onclick="document.getElementById('captcha').src = 'securimage/securimage_show.php?' + Math.random(); return false">[Resim Değiştir]</a>
                                                    </div>
                                                </div>

                                                 <div align="left" style="height: 110px;"  class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <div class="form-group">
                                                        <input type="text" placeholder="Güvenlik Kodunu Giriniz*" class="form-control" name="captcha_code" id="form-mail" data-error="Bu alanı doldurmanız zorunludur." maxlength="10" >
                                                        <div class="help-block with-errors"></div>
                                                    </div>

                                                </div>


                                                


                                                

                                                    
                                                      
                                                                                                                
                </div>
                <button name="ogrencikayit" id="kayitbuton" class="update-btn" type="submit">Kayıt Ol</button>
            </form>
        </div> 
        <div id="bilgikutu" style="border-left:0px;" class="registration-details-area inner-page-padding col-md-6">
            <ul class="new-users-profit">
                <li class="list-item">
                    <div class="list-detail">
                        <h3><i style="color:#43DE09;" class="fas fa-user-edit"></i> Bilgilerini Doldur</h3>
                        <p style="font-size: 19px;">Yandaki kişisel bilgileri doldurup kayıt olduktan sonra özel ders vermek istediğiniz kategorileri ve ücret bilgilerini doldurarak hemen özel ders vermeye başlayabilirsiniz!</p>
                    </div>
                </li>
                <hr>
                <li class="list-item">
                    <div class="list-detail">
                        <h3><i style="color:#43DE09;" class="fas fa-blog"></i> Bloglar Yayınla</h3>
                        <p style="font-size: 19px;">Uzmanı olduğun konularda bloglar yayınlayarak öğrencileri bilgilendirebilir,blog sayfasında adını duyurabilirsin.</p>
                    </div>
                </li>
                <hr>
                <li class="list-item">
                    <div class="list-detail">
                        <h3><i style="color:#43DE09;" class="fas fa-bell" aria-hidden="true"></i> Anında Bildirimleri Al</h3>
                        <p style="font-size: 19px;">Blog yazılarınıza veya profilinize yapılan yorumlar anında bildirim olarak ekranınıza yansır!</p>
                    </div>
                </li>
                <hr>
                <li class="list-item">
                    <div class="list-detail">
                        <h3><i style="color:#43DE09;" class="fas fa-envelope"></i> Mesajları Yanıtla</h3>
                        <p style="font-size: 19px;">Öğrencilerinizin mesajlarına hızlıca cevap verip randevu ayarlayabilirsiniz!</p>
                    </div>
                </li>
                <hr>
                <li class="list-item">
                    <div class="list-detail">
                        <h3><i style="color:#43DE09;" class="fas fa-hand-holding-usd"></i> Ek Gelir Elde Et</h3>
                        <p style="font-size: 19px;">Bilgi birikimlerinizi basit yoldan öğrencilerinizle paylaşıp ek gelir elde edin. Hem de ücretsiz!</p>
                    </div>
                </li>
                <hr>
                <li class="list-item">
                    <div class="list-detail">
                        <h3><i style="color:#43DE09;" class="fas fa-user-graduate"></i> Öğretmen Olmanız Gerekmez</h3>
                        <p style="font-size: 19px;">Yeterli tecrübe ve bilgi birikimine sahip olduğun konularda hemen kaydolup özel ders vermeye başlayabilirsin.</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- Registration Page Area End Here -->
<?php require_once 'footer.php'; ?>
<script type="text/javascript">


$('.topluluksozlesmesi').change(function(){


if ($('.topluluksozlesmesi').prop('checked')) {

  
 $('.topluluksozlesmesihidden').val('1');
  
} else {

  $('.topluluksozlesmesihidden').val('0');
 
};

})



    $('#sehirsec').change(function(){
        $sehirid=$('#sehirsec').val();
        $.ajax({
            type : 'POST',
            url : 'nedmin/production/netting/ajaxsehirsec.php',
            data : {"sehir_id":$.trim($sehirid)},
            success : function(e){
                $('#ilcesec').html(e);
            }
        });
    }).change();



    $('#kayitbuton').click(function(){
        $.ajax({
            type : 'POST',
            url : 'nedmin/production/netting/egitmenkayitajax.php',
            data : $('#personal-info-form').serialize(),
            success : function(sonuc){
                if ($.trim(sonuc)=="sozlesmeonaylanmadi") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen Topluluk Kurallarını Onaylayınız.");
                    
                }  else if ($.trim(sonuc)=="yanlisad") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen adınızı doğru giriniz.");
                    $('input[name="kullanici_ad"]').css("border-color","red");
                } else if($.trim(sonuc)=="yanlissoyad") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen soyadınızı doğru giriniz.");
                    $('input[name="kullanici_soyad"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="mevcutkayit") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Bu kayıt zaten mevcut.");
                    $('input[name="kullanici_mail"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="uyusmayansifre") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Şifreler Uyuşmuyor.");
                    $('input[name="kullanici_sifre"]').css("border-color","red");
                    $('input[name="kullanici_sifre2"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="yetersizmail") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen Mail Adresinizi Doğru Girin.");
                    $('input[name="kullanici_mail"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="kisasifre"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Şifreniz en az 6 karakter olabilir.");
                    $('input[name="kullanici_sifre"]').css("border-color","red");
                    $('input[name="kullanici_sifre2"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="yanlisdogum"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen doğum yılınızı doğru giriniz.");
                    $('input[name="kullanici_dogum"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="yanlismeslek"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen mesleğinizi doğru giriniz.");
                    $('input[name="kullanici_meslek"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if ($.trim(sonuc)=="yanlisokulbolum"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen okul ve bölümünüzü doğru giriniz.");
                    $('input[name="kullanici_okulbolum"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="yanlisgsm"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen cep telefon numaranızı doğru giriniz.");
                    $('input[name="kullanici_gsm"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="mevcutgsm"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Bu Telefon Numarası (GSM) Zaten Mevcut.");
                    $('input[name="kullanici_gsm"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="engelligsm"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Bu Telefon Numarası (GSM) ile Girişiniz Engellenmiş.");
                    $('input[name="kullanici_gsm"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="ilsecilmedi"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen yaşadığınız şehri seçiniz.");
                    $('input[name="kullanici_il"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="cinsiyetsecilmedi"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen cinsiyetinizi belirtiniz.");
                    $('input[name="kullanici_cinsiyet"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if($.trim(sonuc)=="medenisecilmedi"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen medeni durumunuzu belirtiniz.");
                    $('input[name="kullanici_medeni"]').css("border-color","red");
                    $('#bilgikutu').css('height',"1123px");
                } else if ($.trim(sonuc)=="yanliscaptcha") {
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Lütfen Güvenlik Kodunu Doğru Giriniz.");
                    $('input[name="captcha_code"]').css("border-color","red");
                }    else if($.trim(sonuc)=="hata"){
                    $('#uyarikutu').css("display","block");
                    $('#uyarikutu').html("<i class='fas fa-exclamation'></i> Kayıt esnasında hata oluştu.");
                } else if($.trim(sonuc)=="ok") {
                    window.location='index.php';
                };
            }
        })
})
</script>
