<?php require_once 'header.php'; ?>

<head>
  
<title>Mesajlarım - eğitmenkampı</title>

</head>


<?php if (empty($_SESSION['kullanicioturum'])) {
    
    header("Location:404");
} ?>

<style type="text/css">

 .update-btn2 {
  margin-top: 30px;
  text-align: center;
  color: #ffffff;
  padding: 10px 30px 11px;
  background: #e74c3c;
  text-transform: capitalize;
  font-size: 15px;
  font-weight: 500;
  display: inline-block;
  border: 2px solid #e74c3c;
  -webkit-transition: all 0.3s ease-out;
  -moz-transition: all 0.3s ease-out;
  -ms-transition: all 0.3s ease-out;
  -o-transition: all 0.3s ease-out;
  transition: all 0.3s ease-out;
}
.update-btn2:hover {
  background: transparent;
  color:  #e74c3c;
}
    
.ul-list li .notify-message-img {
  -webkit-box-flex: 1;
  -moz-flex: 1;
  -webkit-flex: 1;
  flex: 1;
}

 
 .ul-list li {
  border-bottom: 1px solid #dfdfdf;
  padding-left: 15px;
  padding-right: 15px;
  padding-bottom: 15px;
  padding-top: 15px;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-flex;
  display: -ms-flex;
  display: -o-flex;
  display: flex;
}
 .ul-list li:first-child .notify-message-sign {
  color: #ef6c00;
}
 .ul-list li:last-child {
  border-bottom: none;
}
.ul-list li:hover {
  background: #ffffff;
}
.ul-list li .notify-message-img {
  -webkit-box-flex: 1;
  -moz-flex: 1;
  -webkit-flex: 1;
  flex: 1;
}
 .ul-list li .notify-message-info {
  margin-left: 10px;
  text-align: left;
  -webkit-box-flex: 3;
  -moz-flex: 3;
  -webkit-flex: 3;
  flex: 3;
}
 .ul-list li .notify-message-info .notify-message-sender {
  font-size: 17px;
  color: #263238;
}
 .ul-list li .notify-message-info .notify-message-subject {
  font-size: 15px;
  color: #707070;
}
 .ul-list li .notify-message-info .notify-message-date {
  font-size: 14px;
  color: #8bc34a;
}
 .ul-list li .notify-message-sign {
  padding-top: 15px;
  -webkit-box-flex: 1;
  -moz-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  color: #b0bec5;
}

</style>
            <div class="pagination-area bg-secondary">
                <div class="container">
                    <div class="pagination-wrapper">
                        <ul>
                            <li><a href="index.php">Anasayfa</a><span> -</span></li>
                            <li>Mesajlarım</li>
                        </ul>
                    </div>
                </div>  
            </div> 
            <!-- Inner Page Banner Area End Here -->          
            <!-- Settings Page Start Here -->




            <div class="settings-page-area bg-secondary section-space-bottom">
                <div class="container">
                    <div class="row settings-wrapper">
                        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                            <ul class="settings-title">
                                <li class="active"><a href="#gelen" data-toggle="tab" aria-expanded="false">Gelen Mesajlar (<?php echo $mesajsay; ?>)</a></li>
                                <li><a href="#giden" data-toggle="tab" aria-expanded="false">Giden Mesajlar</a></li>
                                
                            </ul>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12"> 

                            
                                    <?php if ($_GET['mesajsil']=="ok") { ?>

                                        <div class="alert alert-success"><i class="fas fa-check"></i> Mesaj Başarıyla Silindi!</div>

                                   


                                         





                                   <?php } else if($_GET['mesajsil']=="no"){ ?>

                                    <div class="alert alert-danger"><i class="fas fa-exclamation"></i> Mesaj Silinemedi.</div>


                                  <?php } else if($_GET['mesajgonder']=="ok") { ?>


                                    <div class="alert alert-success"><i class="fas fa-check"></i> Mesaj Başarıyla İletildi!</div>



                                  <?php } ?>
                          
                                <div class="settings-details tab-content">
                                    <div class="tab-pane fade active in" id="gelen">

                                      <?php $mesajsecgelen=$db->prepare("SELECT * from mesajlar where mesaj_alici=:alici and mesaj_turu=:turu order by mesaj_zaman DESC");
$mesajsecgelen->execute(array(

"alici" => $_SESSION['kullanici_id'],
"turu" => 0

));

$gelenmesajsay=$mesajsecgelen->rowCount();


 ?> 

                                        <h2 class="title-section">Gelen Mesajlarım</h2>
                                        <div class="personal-info inner-page-padding">


                                          <?php if ($gelenmesajsay>0) { ?>


                                            <ul  class="ul-list">
                                                <?php while ($mesajcekgelen=$mesajsecgelen->fetch(PDO::FETCH_ASSOC)) { 

$gelenkullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id and kullanici_durum=:durum");
$gelenkullanicisec->execute(array(

"id" => $mesajcekgelen['mesaj_gonderen'],
"durum" => 1
));

$gelenkullanicicek=$gelenkullanicisec->fetch(PDO::FETCH_ASSOC);
                                                    ?>

                                                   <?php if ($mesajcekgelen['mesaj_okundu']==1) { ?>

                                                    <li>

                                                    
                                                 <?php  } else if($mesajcekgelen['mesaj_okundu']==0) {  ?>

                                                  <li style="background: rgba(139, 195, 74 ,0.3);">


                                                  
                                               <?php  } ?>
                                                        <div class="notify-message-img">
                                                            <?php if (!empty($gelenkullanicicek['kullanici_resim'])) { ?>


                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="<?php echo $gelenkullanicicek['kullanici_resim']; ?>">
                                                            

                                                      <?php  } else {


                                                        if ($gelenkullanicicek['kullanici_yetki']=="0") {


                                                            if (empty($gelenkullanicicek['kullanici_cinsiyet'])) { ?>


                                                                <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">


                                                                

                                                          <?php  } else if ($gelenkullanicicek['kullanici_cinsiyet']=="1") { ?>

                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/3.jpg">
                                                                

                                                           <?php } else if($gelenkullanicicek['kullanici_cinsiyet']=="2"){ ?>


                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/5.jpg">


                                                           <?php }

                                                            

                                                        } else if($gelenkullanicicek['kullanici_yetki']=="1" or $gelenkullanicicek['kullanici_yetki']=="2" or $gelenkullanicicek['kullanici_yetki']=="3"){


                                                            if ($gelenkullanicicek['kullanici_cinsiyet']=="1") { ?>


                                                                 <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/9.jpg">
                                                              

                                                          <?php  } else { ?>


                                                            <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/11.jpg">



                                                        <?php  }





                                                        }




                                                      } ?>
                                                        </div>
                                                        <div class="notify-message-info">
                                                            <div class="notify-message-sender">

                                                               <?php if ($gelenkullanicicek['kullanici_yetki']==1) { ?>

                                                                    <a style="color:#707070;" href="profil-<?php echo $gelenkullanicicek['kullanici_id']; ?>"><?php echo $gelenkullanicicek['kullanici_ad']." ".$gelenkullanicicek['kullanici_soyad']; ?></a>

                                                              <?php } else { ?>

                                                                <?php echo $gelenkullanicicek['kullanici_ad']." ".$gelenkullanicicek['kullanici_soyad']; ?>



                                                            <?php  } ?> (<?php if ($gelenkullanicicek['kullanici_yetki']==1 or $gelenkullanicicek['kullanici_yetki']==2 or $gelenkullanicicek['kullanici_yetki']==3) {
                                                                    echo "Eğitmen";
                                                                } else if($gelenkullanicicek['kullanici_yetki']==0){

                                                                    echo "Öğrenci";


                                                                } ?>)
                                                                    

                                                                </div>
                                                            <div class="notify-message-date"><?php if (substr($mesajcekgelen['mesaj_zaman'],5,2)=="01") {
                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Ocak";
                                            } 
                                            else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="02"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Şubat";



                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="03"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Mart";



                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="04"){

                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Nisan";




                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="05"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Mayıs";



                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="06"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Haz";




                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="07"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Tem";



                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="08"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Ağu";




                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="09"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Eylül";




                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="10"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Ekim";



                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="11"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Kasım";




                                            } else if(substr($mesajcekgelen['mesaj_zaman'],5,2)=="12"){


                                                echo substr($mesajcekgelen['mesaj_zaman'],8,2)." Aralık";




                                            } ?> <?php echo substr($mesajcekgelen['mesaj_zaman'], 0,4)."   ".substr($mesajcekgelen['mesaj_zaman'], 11,5) ?></div>
                                                            <div class="notify-message-subject"><?php echo $mesajcekgelen['mesaj_icerik']; ?></div>
                                                            
                                                            
                                                        </div>
                                                      <div class="notify-message-sign">
                                                           
                                                          
                                                           <a id="mesajsilengel" style=" margin-left: 22px;" data-toggle="tooltip" data-placement="bottom" title="Bu Mesajı Sil" href="nedmin/production/netting/musteriislem.php?mesaj_id=<?php echo $mesajcekgelen['mesaj_id'] ?>&mesajsilgelen=ok"><i style="color:#e74c3c;" class="fas fa-trash"></i></a>

                                                           <a style="margin-left: 22px;" data-toggle='modal' data-toggle="tooltip" data-placement="bottom" title="Mesajı Cevapla" href="#mesajgonder"><i style="color:#8bc34a;" class="fas fa-reply"></i></a>
                                                           
                                                        </div>



                                                         <div class="modal fade" id="mesajgonder"> 
  <div class="modal-dialog modal-lg">
    <div style="margin-top:200px;" class="modal-content">
     

<div class="modal-body">


   <form id="mesajyanitpost" action="nedmin/production/netting/musteriislem.php" method="POST">

  <textarea style="height: 200px;" class="textarea form-control" placeholder="<?php   echo $gelenkullanicicek['kullanici_ad']." ".$gelenkullanicicek['kullanici_soyad']; ?> Adlı Kişiye Yanıtınız" maxlength="1000" required="" name="mesaj_icerik"></textarea>


  <input value="<?php   echo $kullanicioturumcek['kullanici_id']; ?>" type='hidden' name="mesaj_gonderen">
<input value="<?php   echo $gelenkullanicicek['kullanici_id']; ?>"   type="hidden" name="mesaj_alici">
<input type="hidden" value="<?php   echo 'http://'.$_SERVER['HTTP_HOST' ].$_SERVER['REQUEST_URI']; ?>" name="gelen_url3">


  
  

</div>

<div class="modal-footer">
  
  <button type="submit" name="mesajgonder" class="update-btn">Gönder</button>
    <button class="update-btn2" data-dismiss="modal">Çık</button>
</div>

</form>
    </div>

  </div>

</div>





                                                        


                                                       






                                                    </li>



                                                    
                                                   
                                                    
                                               <?php } ?>
                                                    
                                                </ul>

                                           
                                         <?php } else { ?>

<p align="center"><i class="far fa-envelope-open"></i> Mesaj Kutunuz Şuan Boş</p>


                                        <?php } ?>


                                         





                                        

                                         
                                                <?php $hazirla=$db->prepare("UPDATE mesajlar set 

mesaj_okundu=:mesaj_okundu


where mesaj_alici={$_SESSION['kullanici_id']}


");


$update=$hazirla->execute(array(

"mesaj_okundu" => 1



));

 ?>
                                            
                                                                              
                                        </div> 
                                    </div> 






                                    <div class="tab-pane fade" id="giden">

<?php $mesajsecgiden=$db->prepare("SELECT * from mesajlar where mesaj_gonderen=:gonderen and mesaj_turu=:turu order by mesaj_zaman DESC");
$mesajsecgiden->execute(array(

"gonderen" => $_SESSION['kullanici_id'],
"turu" => 1

));

$gidenmesajsay=$mesajsecgiden->rowCount();


 ?>

                                        <h3 class="title-section">Giden Mesajlarım</h3>
                                        <div class="public-profile inner-page-padding"> 
                                            
                                            <?php if ($gidenmesajsay>0) { ?>



                                              <ul  class="ul-list">
                                                <?php while ($mesajcekgiden=$mesajsecgiden->fetch(PDO::FETCH_ASSOC)) { 

$gidenkullanicisec=$db->prepare("SELECT * from kullanici where kullanici_id=:id and kullanici_durum=:durum");
$gidenkullanicisec->execute(array(

"id" => $mesajcekgiden['mesaj_alici'],
"durum" => 1
));

$gidenkullanicicek=$gidenkullanicisec->fetch(PDO::FETCH_ASSOC);
                                                    ?>

                                                    <li>
                                                        <div class="notify-message-img">
                                                            <?php if (!empty($gidenkullanicicek['kullanici_resim'])) { ?>


                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="<?php echo $gidenkullanicicek['kullanici_resim']; ?>">
                                                            

                                                      <?php  } else {


                                                        if ($gidenkullanicicek['kullanici_yetki']=="0") {


                                                            if (empty($gidenkullanicicek['kullanici_cinsiyet'])) { ?>


                                                                <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/unisex-avatar.jpg">


                                                                

                                                          <?php  } else if ($gidenkullanicicek['kullanici_cinsiyet']=="1") { ?>

                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/3.jpg">
                                                                

                                                           <?php } else if($gidenkullanicicek['kullanici_cinsiyet']=="2"){ ?>


                                                             <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/5.jpg">


                                                           <?php }

                                                            

                                                        } else if($gidenkullanicicek['kullanici_yetki']=="1" or $gidenkullanicicek['kullanici_yetki']=="2" or $gidenkullanicicek['kullanici_yetki']=="3"){


                                                            if ($gidenkullanicicek['kullanici_cinsiyet']=="1") { ?>


                                                                 <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/9.jpg">
                                                              

                                                          <?php  } else { ?>


                                                            <img style="width: 75px;height: 75px;" class="img-responsive img-circle" src="dimg/11.jpg">



                                                        <?php  }





                                                        }




                                                      } ?>
                                                        </div>
                                                        <div class="notify-message-info">
                                                            <div class="notify-message-sender">

                                                               <?php if ($gidenkullanicicek['kullanici_yetki']==1) { ?>

                                                                    <a style="color:#707070;" href="profil-<?php echo $gidenkullanicicek['kullanici_id']; ?>"><?php echo $gidenkullanicicek['kullanici_ad']." ".$gidenkullanicicek['kullanici_soyad']; ?></a>

                                                              <?php } else { ?>

                                                                <?php echo $gidenkullanicicek['kullanici_ad']." ".$gidenkullanicicek['kullanici_soyad']; ?>



                                                            <?php  } ?> (<?php if ($gidenkullanicicek['kullanici_yetki']==1 or $gidenkullanicicek['kullanici_yetki']==2 or $gidenkullanicicek['kullanici_yetki']==3) {
                                                                    echo "Eğitmen";
                                                                } else if($gidenkullanicicek['kullanici_yetki']==0){

                                                                    echo "Öğrenci";


                                                                } ?>)
                                                                    

                                                                </div>
                                                            <div class="notify-message-date"><?php if (substr($mesajcekgiden['mesaj_zaman'],5,2)=="01") {
                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Ocak";
                                            } 
                                            else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="02"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Şubat";



                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="03"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Mart";



                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="04"){

                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Nisan";




                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="05"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Mayıs";



                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="06"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Haz";




                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="07"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Tem";



                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="08"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Ağu";




                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="09"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Eylül";




                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="10"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Ekim";



                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="11"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Kasım";




                                            } else if(substr($mesajcekgiden['mesaj_zaman'],5,2)=="12"){


                                                echo substr($mesajcekgiden['mesaj_zaman'],8,2)." Aralık";




                                            } ?> <?php echo substr($mesajcekgiden['mesaj_zaman'], 0,4)."   ".substr($mesajcekgiden['mesaj_zaman'], 11,5) ?></div>
                                                            <div class="notify-message-subject"><?php echo $mesajcekgiden['mesaj_icerik']; ?></div>
                                                            <?php if ($mesajcekgiden['mesaj_okundu']==1) { ?> <div>  

                                                              <i style="color:rgba(78, 192, 33, 0.7)" class="far fa-check-circle"> Okundu</i>
                                                              
                                                          </div> <?php  } ?>
                                                            
                                                        </div>
                                                      <div class="notify-message-sign">
                                                           
                                                          
                                                           <a id="mesajsilengel" data-toggle="tooltip" data-placement="bottom" title="Bu Mesajı Sil" href="nedmin/production/netting/musteriislem.php?mesaj_id=<?php echo $mesajcekgiden['mesaj_id'] ?>&mesajsilgiden=ok"><i style="color:#e74c3c;margin-left: 22px;" class="fas fa-trash"></i></a>
                                                           
                                                        </div>


                                                    </li>
                                                   
                                                    
                                               <?php } ?>
                                                    
                                                </ul>
                                              

                                          <?php  } else { ?>



                                           <p align="center">Henüz Kimseye Mesaj Göndermemişsiniz.</p>



                                         <?php } ?>
                                            
                                        </div> 
                                    </div> 
                                                                           
                                </div> 

                            
                        </div>  
                    </div>  
                </div>  
            </div> 
           <?php require_once 'footer.php'; ?>

           <script type="text/javascript">
             
             $(document).ready(function () {
    $("a#mesajsilengel").one("click", function() {
    $(this).click(function () { return false; });
});
});

             $(document).ready(function() {
  $('#mesajyanitpost').submit(function() {


    if(typeof jQuery.data(this, "disabledOnSubmit") == 'undefined') {
      jQuery.data(this, "disabledOnSubmit", { submited: true });
      $('input[type=submit], input[type=button]', this).each(function() {
        $(this).attr("disabled", "disabled");
      });
      return true;
    }
    else
    {
      return false;
    };






  });


});
           </script>